/* =====================================================================
   03 — TEXTURES, DRAWN FROM NOTHING

   There are no image files in this project. Every leaf, blossom, needle
   and blade below is drawn with ordinary 2D canvas commands — the same
   API you would use to draw a chart — and then handed to the graphics
   card as a texture. That is why the whole park fits in one file.

   Each texture is a square tile with a transparent background. The
   renderer alpha-tests it: any pixel below the cutoff is thrown away
   entirely, which is what gives a flat rectangle the outline of a leaf.
   ===================================================================== */

function mkTex(gl, size, draw, opts){
  const cv = newCanvas(size, size);
  const g  = cv.getContext('2d');
  g.clearRect(0, 0, size, size);
  draw(g, size);
  const t = texFromCanvas(gl, cv, true);
  if(opts && opts.repeat){
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
  }
  return t;
}

/* ---- shared drawing helpers ---------------------------------------- */

/* A leaf blade: two mirrored bezier curves from base to tip. `width`
   controls how fat it is, `belly` where along its length it is widest. */
function leafPath(g, x, y, len, width, belly){
  belly = belly === undefined ? 0.42 : belly;
  g.beginPath();
  g.moveTo(x, y);
  g.bezierCurveTo(x + width, y - len*belly, x + width*0.62, y - len*0.82, x, y - len);
  g.bezierCurveTo(x - width*0.62, y - len*0.82, x - width, y - len*belly, x, y);
  g.closePath();
}

/* Serrations along both edges — the giveaway feature on a cherry leaf.
   Drawn as small notches cut out with destination-out compositing. */
function serrate(g, x, y, len, width, teeth){
  g.save();
  g.globalCompositeOperation = 'destination-out';
  for(let i = 1; i < teeth; i++){
    const f  = i/teeth;
    const hw = width * Math.sin(f*Math.PI) * 0.98;
    const yy = y - len*f;
    const r  = len*0.032;
    g.beginPath(); g.arc(x + hw, yy, r, 0, 7); g.fill();
    g.beginPath(); g.arc(x - hw, yy - len*0.5/teeth, r, 0, 7); g.fill();
  }
  g.restore();
}

function veins(g, x, y, len, width, n, col, wid){
  g.strokeStyle = col;
  g.lineWidth = wid;
  g.lineCap = 'round';
  g.beginPath(); g.moveTo(x, y); g.lineTo(x, y - len*0.97); g.stroke();  // midrib
  for(let i = 1; i <= n; i++){
    const f  = i/(n+1);
    const yy = y - len*f;
    const hw = width * Math.sin(f*Math.PI) * 0.86;
    g.beginPath();
    g.moveTo(x, yy);
    g.quadraticCurveTo(x + hw*0.55, yy - len*0.03, x + hw, yy - len*0.10);
    g.stroke();
    g.beginPath();
    g.moveTo(x, yy);
    g.quadraticCurveTo(x - hw*0.55, yy - len*0.03, x - hw, yy - len*0.10);
    g.stroke();
  }
}

/* Vertical shading so a flat leaf does not read as a flat leaf. */
function leafFill(g, x, y, len, c1, c2){
  const gr = g.createLinearGradient(x, y, x, y - len);
  gr.addColorStop(0,    c1);
  gr.addColorStop(0.55, c2);
  gr.addColorStop(1,    c1);
  return gr;
}

/* =====================================================================
   FOLIAGE — one function per species
   ===================================================================== */

/* SAKURA — the blossom cluster. Five petals, each with the notched tip
   that distinguishes a cherry from a plum, pale at the edge and pink at
   the throat, with a tuft of stamens in the middle. Three or four
   flowers per tile so one card carries a whole cluster. */
function texSakuraBlossom(g, S){
  const r = rng(21);
  const flower = (cx, cy, rad, rot, pale) => {
    for(let p = 0; p < 5; p++){
      const a = rot + p * (Math.PI*2/5);
      g.save();
      g.translate(cx, cy);
      g.rotate(a);
      const gr = g.createRadialGradient(0, -rad*0.55, rad*0.06, 0, -rad*0.2, rad*1.15);
      gr.addColorStop(0,   pale ? '#ffffff' : '#fde3ec');
      gr.addColorStop(0.5, pale ? '#fdeaf1' : '#f9c9dc');
      gr.addColorStop(1,   pale ? '#f6cfdd' : '#efa8c6');
      g.fillStyle = gr;
      /* petal outline: wide, rounded, with a V cut out of the far edge */
      g.beginPath();
      g.moveTo(0, 0);
      g.bezierCurveTo(-rad*0.62, -rad*0.34, -rad*0.56, -rad*0.90, -rad*0.17, -rad*1.02);
      g.lineTo(0, -rad*0.84);                      // the notch
      g.lineTo(rad*0.17, -rad*1.02);
      g.bezierCurveTo(rad*0.56, -rad*0.90, rad*0.62, -rad*0.34, 0, 0);
      g.closePath();
      g.fill();
      g.strokeStyle = 'rgba(214,138,170,0.30)';
      g.lineWidth = rad*0.035;
      g.stroke();
      g.restore();
    }
    /* stamens */
    g.save();
    g.translate(cx, cy);
    for(let s = 0; s < 12; s++){
      const a = r()*Math.PI*2, l = rad*(0.30 + r()*0.30);
      g.strokeStyle = 'rgba(226,196,140,0.85)';
      g.lineWidth = rad*0.045;
      g.beginPath(); g.moveTo(0,0); g.lineTo(Math.cos(a)*l, Math.sin(a)*l); g.stroke();
      g.fillStyle = '#c9a24a';
      g.beginPath(); g.arc(Math.cos(a)*l, Math.sin(a)*l, rad*0.055, 0, 7); g.fill();
    }
    g.fillStyle = '#d9be7a';
    g.beginPath(); g.arc(0, 0, rad*0.10, 0, 7); g.fill();
    g.restore();
  };

  const S2 = S/2;
  flower(S2*0.62, S2*0.66, S*0.235, 0.3,  false);
  flower(S2*1.38, S2*0.80, S*0.215, 1.1,  true);
  flower(S2*1.05, S2*1.42, S*0.250, 2.0,  false);
  flower(S2*0.50, S2*1.48, S*0.180, 0.8,  true);
  flower(S2*1.55, S2*1.55, S*0.165, 2.6,  false);
}

/* SAKURA — hazakura, the leaves that follow the flowers. Ovate,
   serrated, with the bronze flush that new cherry growth has. */
function texSakuraLeaf(g, S){
  const draw = (x, y, len, w, rot, c1, c2) => {
    g.save(); g.translate(x, y); g.rotate(rot); g.translate(-x, -y);
    leafPath(g, x, y, len, w, 0.40);
    g.fillStyle = leafFill(g, x, y, len, c1, c2);
    g.fill();
    serrate(g, x, y, len, w, 16);
    g.save(); leafPath(g, x, y, len, w, 0.40); g.clip();
    veins(g, x, y, len, w, 7, 'rgba(74,104,58,0.42)', len*0.014);
    g.restore();
    g.restore();
  };
  draw(S*0.30, S*0.94, S*0.62, S*0.135, -0.35, '#5f8347', '#7ba35c');
  draw(S*0.70, S*0.98, S*0.70, S*0.150,  0.30, '#557a40', '#74a057');
  draw(S*0.52, S*0.62, S*0.48, S*0.110,  0.05, '#6b8f4f', '#89b06a');
}

/* MOMIJI — Japanese maple. Seven lobes cut nearly to the middle, each
   lobe itself toothed. In late spring the leaf is fresh green with the
   new growth still carrying red at the tips. */
function texMomijiLeaf(g, S){
  const draw = (cx, cy, rad, rot, red) => {
    g.save(); g.translate(cx, cy); g.rotate(rot);
    const lobes = 7, spread = Math.PI*1.30;
    for(let i = 0; i < lobes; i++){
      const a = -spread/2 + (i/(lobes-1))*spread;
      /* the middle lobe is longest, the outer ones shorter */
      const L = rad * (0.62 + 0.38*Math.cos(a*0.92));
      g.save(); g.rotate(a);
      const gr = g.createLinearGradient(0, 0, 0, -L);
      gr.addColorStop(0,   red ? '#8d5a44' : '#4f7a3c');
      gr.addColorStop(0.4, red ? '#b06a4e' : '#6a9b4e');
      gr.addColorStop(1,   red ? '#c07a55' : '#84b45f');
      g.fillStyle = gr;
      g.beginPath();
      g.moveTo(0, 0);
      g.lineTo(-L*0.115, -L*0.30);
      /* toothed edge up one side and down the other */
      for(let t = 0; t < 5; t++){
        const f = 0.30 + t*0.145;
        const w = L*0.115*(1 - t*0.16);
        g.lineTo(-w*1.55, -L*f);
        g.lineTo(-w*0.80, -L*(f+0.055));
      }
      g.lineTo(0, -L);
      for(let t = 4; t >= 0; t--){
        const f = 0.30 + t*0.145;
        const w = L*0.115*(1 - t*0.16);
        g.lineTo(w*0.80, -L*(f+0.055));
        g.lineTo(w*1.55, -L*f);
      }
      g.lineTo(L*0.115, -L*0.30);
      g.closePath();
      g.fill();
      g.strokeStyle = red ? 'rgba(120,70,50,0.5)' : 'rgba(58,88,44,0.45)';
      g.lineWidth = L*0.022;
      g.beginPath(); g.moveTo(0,0); g.lineTo(0,-L*0.9); g.stroke();
      g.restore();
    }
    g.restore();
  };
  draw(S*0.34, S*0.66, S*0.34,  0.10, false);
  draw(S*0.72, S*0.46, S*0.27, -0.45, true);
  draw(S*0.62, S*0.86, S*0.30,  0.55, false);
}

/* SUGI — Japanese cedar. Not really leaves: short, incurved, awl-shaped
   scales spiralling round the shoot. Drawn as a whole branchlet, since
   that is the unit the eye reads at any distance. */
function texSugiSprig(g, S){
  const r = rng(7);
  const shoot = (x0, y0, ang, len, w) => {
    const steps = 34;
    for(let i = 0; i < steps; i++){
      const f  = i/steps;
      const px = x0 + Math.cos(ang)*len*f;
      const py = y0 + Math.sin(ang)*len*f;
      /* Short, incurved, and crowded. Sugi scales are stubby — draw them
         long and the card reads as a pine frond instead of a cedar. */
      const nl = w * (1 - f*0.42) * (0.7 + r()*0.5);
      for(const side of [-1, 1]){
        const a2 = ang + side*(1.05 - f*0.30) + (r()-0.5)*0.3;
        g.strokeStyle = `rgba(${40+Math.floor(r()*24)},${72+Math.floor(r()*30)},${44+Math.floor(r()*18)},0.97)`;
        g.lineWidth = Math.max(1.4, S*0.024);
        g.lineCap = 'round';
        g.beginPath();
        g.moveTo(px, py);
        g.quadraticCurveTo(
          px + Math.cos(a2)*nl*0.6, py + Math.sin(a2)*nl*0.6,
          px + Math.cos(a2*0.72 + ang*0.28)*nl, py + Math.sin(a2*0.72 + ang*0.28)*nl
        );
        g.stroke();
      }
    }
    g.strokeStyle = '#4a3a2a';
    g.lineWidth = S*0.014;
    g.beginPath(); g.moveTo(x0,y0); g.lineTo(x0+Math.cos(ang)*len, y0+Math.sin(ang)*len); g.stroke();
  };
  /* A denser, squatter spray than one long frond. A single long shoot
     reads as a palm leaf at card size; a bushy cluster reads as cedar. */
  shoot(S*0.50, S*0.99, -Math.PI/2, S*0.72, S*0.130);
  for(let i = 0; i < 9; i++){
    const f = 0.10 + i*0.098;
    const y = S*0.99 - S*0.72*f;
    const L = S*0.34*(1 - f*0.50);
    shoot(S*0.50, y, -Math.PI/2 - (1.02 - f*0.42), L, S*0.100);
    shoot(S*0.50, y, -Math.PI/2 + (1.02 - f*0.42), L, S*0.100);
    if(i % 2 === 0){
      shoot(S*0.50, y, -Math.PI/2 - (0.55 - f*0.20), L*0.7, S*0.088);
      shoot(S*0.50, y, -Math.PI/2 + (0.55 - f*0.20), L*0.7, S*0.088);
    }
  }
}

/* ICHO — ginkgo. The most recognisable leaf outline of any tree: a fan
   with parallel veins radiating from the stalk and a notch in the
   middle of the outer edge. */
function texGinkgoLeaf(g, S){
  const fan = (cx, cy, rad, rot) => {
    g.save(); g.translate(cx, cy); g.rotate(rot);
    const half = 0.72;
    g.beginPath();
    g.moveTo(0, 0);
    g.lineTo(Math.sin(-half)*rad, -Math.cos(-half)*rad);
    for(let a = -half; a <= half; a += 0.06){
      /* the notch: pull the radius in near the centre of the arc */
      const notch = 1 - 0.14*Math.exp(-(a*a)/0.006);
      g.lineTo(Math.sin(a)*rad*notch, -Math.cos(a)*rad*notch);
    }
    g.closePath();
    const gr = g.createLinearGradient(0, 0, 0, -rad);
    gr.addColorStop(0,   '#7d9c4a');
    gr.addColorStop(0.6, '#98b45c');
    gr.addColorStop(1,   '#a8c069');
    g.fillStyle = gr;
    g.fill();
    /* dichotomous venation — veins that fork rather than branch off a
       midrib. Ginkgo has no midrib at all. */
    g.strokeStyle = 'rgba(88,108,52,0.42)';
    g.lineWidth = rad*0.014;
    for(let a = -half*0.95; a <= half*0.95; a += 0.075){
      g.beginPath();
      g.moveTo(0, 0);
      g.lineTo(Math.sin(a)*rad*0.985, -Math.cos(a)*rad*0.985);
      g.stroke();
    }
    g.strokeStyle = '#6f8a44';
    g.lineWidth = rad*0.045;
    g.beginPath(); g.moveTo(0,0); g.lineTo(0, rad*0.22); g.stroke();
    g.restore();
  };
  fan(S*0.32, S*0.60, S*0.40, -0.30);
  fan(S*0.70, S*0.52, S*0.33,  0.42);
  fan(S*0.52, S*0.92, S*0.36,  0.05);
}

/* MATSU — Japanese black pine. Needles in bundles of two, stiff and
   dark, held in a sheath. Drawn as a spray so each card is a tuft. */
function texPineNeedles(g, S){
  const r = rng(13);
  const bundle = (x, y, ang, len) => {
    for(const off of [-0.055, 0.055]){
      const a = ang + off + (r()-0.5)*0.05;
      const gr = g.createLinearGradient(x, y, x + Math.cos(a)*len, y + Math.sin(a)*len);
      gr.addColorStop(0,   '#2f4a2c');
      gr.addColorStop(0.6, '#3c5c34');
      gr.addColorStop(1,   '#4c6f3d');
      g.strokeStyle = gr;
      g.lineWidth = Math.max(1.1, S*0.018);
      g.lineCap = 'round';
      g.beginPath();
      g.moveTo(x, y);
      /* a slight bow — pine needles are not straight lines */
      g.quadraticCurveTo(
        x + Math.cos(a)*len*0.5 - Math.sin(a)*len*0.06,
        y + Math.sin(a)*len*0.5 + Math.cos(a)*len*0.06,
        x + Math.cos(a)*len, y + Math.sin(a)*len);
      g.stroke();
    }
    g.fillStyle = '#6b5238';
    g.beginPath(); g.arc(x, y, S*0.022, 0, 7); g.fill();
  };
  const cx = S*0.5, cy = S*0.94;
  for(let i = 0; i < 15; i++){
    const a = -Math.PI/2 + (r()-0.5)*2.25;
    bundle(cx + (r()-0.5)*S*0.10, cy - r()*S*0.16, a, S*(0.50 + r()*0.42));
  }
  for(let i = 0; i < 8; i++){
    const a = -Math.PI/2 + (r()-0.5)*2.6;
    bundle(cx + (r()-0.5)*S*0.34, cy - S*(0.24 + r()*0.26), a, S*(0.30 + r()*0.30));
  }
}

/* Generic broadleaf for the shrubs and hedges that fill the middle
   distance — simple, because nothing looks at them closely. */
function texShrubLeaf(g, S){
  const r = rng(31);
  for(let i = 0; i < 11; i++){
    const x = S*(0.14 + r()*0.72), y = S*(0.30 + r()*0.68);
    const len = S*(0.24 + r()*0.24), w = len*(0.30 + r()*0.14);
    g.save(); g.translate(x, y); g.rotate((r()-0.5)*2.6); g.translate(-x,-y);
    leafPath(g, x, y, len, w, 0.46);
    const v = 0.78 + r()*0.42;
    g.fillStyle = `rgb(${Math.floor(74*v)},${Math.floor(112*v)},${Math.floor(58*v)})`;
    g.fill();
    g.strokeStyle = 'rgba(40,62,32,0.34)';
    g.lineWidth = len*0.02;
    g.beginPath(); g.moveTo(x,y); g.lineTo(x, y-len*0.94); g.stroke();
    g.restore();
  }
}

/* Azalea — the shrub that is actually in flower in a Japanese park in
   late spring. Funnel-shaped flowers, five shallow lobes. */
function texAzalea(g, S){
  const r = rng(53);
  /* foliage behind */
  for(let i = 0; i < 9; i++){
    const x = S*(0.12+r()*0.76), y = S*(0.30+r()*0.66);
    const len = S*(0.18+r()*0.16), w = len*0.34;
    g.save(); g.translate(x,y); g.rotate((r()-0.5)*2.8); g.translate(-x,-y);
    leafPath(g, x, y, len, w, 0.48);
    g.fillStyle = `rgba(${52+Math.floor(r()*24)},${86+Math.floor(r()*26)},${44+Math.floor(r()*18)},1)`;
    g.fill();
    g.restore();
  }
  const bloom = (cx, cy, rad, hue) => {
    for(let p = 0; p < 5; p++){
      const a = p*(Math.PI*2/5) + r()*0.2;
      g.save(); g.translate(cx, cy); g.rotate(a);
      const gr = g.createRadialGradient(0, -rad*0.2, rad*0.05, 0, -rad*0.5, rad);
      gr.addColorStop(0, '#ffffff');
      gr.addColorStop(1, hue);
      g.fillStyle = gr;
      g.beginPath();
      g.moveTo(0,0);
      g.bezierCurveTo(-rad*0.55, -rad*0.4, -rad*0.42, -rad*0.98, 0, -rad);
      g.bezierCurveTo(rad*0.42, -rad*0.98, rad*0.55, -rad*0.4, 0, 0);
      g.fill();
      g.restore();
    }
    g.fillStyle = 'rgba(190,120,150,0.7)';
    g.beginPath(); g.arc(cx, cy, rad*0.10, 0, 7); g.fill();
  };
  bloom(S*0.34, S*0.44, S*0.20, '#e4749e');
  bloom(S*0.68, S*0.38, S*0.17, '#ef8fb2');
  bloom(S*0.52, S*0.70, S*0.19, '#e0668f');
  bloom(S*0.80, S*0.68, S*0.14, '#f2a3c0');
}

/* Grass. A tile of blades rather than one blade — far fewer cards for
   the same visual density. */
function texGrass(g, S){
  const r = rng(97);
  for(let i = 0; i < 26; i++){
    const x = S*(0.04 + r()*0.92);
    const h = S*(0.42 + r()*0.54);
    const bend = (r()-0.5)*S*0.30;
    const w = S*(0.016 + r()*0.020);
    const v = 0.72 + r()*0.34;
    const gr = g.createLinearGradient(x, S, x, S-h);
    gr.addColorStop(0, `rgb(${Math.floor(44*v)},${Math.floor(68*v)},${Math.floor(32*v)})`);
    gr.addColorStop(1, `rgb(${Math.floor(86*v)},${Math.floor(116*v)},${Math.floor(54*v)})`);
    g.fillStyle = gr;
    g.beginPath();
    g.moveTo(x - w, S);
    g.quadraticCurveTo(x - w + bend*0.5, S - h*0.55, x + bend, S - h);
    g.quadraticCurveTo(x + w + bend*0.5, S - h*0.55, x + w, S);
    g.closePath();
    g.fill();
  }
}

/* Small meadow flowers, drawn white so a per-instance tint can turn the
   same geometry into buttercups, clover or shibazakura. */
function texMeadowFlower(g, S){
  const r = rng(61);
  const one = (cx, cy, rad, petals) => {
    for(let p = 0; p < petals; p++){
      const a = p*(Math.PI*2/petals);
      g.save(); g.translate(cx, cy); g.rotate(a);
      g.fillStyle = '#ffffff';
      g.beginPath(); g.ellipse(0, -rad*0.62, rad*0.30, rad*0.62, 0, 0, 7); g.fill();
      g.restore();
    }
    g.fillStyle = '#ffd76b';
    g.beginPath(); g.arc(cx, cy, rad*0.24, 0, 7); g.fill();
  };
  for(let i = 0; i < 5; i++){
    one(S*(0.18+r()*0.64), S*(0.20+r()*0.62), S*(0.11+r()*0.10), 5 + Math.floor(r()*3));
  }
  g.strokeStyle = 'rgba(96,126,58,0.9)';
  g.lineWidth = S*0.022;
  for(let i = 0; i < 4; i++){
    const x = S*(0.2+r()*0.6);
    g.beginPath(); g.moveTo(x, S); g.quadraticCurveTo(x+(r()-0.5)*S*0.1, S*0.7, x+(r()-0.5)*S*0.2, S*0.45); g.stroke();
  }
}

/* A single falling petal, seen from any angle. */
function texPetal(g, S){
  const gr = g.createRadialGradient(S*0.5, S*0.72, S*0.04, S*0.5, S*0.5, S*0.52);
  gr.addColorStop(0,   '#ffffff');
  gr.addColorStop(0.55,'#fbdde8');
  gr.addColorStop(1,   '#f2b9d0');
  g.fillStyle = gr;
  g.beginPath();
  g.moveTo(S*0.5, S*0.92);
  g.bezierCurveTo(S*0.06, S*0.68, S*0.10, S*0.14, S*0.42, S*0.08);
  g.lineTo(S*0.5, S*0.22);
  g.lineTo(S*0.58, S*0.08);
  g.bezierCurveTo(S*0.90, S*0.14, S*0.94, S*0.68, S*0.5, S*0.92);
  g.closePath();
  g.fill();
}

/* Butterfly. One tile holds both wings; the geometry folds them along
   the middle so they can flap. */
function texButterfly(g, S){
  const wing = (flip) => {
    g.save();
    g.translate(S*0.5, S*0.5);
    g.scale(flip, 1);
    const gr = g.createLinearGradient(0, -S*0.3, S*0.42, S*0.3);
    gr.addColorStop(0,   '#fff4d2');
    gr.addColorStop(0.5, '#f6d98a');
    gr.addColorStop(1,   '#e0a94e');
    g.fillStyle = gr;
    g.beginPath();                                   // forewing
    g.moveTo(0, -S*0.05);
    g.bezierCurveTo(S*0.16, -S*0.44, S*0.44, -S*0.40, S*0.44, -S*0.12);
    g.bezierCurveTo(S*0.44, S*0.02, S*0.20, S*0.04, 0, S*0.02);
    g.closePath(); g.fill();
    g.beginPath();                                   // hindwing
    g.moveTo(0, S*0.01);
    g.bezierCurveTo(S*0.22, S*0.02, S*0.36, S*0.18, S*0.26, S*0.36);
    g.bezierCurveTo(S*0.14, S*0.44, S*0.02, S*0.26, 0, S*0.10);
    g.closePath(); g.fill();
    g.strokeStyle = 'rgba(70,48,26,0.8)';
    g.lineWidth = S*0.014;
    g.stroke();
    /* eyespots */
    g.fillStyle = 'rgba(70,48,26,0.75)';
    g.beginPath(); g.arc(S*0.30, -S*0.22, S*0.035, 0, 7); g.fill();
    g.beginPath(); g.arc(S*0.20, S*0.24, S*0.028, 0, 7); g.fill();
    g.restore();
  };
  wing(1); wing(-1);
  g.fillStyle = '#4a3520';
  g.beginPath(); g.ellipse(S*0.5, S*0.5, S*0.022, S*0.16, 0, 0, 7); g.fill();
}

/* A bird in silhouette, wings spread — only ever seen small and far. */
function texBird(g, S){
  g.fillStyle = 'rgba(38,32,28,0.92)';
  g.beginPath();
  g.moveTo(S*0.5, S*0.55);
  g.quadraticCurveTo(S*0.30, S*0.30, S*0.06, S*0.40);
  g.quadraticCurveTo(S*0.28, S*0.46, S*0.46, S*0.62);
  g.quadraticCurveTo(S*0.28, S*0.62, S*0.10, S*0.72);
  g.quadraticCurveTo(S*0.34, S*0.72, S*0.5, S*0.64);
  g.quadraticCurveTo(S*0.66, S*0.72, S*0.90, S*0.72);
  g.quadraticCurveTo(S*0.72, S*0.62, S*0.54, S*0.62);
  g.quadraticCurveTo(S*0.72, S*0.46, S*0.94, S*0.40);
  g.quadraticCurveTo(S*0.70, S*0.30, S*0.5, S*0.55);
  g.fill();
}

/* Ground grain. Tiles seamlessly, and is multiplied over the grass and
   gravel colours so a 1-metre triangle does not read as a flat plane. */
function texGroundDetail(g, S){
  const img = g.createImageData(S, S);
  const d = img.data;
  for(let y = 0; y < S; y++){
    for(let x = 0; x < S; x++){
      /* Sample noise on a torus so the left edge matches the right and
         the top matches the bottom — that is what makes it tile. */
      const u = x/S*Math.PI*2, v = y/S*Math.PI*2;
      const n = fbm(Math.cos(u)*2.4 + 8, Math.sin(v)*2.4 + 8, 4)
              + fbm(Math.cos(u)*7.0 + 2, Math.sin(v)*7.0 + 2, 3) * 0.5;
      const c = Math.max(0, Math.min(255, 202 + n*66));
      const i = (y*S + x)*4;
      d[i] = c; d[i+1] = c; d[i+2] = c*0.99; d[i+3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
}

/* Bark. Vertical fissures, applied to trunks; the colour underneath is
   per-species vertex colour, so this only supplies the light and shade
   of the furrows. */
function texBark(g, S){
  const img = g.createImageData(S, S);
  const d = img.data;
  for(let y = 0; y < S; y++){
    for(let x = 0; x < S; x++){
      const u = x/S*Math.PI*2;
      /* stretched vertically: bark runs up the trunk, not across it */
      const n = fbm(Math.cos(u)*3.0 + 40, y/S*11 + 40, 4);
      const m = fbm(Math.cos(u)*9.0 + 70, y/S*30 + 70, 3) * 0.4;
      const c = Math.max(0, Math.min(255, 168 + (n + m)*190));
      const i = (y*S + x)*4;
      d[i] = c; d[i+1] = c*0.985; d[i+2] = c*0.96; d[i+3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
}

/* The marker ring. A soft annulus, brightest a little inside its edge,
   so it reads as light caught in the grass rather than as a drawn circle. */
function texHalo(g, S){
  const img = g.createImageData(S, S);
  const d = img.data;
  const c = S/2;
  for(let y = 0; y < S; y++){
    for(let x = 0; x < S; x++){
      const r = Math.hypot(x - c, y - c) / c;
      /* two overlapping falloffs: a ring, and a wash inside it */
      const ring = Math.exp(-Math.pow((r - 0.80)/0.085, 2.0));
      const wash = Math.max(0, 1 - r) * 0.09;
      let a = Math.min(1, ring*0.78 + wash);
      if(r > 1) a = 0;
      const i = (y*S + x)*4;
      d[i] = 255; d[i+1] = 238; d[i+2] = 206; d[i+3] = Math.round(a*255);
    }
  }
  g.putImageData(img, 0, 0);
}

/* Build every texture once, at startup. */
function buildTextures(gl){
  return {
    sakura:  mkTex(gl, 256, texSakuraBlossom),
    sakuraL: mkTex(gl, 256, texSakuraLeaf),
    momiji:  mkTex(gl, 256, texMomijiLeaf),
    sugi:    mkTex(gl, 256, texSugiSprig),
    ginkgo:  mkTex(gl, 256, texGinkgoLeaf),
    matsu:   mkTex(gl, 256, texPineNeedles),
    shrub:   mkTex(gl, 256, texShrubLeaf),
    azalea:  mkTex(gl, 256, texAzalea),
    grass:   mkTex(gl, 256, texGrass),
    flower:  mkTex(gl, 128, texMeadowFlower),
    petal:   mkTex(gl, 64,  texPetal),
    fly:     mkTex(gl, 128, texButterfly),
    bird:    mkTex(gl, 64,  texBird),
    ground:  mkTex(gl, 256, texGroundDetail, {repeat:true}),
    bark:    mkTex(gl, 256, texBark,         {repeat:true}),
    halo:    mkTex(gl, 256, texHalo),
    white:   mkTex(gl, 4, (g,S)=>{ g.fillStyle='#fff'; g.fillRect(0,0,S,S); })
  };
}
