/* =====================================================================
   11 — PUTTING IT TOGETHER
   ===================================================================== */

/* ---- sound ----------------------------------------------------------
   Synthesised, like everything else here. There are no audio files.

   WIND is two seconds of white noise — literally random numbers between
   -1 and 1 — looped forever and pushed through a low-pass filter, which
   throws away the high frequencies and leaves the low rumble. A hiss
   becomes wind. The filter's cutoff then drifts slowly and at random, and
   that drift is what stops it sounding like a machine: real wind gets
   louder and softer and brighter and duller, and never on a schedule.

   BIRDSONG is a single oscillator whose pitch is swept sharply up and
   then down over about a tenth of a second, with the volume rising and
   falling just as fast. That is very nearly what a small bird's call
   looks like on a spectrogram. One to three of them at a time, with a
   random gap of a couple of seconds to several before the next.

   FOOTSTEPS are a burst of noise shaped by a band-pass filter and cut off
   with a sharp decay curve — a crunch on gravel is broadband and short.

   Nothing plays until you click "Step outside", because browsers rightly
   refuse to let a page make noise at you before you have touched it. */
const Audio_ = {
  ok:false, muted:false,
  start(){
    if(this.ok) return;
    try{
      const C = window.AudioContext || window.webkitAudioContext;
      if(!C) return;
      this.ctx = new C();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.30;
      this.master.connect(this.ctx.destination);

      /* wind: two seconds of white noise on a loop, run through a
         low-pass that drifts, which is enough to stop it sounding like
         a hiss */
      const len = this.ctx.sampleRate*2;
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for(let i=0;i<len;i++) d[i] = (Math.random()*2-1)*0.5;
      const src = this.ctx.createBufferSource();
      src.buffer = buf; src.loop = true;
      const lp = this.ctx.createBiquadFilter();
      lp.type='lowpass'; lp.frequency.value=420; lp.Q.value=0.6;
      const g = this.ctx.createGain(); g.gain.value=0.30;
      src.connect(lp); lp.connect(g); g.connect(this.master);
      src.start();
      this.windLP = lp;

      const drift = () => {
        if(!this.ctx) return;
        const t = this.ctx.currentTime;
        lp.frequency.cancelScheduledValues(t);
        lp.frequency.linearRampToValueAtTime(280 + Math.random()*520, t + 3 + Math.random()*4);
        g.gain.linearRampToValueAtTime(0.18 + Math.random()*0.22, t + 3);
        setTimeout(drift, 3500 + Math.random()*4000);
      };
      drift();
      this.ok = true;
      this.birdLoop();
    }catch(e){ /* no audio available; the park is just quiet */ }
  },
  blip(f, dur, type, vol){
    if(!this.ok || this.muted) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f, t);
    o.frequency.exponentialRampToValueAtTime(f*(1.4+Math.random()*0.7), t+dur*0.55);
    o.frequency.exponentialRampToValueAtTime(f*0.85, t+dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol||0.09, t+0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    o.connect(g); g.connect(this.master);
    o.start(t); o.stop(t+dur+0.02);
  },
  birdLoop(){
    if(!this.ok) return;
    const n = 1 + Math.floor(Math.random()*3);
    for(let i=0;i<n;i++){
      setTimeout(()=> this.blip(1500 + Math.random()*2100, 0.07 + Math.random()*0.09,
                                'sine', 0.035 + Math.random()*0.03), i*120 + Math.random()*90);
    }
    setTimeout(()=> this.birdLoop(), 1800 + Math.random()*6500);
  },
  click(){
    if(!this.ok || this.muted) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type='square'; o.frequency.setValueAtTime(2400, t);
    o.frequency.exponentialRampToValueAtTime(340, t+0.045);
    g.gain.setValueAtTime(0.09, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t+0.06);
    o.connect(g); g.connect(this.master); o.start(t); o.stop(t+0.07);
  },
  step(){
    if(!this.ok || this.muted) return;
    const t = this.ctx.currentTime;
    const len = Math.floor(this.ctx.sampleRate*0.09);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++) d[i] = (Math.random()*2-1) * Math.pow(1-i/len, 3);
    const s = this.ctx.createBufferSource(); s.buffer = buf;
    const f = this.ctx.createBiquadFilter(); f.type='bandpass';
    f.frequency.value = 700 + Math.random()*700; f.Q.value = 0.9;
    const g = this.ctx.createGain(); g.gain.value = 0.055;
    s.connect(f); f.connect(g); g.connect(this.master); s.start(t);
  },
  toggle(){ this.muted = !this.muted; if(this.master) this.master.gain.value = this.muted?0:0.30; return this.muted; }
};

/* ---- boot ----------------------------------------------------------- */
const wait = () => new Promise(r => requestAnimationFrame(()=>setTimeout(r,0)));

async function boot(){
  const $ = id => document.getElementById(id);
  const fill = $('bootFill'), msg = $('bootMsg');
  const say = async (pct, text) => {
    fill.style.width = pct + '%';
    msg.textContent = text;
    await wait();
  };

  const canvas = $('gl');
  let R_;
  try{
    R_ = new Renderer(canvas);
    window.__R = R_; window.__LOOK = LOOK; window.Device = Device;
  }catch(e){
    msg.innerHTML = 'This needs WebGL2, which this browser has turned off or does not support.<br>Try a current Chrome, Edge, Firefox or Safari.';
    fill.style.width = '100%';
    return;
  }

  await say(8, 'drawing leaves, petals and bark…');
  const tex = buildTextures(R_.gl);

  await say(26, 'growing fifteen trees, branch by branch…');
  const world = buildWorld(R_.gl, tex);

  await say(62, 'laying the path and sowing the ground…');
  const crit = buildCritters(R_.gl);
  const player = new Player(world);
  player.attach(canvas);
  window.__P = player; window.__W = world;
  player.onLook = on => canvas.classList.toggle('look', on);

  await say(78, 'preparing the device…');
  /* Where the view was pointing before the device took it over. Set when
     Space aims at a tree, spent when the device closes, so putting
     Arborality away leaves you looking where you were rather than at
     whatever the scan happened to frame. */
  let viewBeforeScan = null;

  Device.init({
    onClose(){
      player.frozen = false;
      player.keys.clear();
      if(viewBeforeScan){
        player.tweenTo(viewBeforeScan.yaw, viewBeforeScan.pitch, 0.5);
        viewBeforeScan = null;
      }
    },
    onScan(){ Audio_.click(); },
    onCollect(){ Audio_.blip(880, 0.16, 'triangle', 0.07); setTimeout(()=>Audio_.blip(1320,0.22,'triangle',0.06), 130); }
  });

  const tris = world.treeGroups.reduce((a,p)=>a+p.tris,0);
  await say(96, Math.round(tris/1000) + 'k triangles of tree, ' + world.trees.length + ' trees');
  await say(100, 'ready');

  $('bootGo').classList.remove('hidden');
  $('bootGo').addEventListener('click', ()=>{
    $('boot').classList.add('hidden');
    Audio_.start();
    /* fade the control hint out once you have had a chance to read it */
    setTimeout(()=>{ const h=$('hint'); if(h) h.style.opacity='0.25'; }, 14000);
  });

  /* ---- input that is not walking ---- */
  let lastTree = null;
  window.addEventListener('keydown', e => {
    if(Device.open){
      if(Device.key(e.code)) e.preventDefault();
      return;
    }
    if(e.code === 'Space'){
      const t = player.nearestSpecimen();
      if(t){
        lastTree = t;
        /* Point the device at the tree before it comes up, so the scan
           frames the specimen rather than empty grass. aimAt hands back
           the heading it is about to leave, which is what gets restored
           when the device closes. */
        viewBeforeScan = player.aimAt(
          [t.x, t.y + Math.min(t.proto.height*t.scale*0.45, 9), t.z], 0.6);
        player.frozen = true;
        if(document.exitPointerLock) document.exitPointerLock();
        Audio_.click();
        Device.show(t);
      }
      e.preventDefault();
    }
    if(e.code === 'KeyC'){
      player.frozen = true;
      if(document.exitPointerLock) document.exitPointerLock();
      Device.show(lastTree || world.specimens[0]);
      Device.state = 'coll';
      Device.paint();
      e.preventDefault();
    }
    if(e.code === 'KeyR'){
      /* Start the visit over: back to the first spot on the path, facing
         the way you first faced, with the collection empty. The park
         itself is not rebuilt — it is grown from a fixed seed, so it was
         never going to be any different. */
      player.reset();
      Device.clearCollection();
      R_.halo.a = 0;
      Device.toast('the park is as you found it');
      Audio_.blip(660, 0.20, 'triangle', 0.05);
      e.preventDefault();
    }
    if(e.code === 'KeyM'){
      const m = Audio_.toggle();
      Device.toast(m ? 'sound off' : 'sound on');
    }
    if(e.code === 'KeyP'){
      /* Three steps down: full, lighter, lightest. Choosing by hand also
         stops the automatic version second-guessing you afterwards. */
      const next = R_.quality === 1 ? 0.5 : (R_.quality === 0.5 ? 0 : 1);
      R_.setQuality(next, true);
      Device.toast(next === 1 ? 'full detail' : next === 0.5 ? 'lighter graphics' : 'lightest graphics');
    }
  });

  /* ---- the loop -----------------------------------------------------
     Order matters here:
       1. work out how much time has passed, and CLAMP it
       2. move the player (and run any turn that is in flight)
       3. move the petals, butterflies and birds
       4. fade the marker ring towards where it should be
       5. draw the frame
       6. tick the device, if it is up
       7. update the prompt

     The clamp in step 1 is the one non-obvious part. requestAnimationFrame
     stops firing while a tab is in the background, so when you come back
     the gap since the last frame might be thirty seconds. Feeding that
     straight into the movement code would teleport you across the park
     and drop every petal at once. Capping it at 50 ms means a long pause
     simply loses that time rather than fast-forwarding through it.
     ------------------------------------------------------------------- */
  const prompt = $('prompt'), promptQ = $('promptQ'), reticle = $('reticle');
  let last = performance.now(), time = 0, stepPhase = 0, shown = null;
  let haloTree = null;

  function frame(now){
    let dt = (now - last)/1000;
    last = now;
    /* Clamp: after a tab has been in the background, dt can be seconds,
       and everything teleports. */
    dt = Math.min(dt, 0.05);
    time += dt;

    const cam = player.update(dt);

    /* footsteps, timed off the head bob so they land with the stride */
    const spd = Math.hypot(player.vel[0], player.vel[1]);
    if(spd > 0.5 && !player.frozen){
      stepPhase += dt*spd*1.55;
      if(stepPhase > 1){ stepPhase = 0; Audio_.step(); }
    }

    /* Which tree, if any, is the prompt talking about? Work it out before
       drawing, because two things point at it: a ring of light on the
       grass, and a few butterflies that drift over to it. */
    const target = Device.open ? null : player.nearestSpecimen();

    const h = R_.halo;
    if(target !== haloTree){
      /* fade the old ring out before moving it, so it never jumps */
      h.a += (0 - h.a) * (1 - Math.exp(-dt*7));
      if(h.a < 0.02){
        haloTree = target;
        if(target){
          h.x = target.x; h.y = target.y; h.z = target.z;
          /* sized off the trunk, not the crown — a ring round the foot */
          h.r = Math.max(1.15, target.proto.form.rad * target.scale * 4.2);
        }
      }
    } else {
      h.a += ((target ? 1 : 0) - h.a) * (1 - Math.exp(-dt*3.5));
    }

    updateCritters(crit, time, LOOK.wind*8,
                   target ? [target.x, target.y, target.z] : null);
    R_.render(world, crit, tex, cam, time);
    Device.tick(dt);

    if(!Device.open){
      const t = target;
      if(t !== shown){
        shown = t;
        if(t){
          promptQ.textContent = 'What tree is this?';
          prompt.classList.add('on');
        } else {
          prompt.classList.remove('on');
        }
      }
      reticle.style.opacity = t ? '0.9' : '0.35';
    } else {
      prompt.classList.remove('on');
    }

    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
