/* =====================================================================
   07 — WALKING

   Arrow keys, because that is what was asked for, with the mouse and
   WASD available as well. Left and right TURN rather than strafe: with
   no mouse you would otherwise be able to walk but never to look, and
   the whole point of the place is looking at it.
   ===================================================================== */

const EYE = 1.62;

class Player {
  constructor(world){
    this.world = world;
    /* Start on the path, facing along it, so the first thing you see is
       somewhere to walk to. */
    const at = pathPointAt(world.path, 2);
    this.pos = [at.p[0], 0, at.p[1]];
    this.yaw = Math.atan2(at.dir[0], at.dir[2]);
    this.pitch = 0.02;
    /* Kept so R can put you back exactly where you came in. Sliced,
       not referenced — otherwise walking would quietly edit the record
       of where you started. */
    this.start = { pos: this.pos.slice(), yaw: this.yaw, pitch: this.pitch };
    this.vel = [0,0];
    this.bob = 0;
    this.fov = 62 * Math.PI/180;
    this.keys = new Set();
    this.locked = false;
    this.dragging = false;
    this.frozen = false;      // true while the device is up
    this.headTilt = 0;

    /* Trunks you cannot walk through. Only the near trees matter — you
       never get close enough to the far ones for it to show. */
    this.blockers = world.trees.map(t => [t.x, t.z, Math.max(0.42, t.proto.form.rad * t.scale * 1.5 + 0.30)]);
  }

  attach(canvas){
    const kd = e => {
      if(e.repeat) return;
      this.keys.add(e.code);
      if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code)) e.preventDefault();
    };
    const ku = e => this.keys.delete(e.code);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    /* Losing focus mid-stride leaves a key stuck down and you walk into
       a tree forever. */
    window.addEventListener('blur', () => this.keys.clear());

    /* Looking around is a toggle: click to take the camera, click again
       to give it back. Escape still works because the browser insists on
       it, but nobody should have to discover that.

       Pointer lock is the nice way to do this, and a page inside a
       sandboxed frame is not always allowed it — so if the request is
       refused we quietly fall back to click-and-drag, which always
       works. */
    this.lockOK = !!canvas.requestPointerLock;
    let releasedByClick = false;

    canvas.addEventListener('mousedown', e => {
      if(this.frozen) return;
      if(this.locked){
        /* The second click. Release, and remember that we did, so the
           click event that follows does not immediately re-take it. */
        releasedByClick = true;
        if(document.exitPointerLock) document.exitPointerLock();
        e.preventDefault();
        return;
      }
      if(!this.lockOK){ this.dragging = true; e.preventDefault(); }
    });
    canvas.addEventListener('click', () => {
      if(this.frozen) return;
      if(releasedByClick){ releasedByClick = false; return; }
      if(this.locked || !this.lockOK) return;
      const p = canvas.requestPointerLock();
      if(p && p.catch) p.catch(()=>{ this.lockOK = false; });
    });
    document.addEventListener('pointerlockerror', () => { this.lockOK = false; });
    document.addEventListener('pointerlockchange', () => {
      this.locked = (document.pointerLockElement === canvas);
      if(this.onLook) this.onLook(this.locked);
    });
    window.addEventListener('mouseup', () => {
      if(this.dragging){ this.dragging = false; if(this.onLook) this.onLook(false); }
    });
    canvas.addEventListener('mousedown', () => {
      if(this.dragging && this.onLook) this.onLook(true);
    });
    window.addEventListener('mousemove', e => {
      if(this.frozen) return;
      if(this.locked || this.dragging) this.look(e.movementX || 0, e.movementY || 0);
    });

    /* Touch: drag anywhere to look, and the on-screen pad walks. */
    let lastT = null;
    canvas.addEventListener('touchstart', e => { lastT = e.touches[0]; }, {passive:true});
    canvas.addEventListener('touchmove', e => {
      if(this.frozen || !lastT) return;
      const t = e.touches[0];
      this.look((t.clientX-lastT.clientX)*1.8, (t.clientY-lastT.clientY)*1.8);
      lastT = t;
    }, {passive:true});
    canvas.addEventListener('touchend', () => { lastT = null; }, {passive:true});
  }

  look(dx, dy){
    this.yaw   -= dx * 0.0026;
    this.pitch -= dy * 0.0026;
    /* Stop just short of straight up or down: past vertical the camera
       flips over and it is horrible. */
    this.pitch = Math.max(-1.35, Math.min(1.35, this.pitch));
  }

  get fwd(){
    const cp = Math.cos(this.pitch);
    return [Math.sin(this.yaw)*cp, Math.sin(this.pitch), Math.cos(this.yaw)*cp];
  }

  /* ---- turning the view on its own --------------------------------
     Two jobs share one mechanism. Raising the device swings the view
     onto the tree; putting the device away swings it back to exactly
     where you were looking before. Both are `tweenTo`.
     ----------------------------------------------------------------- */

  /* Ease the view to an absolute yaw and pitch over `secs` seconds. */
  tweenTo(targetYaw, targetPitch, secs){
    /* Yaw is an angle on a circle, so 350 degrees and 10 degrees are
       twenty degrees apart, not three hundred and forty. Wrapping the
       difference into -180..+180 makes the view take the short way
       round instead of spinning almost the whole way back. */
    let d = targetYaw - this.yaw;
    while(d >  Math.PI) d -= Math.PI*2;
    while(d < -Math.PI) d += Math.PI*2;

    /* Timed off the WALL CLOCK, not off accumulated frame deltas. The
       frame loop clamps dt to 50 ms so a backgrounded tab cannot teleport
       you across the park — but that same clamp would make this turn take
       two real seconds on a machine struggling at 10 fps. A turn should
       last as long as it says it lasts however the frame rate is doing. */
    this.aim = {
      yaw0:   this.yaw,   dYaw:   d,
      pitch0: this.pitch, dPitch: targetPitch - this.pitch,
      t0: performance.now(), dur: (secs || 0.6) * 1000
    };
  }

  /* Swing the view round to frame a tree, and hand back where it was
     looking first so the caller can restore it later. */
  aimAt(p, secs){
    const before = { yaw: this.yaw, pitch: this.pitch };

    const dx = p[0]-this.pos[0], dz = p[2]-this.pos[2];
    /* Distance along the ground only — the pitch is worked out from this
       and the height difference, so it must not already include height.
       Floored at 0.4 m so standing inside a trunk cannot divide by zero. */
    const horiz = Math.max(0.4, Math.hypot(dx, dz));

    /* Aim at the middle of the crown, but never so steeply that the tree
       leaves the top of the frame. Standing close to a 21 m cedar, the
       true crown centre would be 60 degrees up; this caps how high we
       look and, through aimY, lowers the target instead of tipping you
       over backwards. */
    const aimY = Math.min(p[1], this.pos[1] + horiz*0.72);
    const pitch = Math.max(-0.5, Math.min(0.55,
                    Math.atan2(aimY - this.pos[1], horiz)));

    /* atan2(x, z) rather than the usual atan2(y, x): yaw here is measured
       from the +z axis, because that is the direction `fwd` faces when
       yaw is zero. */
    this.tweenTo(Math.atan2(dx, dz), pitch, secs);
    return before;
  }

  /* Put everything back to how it was when the park opened: same spot on
     the path, same heading, no momentum, no half-finished turn. The
     collection is emptied by the caller, since that belongs to the
     device rather than to the body doing the walking. */
  reset(){
    this.pos = this.start.pos.slice();
    this.yaw = this.start.yaw;
    this.pitch = this.start.pitch;
    this.vel = [0,0];
    this.bob = 0;
    this.aim = null;          // cancel any turn that was mid-flight
    this.keys.clear();        // and any key held down through the reset
  }

  update(dt){
    /* the aim tween runs even while frozen — that is the whole point */
    if(this.aim){
      const k2 = Math.min(1, (performance.now() - this.aim.t0) / this.aim.dur);
      /* Ease in and out rather than moving at a constant rate: a head
         turn starts slowly, gets going, and settles. A linear turn reads
         as a machine panning. */
      const e = k2 < 0.5 ? 2*k2*k2 : 1 - Math.pow(-2*k2+2, 2)/2;
      this.yaw   = this.aim.yaw0   + this.aim.dYaw*e;
      this.pitch = this.aim.pitch0 + this.aim.dPitch*e;
      if(k2 >= 1) this.aim = null;      // arrived; hand control back
    }
    const k = this.keys;
    let fwd = 0, strafe = 0, turn = 0;

    if(!this.frozen){
      if(k.has('ArrowUp')    || k.has('KeyW')) fwd += 1;
      if(k.has('ArrowDown')  || k.has('KeyS')) fwd -= 1;
      if(k.has('ArrowLeft'))  turn += 1;
      if(k.has('ArrowRight')) turn -= 1;
      if(k.has('KeyA')) strafe -= 1;
      if(k.has('KeyD')) strafe += 1;
      if(k.has('KeyQ')) turn += 1;
      if(k.has('KeyE')) turn -= 1;
    }

    /* Holding up and left together turns you as you walk, which traces a
       curve — that is the diagonal. Turning is slowed while walking so
       it feels like leaning into a bend rather than pivoting. */
    this.yaw += turn * dt * (fwd !== 0 ? 1.35 : 1.9);

    const slow = k.has('ShiftLeft') || k.has('ShiftRight');
    const speed = (slow ? 1.15 : 2.45);

    const s = Math.sin(this.yaw), c = Math.cos(this.yaw);
    let vx = (s*fwd + c*strafe) * speed;
    let vz = (c*fwd - s*strafe) * speed;

    /* Ease into and out of motion instead of snapping — a person has
       mass. This is the single cheapest thing that stops first-person
       movement feeling like a cursor. */
    const acc = 1 - Math.exp(-dt*9);
    this.vel[0] += (vx - this.vel[0]) * acc;
    this.vel[1] += (vz - this.vel[1]) * acc;

    let nx = this.pos[0] + this.vel[0]*dt;
    let nz = this.pos[2] + this.vel[1]*dt;

    /* Push out of any trunk we have walked into. Sliding along the
       tangent rather than stopping dead means you brush past a tree
       instead of getting stuck on it. */
    for(const b of this.blockers){
      const dx = nx-b[0], dz = nz-b[1];
      const d = Math.hypot(dx, dz);
      if(d < b[2] && d > 0.0001){
        nx = b[0] + dx/d*b[2];
        nz = b[1] + dz/d*b[2];
      }
    }
    const rr = Math.hypot(nx, nz);
    if(rr > PARK.walkR){ nx = nx/rr*PARK.walkR; nz = nz/rr*PARK.walkR; }

    this.pos[0] = nx; this.pos[2] = nz;

    /* Head bob, scaled by how fast you are actually going, so it stops
       when you stop. */
    const spd = Math.hypot(this.vel[0], this.vel[1]);
    this.bob += dt * spd * 3.1;
    const bobY = Math.sin(this.bob) * 0.026 * Math.min(1, spd/2.4);
    const bobR = Math.cos(this.bob*0.5) * 0.006 * Math.min(1, spd/2.4);
    this.headTilt += (bobR - this.headTilt) * 0.3;
    this.pos[1] = groundH(nx, nz) + EYE + bobY;

    return { pos: this.pos, fwd: this.fwd, fov: this.fov };
  }

  /* Which specimen tree, if any, are we standing at?

     HOW FAR IS "AT" A TREE? It cannot be one fixed distance. This used
     to be a flat 7 metres for everything, which quietly made the cedars
     unreachable: a Cryptomeria needs to stand well back from the path
     because it is a huge thing with a metre-wide trunk, so it sat 7.2 m
     out — just past the line — and never once offered itself, no matter
     how many times you walked by.

     The distance now scales with the tree, which is also how it works in
     life: you notice a 21 m cedar from further away than a 5 m maple,
     because there is more of it to notice.

     The two numbers below are a balance. Too small and the cedars fall
     out of reach again. Too large and a tree offers itself while you are
     still a long way off — including the one by the entrance, which then
     greets you the instant the park opens. They give roughly 6 m for a
     maple and 8.4 m for a cedar, which works out at two to five seconds
     of walking past each tree. */
  reachOf(t){
    return 4.2 + t.proto.height * t.scale * 0.20;
  }

  nearestSpecimen(){
    let best = null, bestScore = 0;
    const f = this.fwd;
    for(const t of this.world.specimens){
      const dx = t.x - this.pos[0], dz = t.z - this.pos[2];
      const d = Math.hypot(dx, dz);
      const reach = this.reachOf(t);
      if(d > reach) continue;

      /* Roughly in front of you: the dot product of the direction you
         are facing with the direction to the tree. 1 is dead ahead, 0 is
         square to your side, negative is behind you. 0.15 is generous —
         about 80 degrees off-axis — because raising the device turns you
         to face the tree properly anyway. */
      const facing = (dx*f[0] + dz*f[2]) / (d || 1);
      if(facing < 0.15) continue;

      /* When two trees are both in range, prefer the nearer one and the
         one you are looking more directly at. Distance is scored against
         that tree's own reach, so a cedar noticed at 10 m does not
         automatically lose to a maple at 6 m. */
      const score = (1 - d/reach) * (0.35 + facing*0.65);
      if(score > bestScore){ bestScore = score; best = t; }
    }
    return best;
  }
}
