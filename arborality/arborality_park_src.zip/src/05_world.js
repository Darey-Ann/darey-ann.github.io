/* =====================================================================
   05 — THE PARK

   Ground, path, and everything scattered on it. All of it derives from
   one seed, so the park is the same every time you open it.
   ===================================================================== */

const PARK = {
  half: 66,          // park extends this far from the centre in x and z
  walkR: 58,         // how far you are allowed to wander
  cell: 1.05,        // ground triangle size in metres
  pathHalf: 1.35,    // path is 2.7 m wide
  pathEdge: 0.85     // and fades into grass over this distance
};

/* Gentle relief. Two octaves of noise, nothing steep — this is a
   municipal park, not a hillside. The same function is used for the
   ground mesh, for placing every tree, and for the height of your own
   feet, so nothing can ever float or sink. */
function groundH(x, z){
  return fbm(x*0.0135 + 11, z*0.0135 + 7, 3) * 2.1
       + fbm(x*0.058  + 31, z*0.058  + 5, 2) * 0.34;
}
function groundN(x, z){
  const e = 0.6;
  const hL = groundH(x-e,z), hR = groundH(x+e,z);
  const hD = groundH(x,z-e), hU = groundH(x,z+e);
  return V.norm([hL-hR, 2*e, hD-hU]);
}

/* ---- the path -------------------------------------------------------
   Each pair below is [x, z] in metres, with the park centred on the
   origin and running to +/-66 m. The list is a closed LOOP — the last
   point joins back to the first — so you can keep walking and keep
   arriving somewhere.

   The curve drawn between the points is Catmull-Rom, which passes
   exactly THROUGH every control point rather than being pulled towards
   them the way a Bezier is. That makes it far easier to art-direct: you
   move a point to where you want the path, and the path goes there.

   Move a pair and the gravel, the worn edges either side, the grass
   thinning, and every specimen tree along the route all follow — they
   are derived from this list rather than placed by hand. */
const PATH_CTRL = [
  [  0, -34], [ 20, -30], [ 33, -14], [ 30,   6], [ 16,  18],
  [ 20,  34], [  6,  44], [-14,  40], [-26,  26], [-22,   8],
  [-34,  -4], [-33, -22], [-16, -34]
];

function catmull(p0, p1, p2, p3, t){
  const t2 = t*t, t3 = t2*t;
  return [
    0.5*((2*p1[0]) + (-p0[0]+p2[0])*t + (2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2 + (-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),
    0.5*((2*p1[1]) + (-p0[1]+p2[1])*t + (2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2 + (-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)
  ];
}

function buildPath(){
  const pts = [];
  const n = PATH_CTRL.length;
  for(let i = 0; i < n; i++){
    const p0 = PATH_CTRL[(i-1+n)%n], p1 = PATH_CTRL[i],
          p2 = PATH_CTRL[(i+1)%n],   p3 = PATH_CTRL[(i+2)%n];
    for(let s = 0; s < 14; s++) pts.push(catmull(p0,p1,p2,p3, s/14));
  }
  /* Arc length along the loop, so trees can be spaced by distance
     walked rather than by index — the samples are not evenly spaced. */
  const cum = [0];
  for(let i = 1; i <= pts.length; i++){
    const a = pts[i-1], b = pts[i % pts.length];
    cum.push(cum[i-1] + Math.hypot(b[0]-a[0], b[1]-a[1]));
  }
  return { pts, cum, len: cum[cum.length-1] };
}

/* Nearest distance from a point to the path polyline, plus which
   segment it was — used for the ground texture blend, for keeping trees
   off the path, and for placing specimen trees beside it. */
function distToPath(path, x, z){
  let best = 1e9, bi = 0, bt = 0;
  const P = path.pts, n = P.length;
  for(let i = 0; i < n; i++){
    const a = P[i], b = P[(i+1)%n];
    const dx = b[0]-a[0], dz = b[1]-a[1];
    const L2 = dx*dx + dz*dz;
    let t = L2 > 0 ? ((x-a[0])*dx + (z-a[1])*dz)/L2 : 0;
    t = t < 0 ? 0 : (t > 1 ? 1 : t);
    const px = a[0] + dx*t, pz = a[1] + dz*t;
    const d = (x-px)*(x-px) + (z-pz)*(z-pz);
    if(d < best){ best = d; bi = i; bt = t; }
  }
  return { d: Math.sqrt(best), i: bi, t: bt };
}

function pathPointAt(path, s){
  /* s in metres along the loop */
  const L = path.len;
  s = ((s % L) + L) % L;
  let lo = 0, hi = path.cum.length-1;
  while(lo < hi-1){
    const mid = (lo+hi)>>1;
    if(path.cum[mid] <= s) lo = mid; else hi = mid;
  }
  const a = path.pts[lo % path.pts.length], b = path.pts[(lo+1) % path.pts.length];
  const seg = path.cum[lo+1] - path.cum[lo] || 1;
  const t = (s - path.cum[lo]) / seg;
  const p = [a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t];
  const dir = V.norm([b[0]-a[0], 0, b[1]-a[1]]);
  return { p, dir, side: [-dir[2], 0, dir[0]] };   // side = perpendicular
}

/* ---- ground mesh ---------------------------------------------------- */
function buildGround(gl, path, sakuraSpots){
  const b = new Builder();
  const H = PARK.half, C = PARK.cell;
  const N = Math.round(H*2/C);
  const idx = [];
  const r = R.make(4242);

  for(let j = 0; j <= N; j++){
    idx.push([]);
    for(let i = 0; i <= N; i++){
      const x = -H + i*C, z = -H + j*C;
      const y = groundH(x, z);
      const nrm = groundN(x, z);
      const dp = distToPath(path, x, z);

      /* 1 on the path, 0 on the grass, smooth in between */
      const onPath = 1 - Math.min(1, Math.max(0,
        (dp.d - PARK.pathHalf) / PARK.pathEdge));

      /* grass colour, mottled so it is not a flat green carpet */
      const m  = fbm(x*0.09+3, z*0.09+9, 3);
      const m2 = fbm(x*0.31+50, z*0.31+20, 2);
      let col = [
        0.152 + m*0.058 + m2*0.024,
        0.252 + m*0.076 + m2*0.028,
        0.096 + m*0.038 + m2*0.016
      ];
      /* worn earth just off the edge of the path, where feet go */
      const wear = Math.max(0, 1 - Math.abs(dp.d - PARK.pathHalf - 0.4)/1.1) * 0.45;
      col = V.lerp(col, [0.255, 0.205, 0.145], wear);
      /* the path itself: pale warm gravel */
      const gravel = [0.620, 0.566, 0.468];
      col = V.lerp(col, V.scale(gravel, 0.9 + m2*0.22), onPath);

      /* fallen blossom under the cherries — a pale pink drift on the
         grass. Kept subtle: it should read as scattered petals caught in
         the grass, not as a painted pink circle. */
      let fall = 0;
      for(const s of sakuraSpots){
        const d = Math.hypot(x-s[0], z-s[1]);
        if(d < 5.0) fall = Math.max(fall, (1 - d/5.0) * (0.45 + fbm(x*0.8,z*0.8,2)*0.55));
      }
      col = V.lerp(col, [0.42, 0.31, 0.33], Math.min(0.34, fall*0.34));

      /* uv is world position, so the grain texture tiles across the
         whole park without a visible repeat at this scale */
      idx[j].push(b.vert([x,y,z], nrm, [x*0.52, z*0.52], col, 0));
    }
  }
  /* Winding matters: get it backwards and the whole ground is treated as
     facing away from you and culled, leaving you looking straight
     through the world at the sky below the horizon. */
  for(let j = 0; j < N; j++){
    for(let i = 0; i < N; i++){
      b.quad(idx[j][i], idx[j+1][i], idx[j+1][i+1], idx[j][i+1]);
    }
  }
  return b.build(gl);
}

/* ---- scattering -----------------------------------------------------
   Specimen trees first, spaced along the path so that walking it takes
   you past one after another. Then background trees to fill the park
   and hide its edges. Then undergrowth. */
function buildWorld(gl, tex){
  const r = R.make(20260824);
  const path = buildPath();
  const world = {
    path, trees: [], specimens: [], protos: {}, shrubs: [], instances: {}
  };

  /* --- prototypes. Three shapes per species so a grove is not a row
     of clones, plus one cheap version for the far background. --- */
  const keys = ['sakura','momiji','sugi','ginkgo','matsu'];
  for(const k of keys){
    world.protos[k] = {
      near: [0,1,2].map(i => growTree(gl, k, 900 + i*37 + k.length*13, 1.0)),
      far:  [0,1].map(i => growTree(gl, k, 5000 + i*91 + k.length*7, 0.52))
    };
  }
  world.shrubProto = [
    growShrub(gl, 11, 'azalea'),
    growShrub(gl, 23, 'azalea'),
    growShrub(gl, 37, 'bush'),
    growShrub(gl, 41, 'bush')
  ];

  const occupied = [];                       // [x, z, radius]
  const fits = (x, z, rad, minPath) => {
    if(Math.hypot(x,z) > PARK.half - 3) return false;
    if(distToPath(path, x, z).d < minPath) return false;
    for(const o of occupied){
      if(Math.hypot(x-o[0], z-o[1]) < rad + o[2]) return false;
    }
    return true;
  };

  /* --- specimen trees: the ones you can scan ---
     Placed alternately left and right of the path, roughly every 11
     metres of walking, at a distance where the tree is clearly beside
     the path rather than on it. */
  const order = ['sakura','momiji','sakura','ginkgo','sakura','matsu',
                 'sugi','sakura','momiji','ginkgo','sakura','matsu','sugi','momiji'];
  let side = 1;
  for(let i = 0; i < order.length; i++){
    const key = order[i];
    const s = (i + 0.5) * (path.len/order.length) + (r()-0.5)*3.5;
    const at = pathPointAt(path, s);
    /* How far off the path centre this specimen stands. Big trees need
       more room — you cannot put a metre-wide cedar trunk two metres
       from a footpath — but keep it inside reachOf() in 07_player.js, or
       the tree will never offer itself as you walk past. */
    const off = (key === 'sugi'   ? 5.2 :      // metre-wide trunk, needs room
                 key === 'momiji' ? 3.5 :      // small, sits close in
                 key === 'matsu'  ? 3.9 :      // also small; was too far out
                                    4.6) + r()*1.2;
    const x = at.p[0] + at.side[0]*off*side;
    const z = at.p[1] + at.side[2]*off*side;
    side = -side;
    const proto = world.protos[key].near[i % 3];
    if(!fits(x, z, proto.radius + 1.4, 2.6)) continue;
    occupied.push([x, z, proto.radius + 1.2]);
    const rec = {
      key, x, z, y: groundH(x,z),
      yaw: r()*6.283, scale: 0.92 + r()*0.20,
      proto, id: 'sp'+i, specimen: true
    };
    world.trees.push(rec);
    world.specimens.push(rec);
  }

  const sakuraSpots = world.trees.filter(t => t.key === 'sakura').map(t => [t.x, t.z]);

  /* --- background trees ---
     Density rises towards the edge of the park so the boundary is a
     wood rather than a wall, and you never see out of it. */
  for(let i = 0; i < 210; i++){
    const a  = r()*Math.PI*2;
    const rr = Math.pow(r(), 0.62) * (PARK.half - 4);
    const x = Math.cos(a)*rr, z = Math.sin(a)*rr;
    const edge = rr / PARK.half;
    /* cedars and pines dominate the outer belt; flowering trees stay
       near the path where you can reach them */
    const key = edge > 0.62
      ? (r() < 0.55 ? 'sugi' : (r() < 0.6 ? 'matsu' : 'ginkgo'))
      : R.pick(r, ['sakura','momiji','ginkgo','matsu','sugi']);
    const far = rr > 26 || r() < 0.35;
    const bank = far ? world.protos[key].far : world.protos[key].near;
    const proto = bank[Math.floor(r()*bank.length)];
    if(!fits(x, z, proto.radius + 1.0, 4.2)) continue;
    occupied.push([x, z, proto.radius + 0.7]);
    world.trees.push({
      key, x, z, y: groundH(x,z),
      yaw: r()*6.283, scale: 0.78 + r()*0.42,
      proto, specimen: false
    });
  }

  /* --- shrubs: clumps, not a sprinkle. Real planting is in groups. --- */
  for(let c = 0; c < 46; c++){
    const a = r()*Math.PI*2, rr = Math.pow(r(),0.7)*(PARK.half-8);
    const cx = Math.cos(a)*rr, cz = Math.sin(a)*rr;
    const kind = r() < 0.55 ? 0 : 2;
    for(let k = 0; k < 3 + Math.floor(r()*5); k++){
      const x = cx + (r()-0.5)*5.5, z = cz + (r()-0.5)*5.5;
      if(!fits(x, z, 1.0, 2.2)) continue;
      occupied.push([x, z, 0.85]);
      world.shrubs.push({
        proto: world.shrubProto[kind + (r()<0.5?0:1)],
        x, z, y: groundH(x,z), yaw: r()*6.283, scale: 0.7 + r()*0.6
      });
    }
  }

  world.ground = buildGround(gl, path, sakuraSpots);

  /* One flat disc, lying in the grass. It is moved to whichever tree the
     prompt is asking about, so a single instance is all we ever need. */
  const hb = new Builder();
  hb.card([0,0,0], [1,0,0], [0,0,1], [1,1,1], 0, [0,0],[1,1], [0,1,0]);
  world.haloMesh = hb.build(gl);
  world.haloMesh.setInstances(new Float32Array([0,-999,0, 0,1, 1,1,1, 0]));

  /* --- instance buffers ---
     Everything of the same species and shape is drawn in one call, with
     a list of positions. Drawing 90 cedars separately would cost 90
     conversations with the graphics card; this way it costs one. */
  const groups = new Map();
  for(const t of world.trees){
    if(!groups.has(t.proto)) groups.set(t.proto, []);
    groups.get(t.proto).push(t);
  }
  world.treeGroups = [];
  for(const [proto, list] of groups){
    const data = new Float32Array(list.length * 9);
    list.forEach((t, i) => {
      const o = i*9;
      data[o]=t.x; data[o+1]=t.y; data[o+2]=t.z;
      data[o+3]=t.yaw; data[o+4]=t.scale;
      /* Small per-tree colour variation. Without it a grove of the same
         prototype is instantly readable as copies. */
      const v = 0.90 + (i*0.618 % 1)*0.20;
      data[o+5]=v; data[o+6]=v*(0.97+((i*0.31)%1)*0.08); data[o+7]=v*0.96;
      data[o+8]=(i*2.399)%6.283;
    });
    proto.branch.setInstances(data);
    proto.foliage.setInstances(data);
    world.treeGroups.push(proto);
  }

  const shrubGroups = new Map();
  for(const s of world.shrubs){
    if(!shrubGroups.has(s.proto)) shrubGroups.set(s.proto, []);
    shrubGroups.get(s.proto).push(s);
  }
  world.shrubGroups = [];
  for(const [proto, list] of shrubGroups){
    const data = new Float32Array(list.length*9);
    list.forEach((s,i)=>{
      const o=i*9;
      data[o]=s.x; data[o+1]=s.y; data[o+2]=s.z;
      data[o+3]=s.yaw; data[o+4]=s.scale;
      const v = 0.86 + (i*0.618%1)*0.28;
      data[o+5]=v; data[o+6]=v*1.02; data[o+7]=v*0.94;
      data[o+8]=(i*1.77)%6.283;
    });
    proto.branch.setInstances(data);
    proto.foliage.setInstances(data);
    world.shrubGroups.push(proto);
  }

  /* --- ground cover ---
     One tuft mesh, instanced thousands of times. Thinned near the path
     (feet wear it away) and inside the wood (too dark underneath). */
  const tuft = new Builder();
  for(let i = 0; i < 3; i++){
    const a = i/3*Math.PI + 0.4;
    tuft.card([0, 0.17, 0], [Math.cos(a)*0.22, 0, Math.sin(a)*0.22],
              [0, 0.17, 0], [1,1,1], 0.55, [0,0],[1,1],
              [Math.sin(a), 0.35, -Math.cos(a)]);
  }
  world.grass = tuft.build(gl);
  const gdata = [];
  /* Grass only near the path. Beyond about thirty metres it is behind
     trees and inside the haze, so it costs a great deal and shows
     almost nothing. */
  for(let i = 0; i < 30000; i++){
    const a = r()*Math.PI*2, rr = Math.sqrt(r())*(PARK.half-2);
    const x = Math.cos(a)*rr, z = Math.sin(a)*rr;
    const dp = distToPath(path, x, z).d;
    if(dp < PARK.pathHalf + 0.35 || dp > 30) continue;
    if(dp < PARK.pathHalf + 1.4 && r() < 0.6) continue;
    const v = 0.80 + r()*0.30;
    gdata.push(x, groundH(x,z) - 0.05, z, r()*6.283, 0.72 + r()*0.55,
               v*0.96, v, v*0.88, r()*6.283);
  }
  world.grass.setInstances(new Float32Array(gdata));

  const fl = new Builder();
  fl.card([0,0.16,0], [0.16,0,0], [0,0.16,0], [1,1,1], 0.6, [0,0],[1,1], [0,0.4,1]);
  fl.card([0,0.16,0], [0,0,0.16], [0,0.16,0], [1,1,1], 0.6, [0,0],[1,1], [1,0.4,0]);
  world.flowers = fl.build(gl);
  const fdata = [];
  const palette = [[1,1,0.96],[1,0.92,0.62],[0.95,0.80,0.92],[0.85,0.88,1],[1,0.86,0.84]];
  for(let i = 0; i < 3000; i++){
    const a = r()*Math.PI*2, rr = Math.sqrt(r())*(PARK.half-6);
    const x = Math.cos(a)*rr, z = Math.sin(a)*rr;
    const dpf = distToPath(path, x, z).d;
    if(dpf < PARK.pathHalf + 0.9 || dpf > 24) continue;
    /* clumped: flowers grow where other flowers already are */
    if(fbm(x*0.14+70, z*0.14+13, 2) < 0.05 && r() < 0.85) continue;
    const c = palette[Math.floor(r()*palette.length)];
    fdata.push(x, groundH(x,z), z, r()*6.283, 0.55 + r()*0.6,
               c[0], c[1], c[2], r()*6.283);
  }
  world.flowers.setInstances(new Float32Array(fdata));

  return world;
}

/* ---- things that move ----------------------------------------------
   Petals, butterflies and birds share one mechanism: a small mesh, and
   an instance buffer rewritten every frame from plain JavaScript. A few
   hundred instances is nothing to upload, and it keeps the motion in
   readable code rather than buried in a shader. */
function buildCritters(gl){
  const petalM = new Builder();
  petalM.card([0,0,0], [0.05,0,0], [0,0,0.05], [1,1,1], 0, [0,0],[1,1], [0,1,0]);
  const petal = petalM.build(gl);

  const flyM = new Builder();
  /* two wings, hinged at the middle, folded slightly so the flap reads
     from any angle */
  flyM.card([-0.075,0,0], [0.075,0,0], [0,0.02,0.085], [1,1,1], 0, [0,0],[0.5,1], [0,1,0]);
  flyM.card([ 0.075,0,0], [0.075,0,0], [0,0.02,0.085], [1,1,1], 0, [0.5,0],[1,1], [0,1,0]);
  const fly = flyM.build(gl);

  const birdM = new Builder();
  birdM.card([0,0,0], [0.34,0,0], [0,0,0.34], [1,1,1], 0, [0,0],[1,1], [0,1,0]);
  const bird = birdM.build(gl);

  const r = R.make(777);
  const petals = [];
  for(let i = 0; i < 520; i++){
    petals.push({
      x: (r()-0.5)*80, y: r()*11 + 0.4, z: (r()-0.5)*80,
      vy: -0.30 - r()*0.35, ph: r()*6.283, sp: 0.6 + r()*0.9,
      sz: 0.7 + r()*0.7, spin: (r()-0.5)*2.4
    });
  }
  const flies = [];
  for(let i = 0; i < 34; i++){
    flies.push({
      hx: (r()-0.5)*70, hz: (r()-0.5)*70, r: 2 + r()*6,
      ph: r()*6.283, sp: 0.30 + r()*0.45, hy: 0.7 + r()*1.4,
      sz: 0.85 + r()*0.5, tint: r() < 0.35 ? [1,1,1] : [1,0.95,0.8]
    });
  }
  const birds = [];
  for(let i = 0; i < 14; i++){
    birds.push({
      cx: (r()-0.5)*60, cz: (r()-0.5)*60, r: 12 + r()*22,
      ph: r()*6.283, sp: 0.10 + r()*0.10, y: 16 + r()*16, sz: 0.8 + r()*0.7
    });
  }
  return {
    petal, fly, bird, petals, flies, birds,
    petalData: new Float32Array(petals.length*9),
    flyData:   new Float32Array(flies.length*9),
    birdData:  new Float32Array(birds.length*9)
  };
}

function updateCritters(c, t, wind, focus){
  /* `focus` is the tree the prompt is pointing at, or null. A few
     butterflies drift over to it — a living arrow, rather than a label. */
  c.pull = c.pull === undefined ? 0 : c.pull;
  c.pull += ((focus ? 1 : 0) - c.pull) * 0.028;
  if(focus){ c.fx = focus[0]; c.fz = focus[2]; }
  let d = c.petalData;
  c.petals.forEach((p, i) => {
    /* Fall, but not straight down: a petal is a tiny wing, so it slips
       sideways and rocks as it drops. Two sine waves at different rates
       give that without simulating any actual aerodynamics. */
    p.y += p.vy * 0.016;
    const sway = Math.sin(t*p.sp + p.ph);
    if(p.y < 0.02){ p.y = 9 + Math.random()*4; p.x = (Math.random()-0.5)*80; p.z = (Math.random()-0.5)*80; }
    const o = i*9;
    d[o]   = p.x + sway*1.5 + t*wind*0.35;
    d[o+1] = p.y;
    d[o+2] = p.z + Math.cos(t*p.sp*0.8 + p.ph)*1.2;
    d[o+3] = t*p.spin + p.ph;
    d[o+4] = p.sz;
    d[o+5] = 1; d[o+6] = 1; d[o+7] = 1;
    d[o+8] = 0;
  });
  c.petal.setInstances(d);

  d = c.flyData;
  c.flies.forEach((f, i) => {
    /* A wandering ellipse, plus a bob. Butterflies do not fly in
       straight lines and it is very obvious when they do. */
    const a = t*f.sp + f.ph;
    /* the first six are the ones that go and gather at the marked tree */
    const k = (i < 6 && c.fx !== undefined) ? c.pull * (1 - i*0.06) : 0;
    const hx = f.hx + (c.fx - f.hx) * k;
    const hz = f.hz + (c.fz - f.hz) * k;
    const rr = f.r * (1 - k*0.72);
    const x = hx + Math.cos(a)*rr + Math.sin(a*2.3)*1.4*(1-k*0.6);
    const z = hz + Math.sin(a*0.8)*rr*0.8 + Math.cos(a*1.7)*1.2*(1-k*0.6);
    const y = groundH(x,z) + f.hy + Math.sin(a*3.1)*0.35 + k*0.5;
    const o = i*9;
    d[o]=x; d[o+1]=y; d[o+2]=z;
    d[o+3] = -a*0.8 + Math.PI/2;
    /* wing flap folded into the scale — cheap, and at this size it
       reads perfectly well as flapping */
    d[o+4] = f.sz * (0.62 + Math.abs(Math.sin(t*9 + f.ph))*0.55);
    d[o+5]=f.tint[0]; d[o+6]=f.tint[1]; d[o+7]=f.tint[2];
    d[o+8]=0;
  });
  c.fly.setInstances(d);

  d = c.birdData;
  c.birds.forEach((b, i) => {
    const a = t*b.sp + b.ph;
    const o = i*9;
    d[o]   = b.cx + Math.cos(a)*b.r;
    d[o+1] = b.y + Math.sin(a*1.7)*1.6;
    d[o+2] = b.cz + Math.sin(a)*b.r;
    d[o+3] = -a + Math.PI/2;
    d[o+4] = b.sz * (0.75 + Math.abs(Math.sin(t*4.5 + b.ph))*0.45);
    d[o+5]=1; d[o+6]=1; d[o+7]=1;
    d[o+8]=0;
  });
  c.bird.setInstances(d);
}
