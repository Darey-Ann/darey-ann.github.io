/* =====================================================================
   09 — THE SCHEMATIC

   The sakura has 200 rendered plates. The other four do not, so their
   lifecycle is drawn live: an ink figure that grows as you move the
   slider. This is the same fallback the Arborality app already has, and
   it is labelled as a schematic on screen so nothing is passed off as a
   render.

   The trick that makes it grow SMOOTHLY rather than in jumps is that no
   branch ever appears from nothing. Each branch order has a birth time,
   and when its moment comes its length eases up from zero — the same
   idea as the `birth` attribute in the Blender node group.
   ===================================================================== */

const SCHEM = {
  momiji: { levels:6, ang:0.98, lenF:0.74, base:0.30, wob:0.34, taper:0.62,
            ink:'#2c2a25', tip:'#584f42',
            leafCol:['#6a9b4e','#84b45f','#a8563f'], leafR:0.20, leafN:9, spread:1.0 },
  sugi:   { conifer:true, ink:'#3a2a1e', tip:'#5c4633',
            leafCol:['#3d5c38','#4a6c42','#334d30'] },
  ginkgo: { levels:5, ang:0.46, lenF:0.70, base:0.46, wob:0.20, taper:0.66,
            ink:'#33302a', tip:'#5e574a',
            leafCol:['#98b45c','#a8c069','#c8c25a'], leafR:0.17, leafN:8, spread:0.62 },
  matsu:  { levels:5, ang:0.88, lenF:0.72, base:0.34, wob:0.62, taper:0.60,
            ink:'#1f1d1b', tip:'#4a4038',
            leafCol:['#2f4a2c','#3c5c34','#243d24'], leafR:0.26, leafN:6, spread:1.15,
            pads:true },
  sakura: { levels:6, ang:0.60, lenF:0.72, base:0.56, wob:0.26, taper:0.58,
            ink:'#17130f', tip:'#3e332b',
            leafCol:['#f4c6d8','#fbe0ea','#e9a8c4'], leafR:0.19, leafN:10, spread:1.0 }
};

function smoothstep(a, b, x){
  const t = Math.max(0, Math.min(1, (x-a)/(b-a)));
  return t*t*(3-2*t);
}

/* Draw one tree into a 2D context.
   t     0..1 through the species' lifespan
   decay 0..1 how far into decline (thins the crown, greys the tips) */
function drawSchematic(g, W, H, key, t, layout){
  const sp = LIB[key], S = SCHEM[key];
  const r0 = 8000 + key.length*911;

  g.clearRect(0, 0, W, H);

  /* When the device supplies a layout, the figure uses the same ground
     line and the same metre scale as the ruler beside it — so a tree
     drawn at 16.7 m actually reaches the 16.7 m mark. Without one (the
     collection thumbnails) it falls back to filling its own box. */
  const groundY  = layout ? layout.groundY  : H*0.955;
  const usable   = layout ? layout.availH   : H*0.86;
  const rulerMax = layout ? layout.rulerMax : sp.maxH * 1.10;
  const left     = layout ? layout.left     : 0;
  const realH    = lerpTable(sp.heightByYear, t*sp.lifespan);
  const px = usable * (realH/rulerMax);         // the tree's height in pixels

  /* decline: the last stage of every species is a retreat of some kind */
  const lastY = sp.stages[sp.stages.length-1].y;
  const prevY = sp.stages[sp.stages.length-2].y;
  const decay = smoothstep(prevY, lastY*1.06, t*sp.lifespan);

  /* ground line and a little hatching, matching the app's plate */
  g.strokeStyle = 'rgba(141,132,113,0.85)';
  g.lineWidth = 1;
  const gx0 = left + (W-left)*0.04, gx1 = W - (W-left)*0.04;
  g.beginPath(); g.moveTo(gx0, groundY); g.lineTo(gx1, groundY); g.stroke();
  g.strokeStyle = 'rgba(141,132,113,0.34)';
  for(let i = 0; i < 22; i++){
    const x = gx0 + i*((gx1-gx0)/22);
    g.beginPath(); g.moveTo(x, groundY); g.lineTo(x - 7, groundY + 8); g.stroke();
  }

  if(px < 1.5) return;
  const cx = left + (W - left)/2;

  /* ---- conifers get their own routine: one leader, side branches that
     shorten with height. A recursive splitter cannot make that shape. */
  if(S.conifer){
    const r = R.make(r0);
    const w0 = Math.max(1.4, px*0.035);
    g.strokeStyle = S.ink; g.lineWidth = w0; g.lineCap = 'round';
    g.beginPath(); g.moveTo(cx, groundY); g.lineTo(cx, groundY - px); g.stroke();
    const whorls = Math.max(3, Math.round(6 + t*22));
    for(let i = 0; i < whorls; i++){
      const f = 0.10 + (i/whorls)*0.86;
      const y = groundY - px*f;
      /* length falls off with height — this is the cone */
      let L = px * 0.40 * Math.pow(1 - f*0.86, 1.25);
      /* an old, broken-crowned tree loses its regular taper near the top */
      if(decay > 0 && f > 0.72) L *= (1 - decay*0.55);
      if(L < 2) continue;
      for(const s of [-1, 1]){
        const droop = 0.18 + r()*0.16;
        g.strokeStyle = S.ink;
        g.lineWidth = Math.max(0.7, w0*0.32*(1-f*0.5));
        g.beginPath();
        g.moveTo(cx, y);
        g.quadraticCurveTo(cx + s*L*0.6, y + L*droop*0.4, cx + s*L, y + L*droop);
        g.stroke();
        /* Foliage as short paired strokes fanning off the shoot, rather
           than a stack of ellipses — a cedar branchlet is feathery, and
           blobs read as a bush. */
        const n = Math.max(3, Math.round(L*0.42));
        g.lineCap = 'round';
        for(let k = 0; k < n; k++){
          const q = 0.10 + (k/n)*0.90;
          const fx = cx + s*L*q, fy = y + L*droop*q*q;
          const sp = L*0.15*(1 - q*0.40);
          g.strokeStyle = S.leafCol[k % S.leafCol.length];
          g.lineWidth = Math.max(0.6, w0*0.16);
          g.globalAlpha = 0.72 + r()*0.28;
          for(const side of [-1, 1]){
            g.beginPath();
            g.moveTo(fx, fy);
            g.quadraticCurveTo(fx + s*sp*0.30, fy + side*sp*0.55,
                               fx + s*sp*0.75, fy + side*sp);
            g.stroke();
          }
        }
        g.globalAlpha = 1;
      }
    }
    /* leading shoot */
    g.strokeStyle = S.tip; g.lineWidth = Math.max(0.8, w0*0.3);
    g.beginPath(); g.moveTo(cx, groundY-px); g.lineTo(cx, groundY-px-px*0.03); g.stroke();
    return;
  }

  /* ---- broadleaves: recursive, with birth times ---- */
  const r = R.make(r0);
  const foliage = [];

  function limb(x, y, ang, len, wid, depth){
    /* Has this order of branch been born yet, and how far along is it? */
    const born = S.base * (depth/(S.levels+1));
    const grow = smoothstep(born, born + 0.16, t);
    if(grow <= 0.001) return;
    const L = len * grow;
    if(L < 1.2) return;

    /* a slight bow, and more of it for the pine */
    const bow = (r()-0.5) * S.wob;
    const mx = x + Math.cos(ang - bow*0.5)*L*0.5;
    const my = y + Math.sin(ang - bow*0.5)*L*0.5;
    const ex = x + Math.cos(ang)*L;
    const ey = y + Math.sin(ang)*L;

    g.strokeStyle = depth < 2 ? S.ink : S.tip;
    g.lineWidth = Math.max(0.55, wid);
    g.lineCap = 'round';
    g.beginPath();
    g.moveTo(x, y);
    g.quadraticCurveTo(mx, my, ex, ey);
    g.stroke();

    if(depth >= S.levels){
      foliage.push([ex, ey, L, depth]);
      return;
    }
    /* Crown retreat: in the last stage the outermost order is shed
       from a growing share of the tree. */
    if(decay > 0.02 && depth >= S.levels-1 && r() < decay*0.75){
      foliage.push([ex, ey, L*0.5, depth]);      // a stub, no leaves
      return;
    }

    const kids = depth === 0 ? 3 : 2;
    for(let i = 0; i < kids; i++){
      const side = (i === 0 ? -1 : 1) * (kids === 3 && i === 2 ? 0.15 : 1);
      const a2 = ang + side*S.ang*(0.6 + r()*0.8) * S.spread;
      limb(ex, ey, a2, L*S.lenF*(0.82+r()*0.34), wid*S.taper, depth+1);
    }
  }

  limb(cx, groundY, -Math.PI/2 + (r()-0.5)*0.16, px*0.34, Math.max(1.6, px*0.040), 0);

  /* Leaves last, so they sit over the wood rather than under it. */
  const leafGrow = smoothstep(S.base*0.7, S.base*0.7+0.20, t);
  if(leafGrow > 0.01){
    for(const [x, y, L, d] of foliage){
      if(decay > 0.3 && r() < decay*0.5) continue;
      const n = S.leafN;
      for(let i = 0; i < n; i++){
        const a = r()*Math.PI*2, rad = L*(0.2 + r()*0.9);
        const fx = x + Math.cos(a)*rad, fy = y + Math.sin(a)*rad*0.8;
        g.fillStyle = S.leafCol[Math.floor(r()*S.leafCol.length)];
        g.globalAlpha = (0.62 + r()*0.34) * leafGrow;
        const rr = Math.max(0.9, L*S.leafR*(0.7+r()*0.7));
        if(S.pads){
          g.beginPath(); g.ellipse(fx, fy, rr*1.7, rr*0.62, (r()-0.5)*0.6, 0, 7); g.fill();
        } else {
          g.beginPath(); g.arc(fx, fy, rr, 0, 7); g.fill();
        }
      }
    }
    g.globalAlpha = 1;
  }
}

/* Vertical scale down the side of the plate, in metres. Same idea as
   the app's ruler: it is what tells you the tree is 3 m and not 9. */
function drawRuler(el, maxM, groundY, availH){
  /* Zero sits exactly on the ground rule and maxM at the height a
     full-grown tree reaches, so the scale and the specimen agree. */
  const step = [1,2,3,5,10,20].find(c => maxM/c <= 8) || 25;
  let html = '';
  for(let m = 0; m <= maxM + 0.001; m += step){
    const top = groundY - (m/maxM)*availH;
    html += `<i class="maj" style="top:${top}px"></i>` +
            `<span style="top:${top}px">${m}&#8201;m</span>`;
  }
  el.innerHTML = html;
}
