/* =====================================================================
   10 — THE DEVICE

   A small state machine driving the camera back:
       menu  ->  scanning  ->  plate  ->  (collect)  ->  menu
                                   \-> collection
   The physical slider on the bottom plate is live only in the plate
   state, and it drives one number: t, the position through the tree's
   whole life. Everything on screen is a function of t.
   ===================================================================== */

/* STATE
   -------------------------------------------------------------------------
   open        is the device raised at all
   state       'menu' | 'scanning' | 'plate' | 'coll'
   tree        the tree in the world you are standing at
   sp          that tree's entry in LIB (08_data.js)
   t           0..1 through the species' whole life. THE central number:
               the plate, the year, the stage, the height, the note and
               the schematic are all functions of it
   sel         which menu row the keyboard is on
   playing     is the life running by itself
   collection  { speciesKey: {at, t} } — also mirrored to localStorage
   ------------------------------------------------------------------- */
const Device = {
  open:false, state:'menu', tree:null, sp:null,
  t:0, sel:0, playing:false, scanTimer:0,
  collection:{},          // key -> { at: 'Year n', t }
  plateImgs:null, plateLoaded:0,

  el:{}, cb:{},

  init(cb){
    this.cb = cb;
    const $ = id => document.getElementById(id);
    this.el = {
      wrap:$('deviceWrap'), screen:$('screen'), rail:$('rail'), thumb:$('thumb'),
      ticks:$('railTicks'), lo:$('railLo'), hi:$('railHi'), counter:$('counter'),
      lamp:$('lamp'), exitBtn:$('exitBtn'), playBtn:$('playBtn'), dialA:$('dialA'),
      tally:$('tallyN'), toast:$('toast')
    };

    /* restore a previous visit if the browser allows it */
    try{
      const s = localStorage.getItem('arborality.collection');
      if(s) this.collection = JSON.parse(s);
    }catch(e){ /* private window, or storage blocked — carry on */ }
    this.updateTally();

    this.bindRail();
    /* The corner button is always "put it away". It was a shutter before,
       which meant the one thing you always want to do had no button. */
    this.el.exitBtn.addEventListener('click', ()=> this.hide());
    this.el.playBtn.addEventListener('click', ()=>{
      if(this.state !== 'plate') return;
      if(this.t >= 0.999) this.setT(0);
      this.playing = !this.playing;
      this.syncPlay();
    });

    /* Start pulling the 200 plates into memory in the background. They
       are already inside this file as data, so there is no network
       involved — this is decode time only, and doing it up front means
       scrubbing the slider is instant later. */
    this.plateImgs = new Array(PLATE_COUNT);
    let i = 0;
    const step = () => {
      const budget = performance.now() + 8;      // stay under one frame
      while(i < PLATE_COUNT && performance.now() < budget){
        const img = new Image();
        img.onload = () => { this.plateLoaded++; this.updateCounter(); };
        img.src = PLATES[i];
        this.plateImgs[i] = img;
        i++;
      }
      if(i < PLATE_COUNT) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  },

  /* ---- the slider ---------------------------------------------------
     One pointer handler for mouse, pen and touch alike. */
  bindRail(){
    const r = this.el.rail;
    const set = e => {
      const b = r.getBoundingClientRect();
      const x = (e.clientX - b.left) / b.width;
      this.setT(Math.max(0, Math.min(1, x)));
      this.playing = false;
    };
    let down = false;
    r.addEventListener('pointerdown', e => {
      down = true; r.setPointerCapture(e.pointerId); set(e); e.preventDefault();
    });
    r.addEventListener('pointermove', e => { if(down) set(e); });
    r.addEventListener('pointerup',   e => { down = false; try{ r.releasePointerCapture(e.pointerId); }catch(_){} });
    r.addEventListener('pointercancel', () => { down = false; });
  },

  setT(v){
    this.t = v;
    this.el.thumb.style.left = (v*100) + '%';
    if(this.state === 'plate') this.paint();
  },

  syncPlay(){
    const b = this.el.playBtn;
    const live = this.state === 'plate';
    b.disabled = !live;
    b.innerHTML = (live && this.playing) ? '&#10073;&#10073;' : '&#9654;';
    b.title = (live && this.playing) ? 'Pause' : 'Play the lifecycle';
  },

  /* ---- opening and closing ---- */
  show(tree){
    this.open = true;
    this.tree = tree;
    this.sp = LIB[tree.key];
    this.state = 'menu';
    this.sel = 0;
    this.t = 0;
    this.playing = false;
    this.el.wrap.classList.add('on');
    this.el.rail.classList.add('off');
    this.el.lamp.classList.remove('on');
    this.syncPlay();
    this.paint();
  },
  hide(){
    this.open = false;
    this.playing = false;
    this.el.wrap.classList.remove('on');
    this.el.lamp.classList.remove('on');
    if(this.cb.onClose) this.cb.onClose();
  },

  beginScan(){
    if(this.state !== 'menu') return;
    this.state = 'scanning';
    this.scanTimer = performance.now();
    this.el.lamp.classList.add('on');
    if(this.cb.onScan) this.cb.onScan();
    this.paint();
  },

  toPlate(){
    this.state = 'plate';
    this.el.lamp.classList.remove('on');
    this.el.rail.classList.remove('off');
    this.el.lo.textContent = 'seed';
    this.el.hi.textContent = this.sp.lifespan + ' yrs';
    this.buildTicks();
    this.setT(0);
    this.playing = true;              // run the life once, automatically
    this.syncPlay();
    this.paint();
  },

  buildTicks(){
    const sp = this.sp;
    let html = '';
    for(const st of sp.stages){
      const p = (st.y/sp.lifespan)*100;
      html += `<i class="maj" style="left:${p}%"></i>`;
    }
    for(let i = 0; i <= 20; i++) html += `<i style="left:${i*5}%"></i>`;
    html += `<span style="left:2%">0</span><span style="left:98%">${sp.lifespan}</span>`;
    this.el.ticks.innerHTML = html;
  },

  updateCounter(){
    if(this.state === 'plate' && this.sp.plates){
      this.el.counter.textContent =
        String(plateForT(this.t)).padStart(3,'0') + ' / ' + PLATE_COUNT;
    } else if(this.plateLoaded < PLATE_COUNT){
      this.el.counter.textContent = String(this.plateLoaded).padStart(3,'0') + ' / ' + PLATE_COUNT;
    } else {
      this.el.counter.textContent = 'ready';
    }
  },

  /* ---- the frame tick, called from the main loop ---- */
  tick(dt){
    if(!this.open) return;
    this.el.dialA.style.transform = 'rotate(' + (this.t*300) + 'deg)';
    if(this.state === 'scanning'){
      /* Wall clock, not accumulated frame deltas — on a slow machine the
         deltas are clamped and the scan would never finish. */
      if(performance.now() - this.scanTimer > 1900) this.toPlate();
      return;
    }
    if(this.state === 'plate' && this.playing){
      /* Play the life through once. Slower early on, because that is
         where all the visible change happens. */
      const rate = 0.055 + this.t*0.10;
      this.setT(Math.min(1, this.t + dt*rate));
      if(this.t >= 1){ this.playing = false; this.syncPlay(); }
    }
  },

  key(code){
    if(!this.open) return false;
    if(code === 'Escape'){
      if(this.state === 'menu') this.hide();
      else { this.back(); }
      return true;
    }
    if(code === 'Backspace' && this.state !== 'menu'){ this.back(); return true; }
    if(this.state === 'menu'){
      const n = 3;
      if(code === 'ArrowDown'){ this.sel = (this.sel+1)%n; this.paint(); return true; }
      if(code === 'ArrowUp'){ this.sel = (this.sel+n-1)%n; this.paint(); return true; }
      if(code === 'Enter' || code === 'Space'){ this.choose(this.sel); return true; }
    }
    if(this.state === 'plate'){
      if(code === 'ArrowLeft'){ this.playing=false; this.setT(Math.max(0, this.t-0.02)); return true; }
      if(code === 'ArrowRight'){ this.playing=false; this.setT(Math.min(1, this.t+0.02)); return true; }
      if(code === 'Space'){ this.playing = !this.playing; this.syncPlay(); return true; }
      if(code === 'Enter'){ this.collect(); return true; }
    }
    if(this.state === 'coll' && (code === 'Enter' || code === 'Space')){
      this.state = 'menu'; this.paint(); return true;
    }
    return true;      // swallow everything while the device is up
  },

  back(){
    this.state = 'menu';
    this.el.rail.classList.add('off');
    this.playing = false;
    this.syncPlay();
    this.paint();
  },

  choose(i){
    if(i === 0) this.beginScan();
    else if(i === 1){ this.state = 'coll'; this.el.rail.classList.add('off'); this.paint(); }
    else this.hide();
  },

  collect(){
    if(this.state !== 'plate') return;
    const k = this.sp.key;
    if(this.collection[k]){ this.toast('already in the collection'); return; }
    this.collection[k] = { at: 'Yr ' + Math.round(this.t*this.sp.lifespan), t: this.t };
    try{ localStorage.setItem('arborality.collection', JSON.stringify(this.collection)); }catch(e){}
    this.updateTally();
    this.toast(this.sp.common + ' added to the collection');
    if(this.cb.onCollect) this.cb.onCollect(k);
    this.paint();
  },

  /* Empty the collection and forget the saved copy, so a reset survives
     a reload rather than coming back the moment the page reopens. */
  clearCollection(){
    this.collection = {};
    try{ localStorage.removeItem('arborality.collection'); }catch(e){ /* storage blocked */ }
    this.updateTally();
    if(this.open) this.paint();
  },

  updateTally(){
    const n = Object.keys(this.collection).length;
    if(this.el.tally) this.el.tally.textContent = n;
  },

  toast(msg){
    const t = this.el.toast;
    t.textContent = msg;
    t.classList.add('on');
    clearTimeout(this._tt);
    this._tt = setTimeout(()=> t.classList.remove('on'), 2200);
  },

  /* ---- drawing the screen ------------------------------------------- */
  paint(){
    const s = this.el.screen;
    if(this.state === 'menu')      s.innerHTML = this.menuHTML();
    else if(this.state === 'scanning') s.innerHTML = this.scanHTML();
    else if(this.state === 'plate')    this.paintPlate(s);
    else if(this.state === 'coll'){ s.innerHTML = this.collHTML(); s.dataset.mode = 'coll'; }
    if(this.state !== 'plate') s.dataset.mode = this.state;
    this.wire();
    if(this.state === 'coll') requestAnimationFrame(paintCollectionThumbs);
    this.updateCounter();
  },

  wire(){
    const s = this.el.screen;
    s.querySelectorAll('[data-act]').forEach(el => {
      el.addEventListener('click', () => {
        const a = el.dataset.act;
        if(a === 'scan') this.beginScan();
        else if(a === 'coll'){ this.state='coll'; this.el.rail.classList.add('off'); this.paint(); }
        else if(a === 'exit') this.hide();
        else if(a === 'back') this.back();
        else if(a === 'add') this.collect();
        else if(a === 'play'){ this.playing = !this.playing; this.syncPlay(); }
        else if(a === 'stage'){ this.playing=false; this.setT(Number(el.dataset.t)); }
      });
    });
  },

  menuHTML(){
    const sp = this.sp;
    const got = !!this.collection[sp.key];
    const items = [
      ['01','Scan this tree', got ? 'catalogued — look again' : 'read its whole life', 'scan', got],
      ['02','The collection', Object.keys(this.collection).length + ' of 5 catalogued', 'coll', false],
      ['03','Put it away',    'back to the path', 'exit', false]
    ];
    return `<div class="menu">
      <div class="eyebrow">specimen in frame</div>
      <h2>A <em>${sp.common.toLowerCase().replace('somei-yoshino','sakura')}</em>, most likely.</h2>
      <div class="binom">${sp.binomial}</div>
      <div class="jp">${sp.japanese} · ${sp.romaji}</div>
      <div class="mlist">
        ${items.map((it,i)=>`
          <button class="mitem ${i===this.sel?'sel':''} ${it[4]?'done':''}" data-act="${it[3]}">
            <span class="no">${it[0]}</span>
            <span class="lbl">${it[1]}</span>
            <span class="sub">${it[2]}</span>
            <span class="arw">&rarr;</span>
          </button>`).join('')}
      </div>
    </div>`;
  },

  scanHTML(){
    return `<div class="scanning">
      <div class="reticle-box"><i></i><i></i><i></i><i></i><div class="sweep"></div></div>
      <div class="scan-meta">
        <div class="line">determining specimen</div>
        <div class="det">${this.sp.binomial}</div>
        <div class="line" style="opacity:.55">leaf &middot; bark &middot; habit &middot; silhouette</div>
      </div>
    </div>`;
  },

  /* ---- plate layout ------------------------------------------------
     These numbers are the app's, not new ones. The plates share a single
     crop box that is the union of every frame's bounding box — and the
     early frames were shot from close up, so their crowns reach far
     higher in the frame than the mature tree's does. The result is that
     a full-grown tree only fills the middle 76.5% of its plate's height
     and 90.5% of its width; the rest is transparent margin. Sizing the
     plate as though the tree filled it is exactly the mistake that left
     the tree looking a quarter too small. */
  PLATE_GEOM: { RULER_W: 38, GROUND_PAD: 22, TOP_PAD: 10,
                CROWN_H_PCT: 76.50, CROWN_W_PCT: 90.54, W: 556, H: 700 },

  /* ---- laying the plate out ----------------------------------------
     This is the fiddliest arithmetic in the project, so, step by step.

     The field is the clear window you look through. Inside it:

       groundY   where the ground line sits, GROUND_PAD up from the bottom
       availH    the height on screen of a FULLY GROWN tree of this
                 species. Everything is measured against this, which is
                 why the metre scale and the specimen always agree

     For the sakura, the plate is a photograph of a render, and three
     numbers govern how big to draw it:

       scale        this tree's real height now, as a fraction of the top
                    of the metre scale. A 6 m cherry against a 12 m scale
                    draws at half size
       CROWN_H_PCT  the fully-grown tree only fills the middle 76.5% of
                    its plate's height. All 200 plates share one crop box,
                    and that box is the union of every frame's bounding
                    box — including early frames shot close up, whose
                    crowns reach much higher in frame than the mature
                    tree's does. Sizing the plate as though the tree
                    filled it leaves the tree about a quarter too small
       CROWN_W_PCT  the same again for width, so a full crown clears the
                    metre scale instead of running underneath it

     Then the anchor. The Blender camera pulls BACK as the tree grows, so
     the foot of the trunk is not in the same place in every plate — it
     drifts from 36% to 54% across the sequence. ANCHORS says where it is
     in each one, and pinning that point to (centre of field, ground line)
     is what stops the tree sliding sideways as you drag the slider.

     For the other four species there is no plate, so drawSchematic is
     handed the same groundY, availH and scale and draws to them instead.
     ------------------------------------------------------------------- */
  paintPlate(s){
    const sp = this.sp;
    const years = this.t * sp.lifespan;
    const si = stageIndexOf(sp, this.t);
    const st = sp.stages[si];
    const realH = lerpTable(sp.heightByYear, years);
    const got = !!this.collection[sp.key];
    const G = this.PLATE_GEOM;

    /* Rebuild the frame only when the species changes; otherwise just
       update the parts that move. Rewriting the whole panel on every
       slider pixel would throw the images away and flicker. */
    if(s.dataset.mode !== 'plate' || s.dataset.key !== sp.key){
      s.dataset.mode = 'plate'; s.dataset.key = sp.key;
      s.innerHTML = `
      <div class="plate-view">
        <div class="pv-left">
          <div class="pv-head">
            <div>
              <div class="pno" id="pvNo">Plate I</div>
              <div class="st" id="pvSt">&mdash;</div>
            </div>
            <div class="yr" id="pvYr">yr 0</div>
          </div>
          <div class="pv-stage" id="pvStage">
            <div class="pv-ruler" id="pvRuler"></div>
            <div class="pv-veil" id="pvVeil"></div>
            ${sp.plates
              ? `<img id="pvImg" alt="rendered specimen">`
              : `<canvas id="pvCv"></canvas><div class="schem-tag">schematic</div>`}
            <div class="pv-ground" id="pvGround"></div>
          </div>
          <div class="pv-cap">
            <span id="pvFig">Fig. 1</span><em id="pvH">0.0 m</em>
          </div>
          <div class="pv-chain" id="pvChain">
            ${sp.stages.map((x,i)=>`<button data-act="stage" data-t="${(x.y/sp.lifespan).toFixed(4)}" data-i="${i}">${x.name}<br><span style="opacity:.6">${x.y} yr</span></button>`).join('')}
          </div>
          <div class="pv-actions">
            <button class="btn ghost" data-act="back">&larr; Back</button>
            <span class="spacer"></span>
            <button class="btn" data-act="add" id="pvAdd">Add to collection</button>
          </div>
        </div>
        <div class="pv-right">
          <div class="entry-no">No. ${sp.no}</div>
          <div class="entry-common">${sp.common}</div>
          <div class="entry-binom">${sp.binomial}</div>
          <div class="entry-alt">${sp.japanese} &middot; ${sp.also}</div>
          <div class="entry-fam">${sp.family}</div>
          <div class="side-head">Note &middot; this stage</div>
          <div class="note" id="pvNote"></div>
          <div class="side-head">Description</div>
          <dl class="facts">${sp.facts.map(f=>`<dt>${f[0]}</dt><dd>${f[1]}</dd>`).join('')}</dl>
          <div class="side-head">Where it grows</div>
          <p class="body-t">${sp.habitat}</p>
          <p class="remark">${sp.remark}</p>
        </div>
      </div>`;
      this.wire();
    }

    const q = id => s.querySelector('#'+id);
    q('pvNo').textContent  = 'Plate ' + ['I','II','III','IV','V','VI'][si];
    q('pvSt').textContent  = st.name + ' \u00b7 ' + st.tag;
    q('pvYr').textContent  = 'yr ' + Math.round(years);
    q('pvFig').textContent = 'Fig. ' + (si+1) + ' \u2014 ' + st.fig;
    q('pvH').textContent   = realH.toFixed(1) + ' m';
    q('pvNote').innerHTML  = st.fact +
      (st.src ? `<br><a href="${st.src.href}" target="_blank" rel="noopener">${st.src.label} &rarr;</a>` : '');
    const add = q('pvAdd');
    if(add){ add.disabled = got; add.textContent = got ? 'In the collection' : 'Add to collection'; }
    s.querySelectorAll('#pvChain button').forEach((b,i)=> b.classList.toggle('on', i===si));

    const stage  = q('pvStage');
    const stageH = stage.clientHeight, stageW = stage.clientWidth;
    if(!stageH || !stageW) return;

    /* One geometry for the ruler, the plate and the schematic, so all
       three are reading the same metre scale. */
    const groundY  = stageH - G.GROUND_PAD;
    const availH   = groundY - G.TOP_PAD;      // screen height of a full-grown tree
    const rulerMax = sp.rulerMax;
    q('pvGround').style.top = groundY + 'px';
    drawRuler(q('pvRuler'), rulerMax, groundY, availH);

    /* The pool of light is placed from the same numbers as the specimen,
       so it follows the tree as it grows instead of sitting in a fixed
       spot. figW/figH are filled in by whichever branch runs below. */
    const veil = q('pvVeil');
    const placeVeil = (fx, fBase, fW, fH) => {
      /* The pool must stay WIDER than the field it sits in. Shrink it to
         hug the tree and the edge of the ellipse lands inside the visible
         area, where it stops reading as light and starts reading as a
         box with a soft edge. Size is fixed; only the density changes. */
      const w2 = Math.max(90, fW*2.3), h2 = Math.max(80, fH*1.5);
      veil.style.left   = (fx - w2/2) + 'px';
      veil.style.top    = (fBase - fH*0.62 - h2/2) + 'px';
      veil.style.width  = w2 + 'px';
      veil.style.height = h2 + 'px';
      /* The rendered plates need a denser pool than the schematics do.
         A schematic is solid ink and holds its own against anything; the
         sakura render is fine branches and pale blossom, exactly the sort
         of thing a sunlit park behind it swallows whole. Same three
         stops in the same places either way — only the numbers move. */
      const c = sp.plates
        ? ['0.94', '0.62']
        : ['0.74', '0.46'];
      veil.style.background =
        'radial-gradient(ellipse at 50% 50%,' +
        ' rgba(247,244,236,' + c[0] + ') 0%,' +
        ' rgba(247,244,236,' + c[1] + ') 44%,' +
        ' rgba(247,244,236,0) 74%)';
    };

    if(sp.plates){
      const n = plateForT(this.t);
      const img = this.plateImgs[n-1];
      const el = q('pvImg');
      if(img && img.src && el.src !== img.src) el.src = img.src;

      /* scale = this tree's real height against the top of the ruler, so
         the plate and the metre scale beside it agree */
      const scale = realH / rulerMax;
      let fullH = availH / (G.CROWN_H_PCT/100);
      const fullW = fullH * (G.W/G.H) * (G.CROWN_W_PCT/100);
      /* A tree is a portrait subject; a letterbox field strands it in
         the middle of nothing. Cap the field to a little wider than it
         is tall, as the app does. */
      const fieldW = Math.min(stageW - G.RULER_W, availH * 1.30);
      const maxW = fieldW - 14;
      if(fullW > maxW) fullH *= maxW/fullW;

      const h = fullH * scale;
      const w = h * (G.W/G.H);

      /* Pin the foot of the trunk. The Blender camera pulls back as the
         tree grows, so the trunk base drifts across the frame — ANCHORS
         says where it is in every plate, and pinning that point stops the
         tree sliding sideways as you scrub. */
      const a  = anchorFor(n);
      const cx = G.RULER_W + (stageW - G.RULER_W)/2;
      el.style.position = 'absolute';
      el.style.width  = w + 'px';
      el.style.height = h + 'px';
      el.style.maxWidth = 'none'; el.style.maxHeight = 'none';
      el.style.left = (cx - w*a[0]/100) + 'px';
      el.style.top  = (groundY - h*a[1]/100) + 'px';
      /* the tree occupies the middle 76.5% / 90.5% of the plate */
      placeVeil(cx, groundY, w*0.905, h*0.765);

      /* The renders stop at a healthy mature tree — there is no dieback
         frame and no snag frame. Decline is drawn as the plate losing its
         colour and then most of its presence. */
      const dying = si >= 5, aging = si === 4;
      let fade = 0;
      if(aging){
        const a0 = sp.stages[4].y/sp.lifespan, a1 = sp.stages[5].y/sp.lifespan;
        fade = Math.max(0, Math.min(1, (this.t - a0)/(a1 - a0)));
      }
      /* A soft dark shadow, so dark branches read against bright sky and
         pale blossom reads against a dark trunk — the same trick a
         sticker uses to sit on any background. */
      const halo = ' drop-shadow(0 2px 6px rgba(20,16,10,0.55))';
      el.style.filter = (dying ? 'grayscale(0.9) contrast(0.8) brightness(1.08)'
                       : aging ? 'saturate(' + (1 - 0.45*fade).toFixed(2) + ')' : '') + halo;
      el.style.opacity = dying ? '0.46' : (aging ? (1 - 0.14*fade).toFixed(2) : '1');
    } else {
      const cv = q('pvCv');
      const dpr = Math.min(2, window.devicePixelRatio||1);
      if(cv.width !== Math.round(stageW*dpr)){
        cv.width = Math.round(stageW*dpr); cv.height = Math.round(stageH*dpr);
      }
      const g = cv.getContext('2d');
      g.setTransform(dpr,0,0,dpr,0,0);
      drawSchematic(g, stageW, stageH, sp.key, this.t,
                    { groundY, availH, rulerMax, left: G.RULER_W });
      const figH = availH * (realH/rulerMax);
      placeVeil(G.RULER_W + (stageW - G.RULER_W)/2, groundY, figH*0.95, figH);
    }
    this.updateCounter();
  },

  collHTML(){
    const cards = LIB_ORDER.map(k => {
      const sp = LIB[k], got = this.collection[k];
      if(!got) return `<div class="card empty">
          <div class="cno">No. ${sp.no}</div>
          <div class="cthumb">not yet catalogued</div>
          <h3>—</h3><div class="cb">&nbsp;</div><div class="cd">&nbsp;</div>
        </div>`;
      return `<div class="card">
          <div class="cno">No. ${sp.no}</div>
          <div class="cthumb"><canvas class="cthumbcv" data-k="${k}" data-t="${got.t}"></canvas></div>
          <h3>${sp.common}</h3>
          <div class="cb">${sp.binomial}</div>
          <div class="cd">${sp.japanese} · catalogued ${got.at}</div>
        </div>`;
    }).join('');
    return `<div class="coll">
      <div class="coll-head">
        <div><div class="eyebrow">field notes</div><h2>The collection</h2></div>
        <div class="eyebrow">${Object.keys(this.collection).length} / 5</div>
      </div>
      <div class="coll-grid">${cards}</div>
      <div class="coll-foot">
        <span class="eyebrow">five species along this path</span>
        <button class="btn ghost" data-act="back">Back</button>
      </div>
    </div>`;
  }
};

/* Collection thumbnails are drawn after the markup lands, because they
   need to know how big their box turned out to be. */
function paintCollectionThumbs(){
  document.querySelectorAll('.cthumbcv').forEach(cv => {
    const k = cv.dataset.k, t = Number(cv.dataset.t);
    const dpr = Math.min(2, window.devicePixelRatio||1);
    const W = cv.clientWidth || 150, H = cv.clientHeight || 82;
    cv.width = Math.round(W*dpr); cv.height = Math.round(H*dpr);
    const g = cv.getContext('2d');
    g.setTransform(dpr,0,0,dpr,0,0);
    drawSchematic(g, W, H, k, Math.max(0.45, t));
  });
}
