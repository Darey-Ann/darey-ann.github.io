/* =====================================================================
   06 — THE RENDERER

   Each frame is drawn three times over:
     1. from the sun, recording only depth        -> the shadow map
     2. from your eyes, into an off-screen buffer -> the scene
     3. a few flat passes over that buffer        -> glow, shafts, grade

   Step 1 is what puts leaf-shaped shadows on the ground. Step 3 is what
   puts the light shafts in the air. Together they are komorebi.
   ===================================================================== */

/* Late-afternoon sun, about fourteen degrees above the horizon.
   Everything about the look of this scene follows from that one number:
   long shadows, warm light, and a low angle that rakes THROUGH the canopy
   instead of coming down onto it.

   Raise SUN_ELEV towards 90 and you get midday — short shadows, flat
   light, no komorebi to speak of. Lower it towards 0 and the shadows
   stretch out of the shadow map's reach and the whole park goes orange.
   SUN_AZI is the compass direction, and only decides which way the
   shadows lie. */
const SUN_ELEV = 14.5 * Math.PI/180;
const SUN_AZI  = 128 * Math.PI/180;

const LOOK = {
  sunDir: V.norm([
    Math.cos(SUN_ELEV)*Math.cos(SUN_AZI),
    Math.sin(SUN_ELEV),
    Math.cos(SUN_ELEV)*Math.sin(SUN_AZI)
  ]),
  /* Colours here are LINEAR and unbounded — the sun is far brighter than
     white, and saying so is what lets highlights bloom instead of simply
     clipping to a flat white blob. The tone-mapping pass at the end
     brings the range back onto a screen.

     Direct sunlight, redder than white because at fourteen degrees the
     light is coming through a great deal of atmosphere. */
  sunCol:  [3.55, 2.18, 1.12],
  /* Ambient light has two halves. Surfaces facing up catch skyCol, which
     is blue because that is what the sky is; surfaces facing down catch
     gndCol, warm light bounced off the grass. Without this split,
     everything in shadow goes uniformly flat. */
  skyCol:  [0.218, 0.268, 0.372],
  gndCol:  [0.128, 0.115, 0.074],
  /* Distance haze. fogCol is what a thing very far away fades TO, and
     fogDens is how fast it gets there — raise it and the park closes in
     around you, lower it and you can see the far edge of the world. */
  fogCol:  [0.248, 0.216, 0.180],
  fogDens: 0.0118,
  /* The sky gradient, top and bottom. */
  zenith:  [0.150, 0.290, 0.560],
  horizon: [0.815, 0.578, 0.378],
  /* Post-processing. exposure is the master brightness applied before
     tone mapping; bloom is how much the bright parts bleed; rays is the
     strength of the shafts through the canopy. */
  exposure: 1.05,
  bloom: 0.34,
  rays: 0.30,
  /* How far the twig tips travel in the breeze, in metres. Small numbers
     only — the sway is multiplied up towards the tips of every branch. */
  wind: 0.055
};

/* A handful of knobs can be overridden from the address bar
   (?exp=1.2&fog=0.006&bloom=0&rays=0). Purely for tuning — it costs
   nothing and it saved a great deal of rebuilding. */
(function(){
  try{
    const q = new URLSearchParams(location.search);
    const num = (k, f) => { if(q.has(k)) LOOK[f] = parseFloat(q.get(k)); };
    num('exp','exposure'); num('fog','fogDens'); num('bloom','bloom');
    num('rays','rays'); num('wind','wind');
  }catch(e){}
})();

class Renderer {
  constructor(canvas){
    const gl = canvas.getContext('webgl2', {
      /* No MSAA: the scene is drawn into an off-screen buffer, so the
         context's own antialiasing would only smooth the one fullscreen
         triangle at the end — pure cost, no benefit. */
      antialias: false, alpha: false, powerPreference: 'high-performance',
      preserveDrawingBuffer: false
    });
    if(!gl) throw new Error('WebGL2 not available');
    this.gl = gl;
    this.canvas = canvas;

    /* Half-float render targets let the scene hold values above 1.0,
       which is what makes bloom look like light rather than like a
       blurred white smear. Not every machine offers it, so we check and
       fall back to plain 8-bit if it is missing. */
    this.hdr = !!gl.getExtension('EXT_color_buffer_half_float') ||
               !!gl.getExtension('EXT_color_buffer_float');
    gl.getExtension('OES_texture_float_linear');

    this.pWorld  = program(gl, VS_COMMON, FS_WORLD,     'world');
    this.pDepth  = program(gl, VS_COMMON, FS_DEPTH,     'depth');
    this.pSky    = program(gl, VS_FULL,   FS_SKY,       'sky');
    this.pBright = program(gl, VS_FULL,   FS_BRIGHT,    'bright');
    this.pBlur   = program(gl, VS_FULL,   FS_BLUR,      'blur');
    this.pRays   = program(gl, VS_FULL,   FS_RAYS,      'rays');
    this.pComp   = program(gl, VS_FULL,   FS_COMPOSITE, 'composite');
    this.pGlow   = program(gl, VS_COMMON, FS_GLOW,      'glow');

    this.quad = fullscreenVAO(gl);
    this.shadowSize = 1792;
    this.shadow = new DepthRT(gl, this.shadowSize);
    this.rtScene = new RT(gl, 2, 2, { depth:true, float:this.hdr });
    this.rtA = new RT(gl, 2, 2, { float:this.hdr });
    this.rtB = new RT(gl, 2, 2, { float:this.hdr });
    this.rtR = new RT(gl, 2, 2, { float:this.hdr });

    /* 1 = full, 0.5 = lighter, 0 = lightest. Drops automatically when
       frames get slow; `pinned` means the viewer chose a level by hand
       and we stop second-guessing them. */
    this.quality = 1;
    this.pinned = false;
    this.frameMs = 16;
    this.halo = { x:0, y:0, z:0, a:0, r:2.4 };
  }

  setQuality(q, pin){
    if(q === this.quality){ if(pin) this.pinned = true; return; }
    this.quality = q;
    if(pin) this.pinned = true;
    const size = q === 1 ? 1792 : (q === 0.5 ? 1280 : 1024);
    if(size !== this.shadowSize){
      this.shadowSize = size;
      this.shadow = new DepthRT(this.gl, size);
    }
    this.canvas.width = 0;        // force a resize on the next frame
    this.frameMs = 16;
  }

  resize(){
    const gl = this.gl;
    /* Cap the pixel ratio. A 3x retina display asks for nine times the
       pixels of a 1x one, and this scene is fill-rate bound. */
    const dpr = Math.min(window.devicePixelRatio || 1,
                         this.quality === 1 ? 1.35 : (this.quality === 0.5 ? 1.0 : 0.78));
    const w = Math.max(2, Math.round(this.canvas.clientWidth  * dpr));
    const h = Math.max(2, Math.round(this.canvas.clientHeight * dpr));
    if(this.canvas.width === w && this.canvas.height === h) return;
    this.canvas.width = w; this.canvas.height = h;
    this.rtScene.resize(w, h);
    const qw = Math.max(2, w>>2), qh = Math.max(2, h>>2);
    this.rtA.resize(qw, qh);
    this.rtB.resize(qw, qh);
    this.rtR.resize(qw, qh);
  }

  /* ---- shadow volume ------------------------------------------------
     The sun's camera is an orthographic box that follows you around. It
     only needs to cover what you can actually see shadows on — about 30
     metres — which keeps the shadow map's resolution high enough that a
     single leaf casts a recognisable shadow rather than a grey blob. */
  lightMatrix(camPos, camFwd){
    const R = 24;
    /* Look slightly ahead of the player so the box is not half wasted
       behind them. */
    let cx = camPos[0] + camFwd[0]*9;
    let cz = camPos[2] + camFwd[2]*9;
    /* Snap the centre to whole shadow-map texels. Without this the map
       shifts by a fraction of a texel as you walk and every shadow edge
       crawls and shimmers. */
    const texelWorld = (R*2)/this.shadowSize;
    cx = Math.round(cx/texelWorld)*texelWorld;
    cz = Math.round(cz/texelWorld)*texelWorld;
    const centre = [cx, groundH(cx,cz) + 6, cz];
    const eye = V.add(centre, V.scale(LOOK.sunDir, 60));
    const view = M4.lookAt(eye, centre, [0,1,0]);
    const proj = M4.ortho(-R, R, -R, R, 1, 130);
    return M4.mul(proj, view);
  }

  /* One place that sets every per-material uniform, so a draw call
     elsewhere is a single readable line. */
  mat(p, o){
    const gl = this.gl;
    gl.uniform1f(p.u.u_useTex,        o.tex ? 1 : 0);
    gl.uniform1f(p.u.u_alphaCut,      o.cut !== undefined ? o.cut : 0);
    if(p.u.u_translucency) gl.uniform1f(p.u.u_translucency, o.trans || 0);
    if(p.u.u_gloss)        gl.uniform1f(p.u.u_gloss, o.gloss || 0);
    if(p.u.u_shadowStr)    gl.uniform1f(p.u.u_shadowStr, o.shadow === undefined ? 1 : o.shadow);
    if(o.tex){
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, o.tex);
      gl.uniform1i(p.u.u_tex, 0);
    }
    if(o.cull === false) gl.disable(gl.CULL_FACE); else gl.enable(gl.CULL_FACE);
  }

  /* Everything in the park, in one list, so the shadow pass and the
     main pass cannot drift out of step. */
  *sceneItems(world, crit, tex){
    yield { mesh: world.ground, tex: tex.ground, cut: 0, inst: false, cull: false, noShadow: true };
    for(const p of world.treeGroups){
      yield { mesh: p.branch, tex: tex.bark, cut: 0, inst: true, cull: true };
      yield { mesh: p.foliage, tex: tex[p.form.leaf.tex], cut: 0.34, inst: true,
              cull: false, trans: p.form.trans, gloss: p.form.gloss, foliage: true };
    }
    for(const p of world.shrubGroups){
      yield { mesh: p.branch, tex: tex.bark, cut: 0, inst: true, cull: true };
      yield { mesh: p.foliage, tex: p.kind === 'azalea' ? tex.azalea : tex.shrub,
              cut: 0.42, inst: true, cull: false, trans: 0.95, gloss: 0.06, foliage: true };
    }
    yield { mesh: world.grass,   tex: tex.grass,  cut: 0.36, inst: true, cull: false, trans: 1.1 };
    yield { mesh: world.flowers, tex: tex.flower, cut: 0.42, inst: true, cull: false, trans: 0.8 };
    yield { mesh: crit.petal,    tex: tex.petal,  cut: 0.40, inst: true, cull: false, trans: 1.4, noShadow: true };
    yield { mesh: crit.fly,      tex: tex.fly,    cut: 0.40, inst: true, cull: false, trans: 1.2, noShadow: true };
    yield { mesh: crit.bird,     tex: tex.bird,   cut: 0.40, inst: true, cull: false, noShadow: true };
  }

  render(world, crit, tex, cam, time){
    const gl = this.gl;
    const t0 = performance.now();
    this.resize();

    const aspect = this.canvas.width / this.canvas.height;
    const proj = M4.persp(cam.fov, aspect, 0.08, 300);
    const view = M4.lookAt(cam.pos, V.add(cam.pos, cam.fwd), [0,1,0]);
    const viewProj = M4.mul(proj, view);
    const lightVP = this.lightMatrix(cam.pos, cam.fwd);

    /* ---------- pass 1: the sun's view ---------- */
    this.shadow.bind();
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    /* Cull front faces while filling the shadow map. It moves the
       depth we store to the far side of each object, which pushes
       self-shadowing artefacts out of sight. */
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.FRONT);
    gl.useProgram(this.pDepth);
    gl.uniformMatrix4fv(this.pDepth.u.u_viewProj, false, lightVP);
    gl.uniformMatrix4fv(this.pDepth.u.u_lightVP, false, lightVP);
    gl.uniform1f(this.pDepth.u.u_time, time);
    gl.uniform1f(this.pDepth.u.u_wind, LOOK.wind);
    for(const it of this.sceneItems(world, crit, tex)){
      if(it.noShadow) continue;
      this.mat(this.pDepth, it);
      if(it.cull === false) gl.disable(gl.CULL_FACE);
      it.mesh.draw(it.inst);
    }
    gl.cullFace(gl.BACK);

    /* ---------- pass 2: your view ---------- */
    this.rtScene.bind();
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    /* sky first, with depth testing off — it is behind everything */
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    gl.useProgram(this.pSky);
    const invVP = invert4(viewProj);
    gl.uniformMatrix4fv(this.pSky.u.u_invVP, false, invVP);
    gl.uniform3fv(this.pSky.u.u_camPos, cam.pos);
    gl.uniform3fv(this.pSky.u.u_sunDir, LOOK.sunDir);
    gl.uniform3fv(this.pSky.u.u_sunCol, LOOK.sunCol);
    gl.uniform3fv(this.pSky.u.u_zenith, LOOK.zenith);
    gl.uniform3fv(this.pSky.u.u_horizon, LOOK.horizon);
    gl.uniform1f(this.pSky.u.u_time, time);
    gl.bindVertexArray(this.quad);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST);

    const p = this.pWorld;
    gl.useProgram(p);
    gl.uniformMatrix4fv(p.u.u_viewProj, false, viewProj);
    gl.uniformMatrix4fv(p.u.u_lightVP, false, lightVP);
    gl.uniform3fv(p.u.u_sunDir, LOOK.sunDir);
    gl.uniform3fv(p.u.u_sunCol, LOOK.sunCol);
    gl.uniform3fv(p.u.u_skyCol, LOOK.skyCol);
    gl.uniform3fv(p.u.u_gndCol, LOOK.gndCol);
    gl.uniform3fv(p.u.u_camPos, cam.pos);
    gl.uniform3fv(p.u.u_fogCol, LOOK.fogCol);
    gl.uniform1f(p.u.u_fogDens, LOOK.fogDens);
    gl.uniform1f(p.u.u_time, time);
    gl.uniform1f(p.u.u_wind, LOOK.wind);
    gl.uniform1f(p.u.u_texel, 1/this.shadowSize);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, this.shadow.tex);
    gl.uniform1i(p.u.u_shadow, 1);

    for(const it of this.sceneItems(world, crit, tex)){
      this.mat(p, it);
      it.mesh.draw(it.inst);
    }

    /* ---- the marker ring at the foot of the tree in question ----
       Drawn last of the solid pass, added rather than lit, and with depth
       WRITING off so grass in front of it still occludes it while it does
       not occlude anything itself. */
    if(this.halo.a > 0.003){
      this._haloData = this._haloData || new Float32Array(9);
      const hd = this._haloData;
      hd[0]=this.halo.x; hd[1]=this.halo.y+0.06; hd[2]=this.halo.z;
      hd[3]=0; hd[4]=this.halo.r;
      hd[5]=1.0; hd[6]=0.90; hd[7]=0.68; hd[8]=0;
      world.haloMesh.setInstances(hd);
      gl.useProgram(this.pGlow);
      gl.uniformMatrix4fv(this.pGlow.u.u_viewProj, false, viewProj);
      gl.uniformMatrix4fv(this.pGlow.u.u_lightVP, false, lightVP);
      gl.uniform1f(this.pGlow.u.u_time, time);
      gl.uniform1f(this.pGlow.u.u_wind, 0);
      gl.uniform3fv(this.pGlow.u.u_camPos, cam.pos);
      /* a slow breath, so it reads as alive rather than as a decal */
      gl.uniform1f(this.pGlow.u.u_fade, this.halo.a * (0.34 + Math.sin(time*1.9)*0.08));
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, tex.halo);
      gl.uniform1i(this.pGlow.u.u_tex, 0);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
      gl.depthMask(false);
      gl.disable(gl.CULL_FACE);
      world.haloMesh.draw(true);
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }

    /* ---------- pass 3: light ---------- */
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);
    gl.bindVertexArray(this.quad);

    /* isolate the bright parts */
    this.rtA.bind();
    gl.useProgram(this.pBright);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.rtScene.tex);
    gl.uniform1i(this.pBright.u.u_src, 0);
    gl.uniform1f(this.pBright.u.u_thresh, this.hdr ? 1.05 : 0.72);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    /* Where is the sun on screen? Push a point a long way along the sun
       direction and project it. If it lands behind the camera there are
       no shafts to draw. */
    const sunWorld = V.add(cam.pos, V.scale(LOOK.sunDir, 900));
    const sp = M4.xformPoint(viewProj, sunWorld);
    const sunOnScreen = sp[3] > 0;
    const sunUV = [sp[0]*0.5+0.5, sp[1]*0.5+0.5];
    /* fade the shafts out as the sun leaves the frame, or they pop */
    const off = Math.max(Math.abs(sunUV[0]-0.5), Math.abs(sunUV[1]-0.5));
    const rayAmt = (sunOnScreen && this.quality === 1)
      ? LOOK.rays * Math.max(0, 1 - Math.max(0, off - 0.5)/0.75) : 0;

    if(rayAmt > 0){
      this.rtR.bind();
      gl.useProgram(this.pRays);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.rtA.tex);
      gl.uniform1i(this.pRays.u.u_src, 0);
      gl.uniform2fv(this.pRays.u.u_sunUV, sunUV);
      gl.uniform1f(this.pRays.u.u_density, 0.66);
      gl.uniform1f(this.pRays.u.u_decay,   0.958);
      gl.uniform1f(this.pRays.u.u_weight,  0.021);
      gl.uniform1f(this.pRays.u.u_expo,    1.0);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }

    /* blur the bright layer: across, then down */
    gl.useProgram(this.pBlur);
    this.rtB.bind();
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.rtA.tex);
    gl.uniform1i(this.pBlur.u.u_src, 0);
    gl.uniform2f(this.pBlur.u.u_dir, 1.6/this.rtA.w, 0);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    this.rtA.bind();
    gl.bindTexture(gl.TEXTURE_2D, this.rtB.tex);
    gl.uniform2f(this.pBlur.u.u_dir, 0, 1.6/this.rtB.h);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    /* ---------- to the screen ---------- */
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.useProgram(this.pComp);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.rtScene.tex);
    gl.uniform1i(this.pComp.u.u_scene, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.rtA.tex);
    gl.uniform1i(this.pComp.u.u_bloom, 1);
    gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, rayAmt > 0 ? this.rtR.tex : this.rtA.tex);
    gl.uniform1i(this.pComp.u.u_rays, 2);
    gl.uniform1f(this.pComp.u.u_bloomAmt, LOOK.bloom);
    gl.uniform1f(this.pComp.u.u_rayAmt, rayAmt);
    gl.uniform1f(this.pComp.u.u_exposure, LOOK.exposure);
    gl.uniform1f(this.pComp.u.u_time, time);
    gl.uniform1f(this.pComp.u.u_vignette, 0.42);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.bindVertexArray(null);

    /* Rolling frame time. If the machine is struggling we quietly drop
       resolution, shadow detail and the shafts rather than stuttering. */
    const wall = t0 - (this._last || t0); this._last = t0;
    if(wall > 0 && wall < 400) this.frameMs = this.frameMs*0.93 + wall*0.07;
    if(this.quality === 1 && this.frameMs > 27 && !this.pinned){
      this.setQuality(0.5);
    } else if(this.quality === 0.5 && this.frameMs > 40 && !this.pinned){
      this.setQuality(0);
    }
  }
}

/* General 4x4 inverse. Only needed once a frame, to turn a screen pixel
   back into a direction for the sky. */
function invert4(m){
  const o = new Float32Array(16);
  const a00=m[0],a01=m[1],a02=m[2],a03=m[3], a10=m[4],a11=m[5],a12=m[6],a13=m[7],
        a20=m[8],a21=m[9],a22=m[10],a23=m[11], a30=m[12],a31=m[13],a32=m[14],a33=m[15];
  const b00=a00*a11-a01*a10, b01=a00*a12-a02*a10, b02=a00*a13-a03*a10,
        b03=a01*a12-a02*a11, b04=a01*a13-a03*a11, b05=a02*a13-a03*a12,
        b06=a20*a31-a21*a30, b07=a20*a32-a22*a30, b08=a20*a33-a23*a30,
        b09=a21*a32-a22*a31, b10=a21*a33-a23*a31, b11=a22*a33-a23*a32;
  let det = b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06;
  if(!det) return M4.ident();
  det = 1/det;
  o[0]=(a11*b11-a12*b10+a13*b09)*det;  o[1]=(a02*b10-a01*b11-a03*b09)*det;
  o[2]=(a31*b05-a32*b04+a33*b03)*det;  o[3]=(a22*b04-a21*b05-a23*b03)*det;
  o[4]=(a12*b08-a10*b11-a13*b07)*det;  o[5]=(a00*b11-a02*b08+a03*b07)*det;
  o[6]=(a32*b02-a30*b05-a33*b01)*det;  o[7]=(a20*b05-a22*b02+a23*b01)*det;
  o[8]=(a10*b10-a11*b08+a13*b06)*det;  o[9]=(a01*b08-a00*b10-a03*b06)*det;
  o[10]=(a30*b04-a31*b02+a33*b00)*det; o[11]=(a21*b02-a20*b04-a23*b00)*det;
  o[12]=(a11*b07-a10*b09-a12*b06)*det; o[13]=(a00*b09-a01*b07+a02*b06)*det;
  o[14]=(a31*b01-a30*b03-a32*b00)*det; o[15]=(a20*b03-a21*b01+a22*b00)*det;
  return o;
}
