/* =====================================================================
   08 — WHAT THE DEVICE KNOWS

   The sakura entry is lifted straight out of the Arborality app so the
   two cannot disagree: same binomial, same six stages, same notes, same
   height curve, same 200 plates.

   The other four are new, and their lifecycles are drawn as schematics
   rather than rendered — which is exactly what the app already does
   when the plate folder is missing. Nothing here is presented as a
   Blender render that isn't one.
   ===================================================================== */

/* THE SHAPE OF AN ENTRY
   -------------------------------------------------------------------------
   no            catalogue number, shown on the plate and the collection card
   key           must match the key used in SPECIES_FORM (04_trees.js), so
                 the 3D tree you walked up to and the entry you are reading
                 are the same species
   plates        true  -> the lifecycle is the 200 Blender renders
                 false -> it is drawn live by drawSchematic (09_schematic.js)
                 and labelled SCHEMATIC on screen
   lifespan      years the slider spans, left to right
   maxH          full height in metres. Sets the top of the metre scale
   heightByYear  [[year, metres], ...] — the growth curve. For the sakura
                 this is the curve that decides WHICH PLATE you see at any
                 point on the slider, so it is not decoration
   stages        six entries: y (the year it begins), name, tag, fig, a
                 sourced fact, and an optional src {href, label}
   facts         the description table down the right-hand side
   habitat       where it grows, in prose
   remark        the one thing worth knowing, in italics at the bottom

   To add a sixth species: add an entry here, add a matching entry to
   SPECIES_FORM in 04_trees.js and to SCHEM in 09_schematic.js, add its
   key to LIB_ORDER below, and add it to the `order` list in buildWorld
   (05_world.js) so one actually stands beside the path.
   ------------------------------------------------------------------- */
const LIB = {

  sakura: {
    no:'001', key:'sakura', plates:true,
    common:'Somei-Yoshino', binomial:'Prunus × yedoensis',
    japanese:'染井吉野', romaji:'Somei-yoshino',
    also:'Yoshino cherry · Tokyo cherry', family:'Rosaceae',
    lifespan:60, maxH:11.4, rulerMax:12,
    habitat:'A garden hybrid, not a wild plant. It arose in the nursery village of Somei, on the edge of Edo, in the mid-1800s, and is now the street and park cherry of Japan and of the Washington DC Tidal Basin. It wants full sun, deep, moist, well-drained soil and room for its roots — three things a pavement pit rarely gives it.',
    remark:'Every Somei-Yoshino on earth is a cutting from one original tree. That is why a whole avenue of them opens on the same day: they are not merely the same variety, they are the same individual.',
    facts:[
      ['Parentage','Edo-higan × Oshima-zakura'],
      ['Height','9–15 m, spread about as wide'],
      ['Flower','Pink in bud, white open, 3.5 cm, 5–6 per cluster'],
      ['Bloom','Late March – April, before the leaves, ~8 days'],
      ['Fruit','Small drupe, red then black; seed rarely viable'],
      ['Hardiness','USDA zone 5'],
      ['Street life','40–80 yrs (avg 57); 100+ yrs in a good park']
    ],
    heightByYear:[[0,0.3],[3,1.6],[6,3.2],[10,5.2],[16,7.6],[24,9.3],[32,10.4],[42,11.2],[52,11.4],[60,11.4]],
    stages:[
      {y:0,  name:'Seedling',    tag:'Establishing', fig:'germination',
       fact:'Street sakura almost never start from seed. Somei-Yoshino barely sets viable seed at all — every tree is grafted or struck from a cutting, which is why an avenue of them opens on the same day.'},
      {y:3,  name:'Sapling',     tag:'First bloom',  fig:'first bloom',
       fact:'Because it is propagated from an already-adult tree rather than raised from seed, a young Somei-Yoshino can flower within two or three years of going into the ground.'},
      {y:8,  name:'Young Tree',  tag:'Rapid growth', fig:'rapid growth',
       fact:"This is the fast stretch — roughly half a metre of height a year. Most of the tree's final size is laid down in its first two decades, then growth flattens out."},
      {y:16, name:'Mature',      tag:'Peak bloom',   fig:'full crown',
       fact:'A mature cherry can host hundreds of other species over its lifetime — insects, birds, fungi and epiphytes — as habitat, not just as food.'},
      {y:36, name:'Declining',   tag:'Crown dieback',fig:'dieback',
       fact:'Compacted soil pushes the roots shallow, where they are easily wounded. Wood-decay fungi get in through those wounds and through pruning cuts, which cherries close slowly, and the upper crown starts to die back.'},
      {y:52, name:'End of Life', tag:'Removal',      fig:'standing snag',
       fact:'Japanese municipalities replace street cherries at an average of 57 years, with plans ranging from 40 to 80. The same clone in a well-kept park routinely passes 100 — the oldest recorded is around 146.'}
    ]
  },

  momiji: {
    no:'002', key:'momiji', plates:false,
    common:'Iroha-momiji', binomial:'Acer palmatum',
    japanese:'いろは紅葉', romaji:'Iroha-momiji',
    also:'Japanese maple · smooth Japanese maple', family:'Sapindaceae',
    lifespan:100, maxH:8.0, rulerMax:9,
    habitat:'An understorey tree of the warm-temperate forests of Japan, Korea and central China — it evolved beneath a canopy, which is why it scorches in full afternoon sun and thrives on the shaded side of a building. Moist, humus-rich, slightly acid soil; shelter from wind, which burns the leaf margins.',
    remark:'The name reads as a counting rhyme. The lobes of the leaf were once numbered off against i-ro-ha-ni-ho-he-to — the old Japanese alphabet song — one syllable per lobe.',
    facts:[
      ['Habit','Small, often several stems from the base'],
      ['Height','6–10 m, spreading as wide or wider'],
      ['Leaf','Palmate, 5–7 (rarely 9) lobes, 4–12 cm'],
      ['Flower','Small, red-purple, in drooping umbels, May'],
      ['Fruit','Paired samaras — the winged “helicopters”'],
      ['Autumn','Crimson to orange; colour is brightest after cool nights'],
      ['Age','Commonly 80–100 yrs; specimens well past 150']
    ],
    heightByYear:[[0,0.4],[5,1.8],[10,3.0],[20,4.8],[40,6.6],[70,7.6],[100,8.0]],
    stages:[
      {y:0,  name:'Seedling',   tag:'In shade',      fig:'germination',
       fact:'Maple seed needs a cold winter before it will germinate — a stratification requirement that stops it sprouting during a warm spell in autumn and dying in the first frost.'},
      {y:5,  name:'Sapling',    tag:'Layering',      fig:'first layers',
       fact:'The horizontal layering starts early. A maple builds itself in tiers with gaps between them, so light arrives underneath in sheets rather than as scattered dapple.'},
      {y:15, name:'Young Tree', tag:'First seed',    fig:'first samaras',
       fact:'The paired winged seeds spin as they fall. The autorotation slows the descent enough for a light wind to carry the seed clear of the parent’s own shade.'},
      {y:30, name:'Mature',     tag:'Full canopy',   fig:'full crown',
       fact:'Autumn colour is not decay. Chlorophyll withdraws to reveal carotenoids that were in the leaf all along, while the reds — anthocyanins — are made fresh, and only in some species.',
       src:{href:'https://www.fs.usda.gov/visit/fall-colors/science-of-fall-colors', label:'US Forest Service — Science of Fall Colors'}},
      {y:60, name:'Veteran',    tag:'Character',     fig:'gnarled',
       fact:'Old maples hollow at the heart without dying. The living tissue is a thin sleeve just under the bark; the heartwood inside it is already dead, so losing it costs the tree very little.'},
      {y:85, name:'Late Life',  tag:'Crown retreat', fig:'dieback',
       fact:'A declining maple gives up its outer crown first and keeps a smaller one closer in — retrenchment. Left alone, a tree can hold that reduced form for decades.'}
    ]
  },

  sugi: {
    no:'003', key:'sugi', plates:false,
    common:'Sugi', binomial:'Cryptomeria japonica',
    japanese:'杉', romaji:'Sugi',
    also:'Japanese cedar · Japanese redwood', family:'Cupressaceae',
    lifespan:400, maxH:35.0, rulerMax:38,
    habitat:'Endemic to Japan and planted the length of it. It wants deep, moist, well-drained soil and high rainfall, and it grows fastest on a sheltered lower slope. Enormous post-war plantations were established for timber and many were never thinned.',
    remark:'It is the national tree of Japan, and the source of the country’s worst allergy. The pollen released by those unthinned plantations each spring is the cause of kafunsho — hay fever — in a large share of the population.',
    facts:[
      ['Habit','A single straight trunk to the very tip'],
      ['Height','25–40 m; the tallest exceed 50 m'],
      ['Leaf','Awl-shaped, incurved, spiralled round the shoot'],
      ['Cone','Globose, ~2 cm, with 20–40 scales'],
      ['Bark','Red-brown, peeling in long vertical strips'],
      ['Wood','Light, straight-grained, fragrant; the standard timber'],
      ['Age','Centuries as a rule; millennia on Yakushima']
    ],
    heightByYear:[[0,0.4],[10,5.0],[25,13.0],[50,22.0],[100,29.0],[200,33.0],[400,35.0]],
    stages:[
      {y:0,   name:'Seedling',    tag:'Establishing', fig:'germination',
       fact:'Sugi seed germinates readily on bare mineral soil or on a rotting log. On Yakushima, where the granite holds little soil, the great trees very often began life on the corpse of an older one.'},
      {y:15,  name:'Sapling',     tag:'Racing up',    fig:'leader',
       fact:'A single leader runs straight to the tip and never gives way to a fork. That habit — excurrent growth — is what produces the cone; the side branches simply get shorter the higher they start.'},
      {y:50,  name:'Pole',        tag:'Canopy',       fig:'closing canopy',
       fact:'In an unthinned plantation the crowns close and the lower branches die for want of light. The trunks stay slender and the stand becomes vulnerable to snow and to windthrow.'},
      {y:120, name:'Mature',      tag:'Full stature', fig:'full crown',
       fact:'Growth in height slows long before growth in girth stops. An old sugi is putting on wood almost entirely as diameter — the same annual increment, spread round a much larger circumference.'},
      {y:250, name:'Ancient',     tag:'Crown broken', fig:'broken crown',
       fact:'A crown that has lost its leader to lightning or snow reiterates: side branches turn upward and each becomes a small tree in its own right. The silhouette stops being a cone.'},
      {y:340, name:'Yakusugi',    tag:'Beyond count', fig:'veteran',
       fact:'Jomon Sugi on Yakushima is the largest known, at about 25 m tall and 16 m round. Age estimates for it range from roughly 2,000 to over 7,000 years — the spread is that wide because the heartwood is hollow and cannot be counted.',
       src:{href:'https://en.wikipedia.org/wiki/J%C5%8Dmon_Sugi', label:'Jōmon Sugi'}}
    ]
  },

  ginkgo: {
    no:'004', key:'ginkgo', plates:false,
    common:'Icho', binomial:'Ginkgo biloba',
    japanese:'銀杏', romaji:'Ichō',
    also:'Ginkgo · maidenhair tree', family:'Ginkgoaceae',
    lifespan:300, maxH:28.0, rulerMax:30,
    habitat:'No confirmed wild population survives — every ginkgo alive is descended from trees kept by people, largely in Chinese temple grounds. It tolerates compacted soil, road salt, drought and polluted air better than almost any other tree, which is why it lines so many city streets.',
    remark:'It is the last of its kind. Every other member of its entire division died out; ginkgo is a single species with no living relatives, essentially unchanged in the fossil record for around 200 million years.',
    facts:[
      ['Habit','Upright, open, rather stiff when young'],
      ['Height','20–35 m'],
      ['Leaf','Fan-shaped, notched, with forking parallel veins'],
      ['Sex','Dioecious — separate male and female trees'],
      ['Seed','Fleshy coat; notoriously foul-smelling when it falls'],
      ['Autumn','Clear yellow, and often shed almost overnight'],
      ['Age','Routinely 1,000 yrs; the oldest claimed far exceed that']
    ],
    heightByYear:[[0,0.4],[10,4.0],[25,10.0],[50,17.0],[100,23.0],[200,27.0],[300,28.0]],
    stages:[
      {y:0,   name:'Seedling',    tag:'Establishing', fig:'germination',
       fact:'Ginkgo has no midrib. The veins fork in twos from the stalk and never rejoin — dichotomous venation, a pattern far older than the flowering plants and visible on 200-million-year-old fossils.'},
      {y:10,  name:'Sapling',     tag:'Ascending',    fig:'ascending',
       fact:'A young ginkgo is gawky: a few stiff ascending branches and long gaps between them. The rounded crown people picture only arrives after several decades.'},
      {y:30,  name:'Young Tree',  tag:'First seed',   fig:'first seed',
       fact:'It can take twenty to thirty years to first bear, and until then there is no reliable way to tell a male from a female. Street plantings are usually male grafts for exactly that reason.'},
      {y:70,  name:'Mature',      tag:'Full crown',   fig:'full crown',
       fact:'Ginkgo drops its leaves faster and more completely than almost any other tree — often most of the canopy within a day or two, leaving a clean yellow ring on the ground.'},
      {y:150, name:'Old',         tag:'Chichi',       fig:'chichi',
       fact:'Old ginkgos grow chichi — downward woody outgrowths from the branches, literally “breasts”. Where one reaches the ground it can root and prop the limb, and the tree effectively clones itself.'},
      {y:240, name:'Ancient',     tag:'Survivor',     fig:'veteran',
       fact:'Six ginkgos within about two kilometres of the Hiroshima hypocentre survived the 1945 bombing and are alive today. They are among the hibaku jumoku — the A-bombed trees — and several stand where the buildings around them did not.',
       src:{href:'https://www.ginkgo-cms.com/hibakujumoku/', label:'Hibakujumoku — the A-bombed trees'}}
    ]
  },

  matsu: {
    no:'005', key:'matsu', plates:false,
    common:'Kuromatsu', binomial:'Pinus thunbergii',
    japanese:'黒松', romaji:'Kuromatsu',
    also:'Japanese black pine', family:'Pinaceae',
    lifespan:250, maxH:20.0, rulerMax:22,
    habitat:'A coastal tree, and a tough one: it holds in sand, takes salt spray full in the face and stands up to wind that flattens everything around it. Long belts of it were planted the length of the Japanese coast as windbreaks and against blown sand.',
    remark:'It is the pine of the garden and the painted screen, and almost none of that shape is natural. The layered pads are made by hand — candles pinched out in spring, old needles pulled in autumn, every year, for decades.',
    facts:[
      ['Habit','Irregular, leaning, picturesque; rarely symmetrical'],
      ['Height','To 25–40 m wild; usually far less when tended'],
      ['Needle','In bundles of two, stiff and sharp, 6–12 cm'],
      ['Bud','Grey-white — the field mark against red pine'],
      ['Bark','Near-black, thick, breaking into deep plates'],
      ['Cone','Ovoid, 4–6 cm, ripening in the second year'],
      ['Threat','Pine wilt nematode, spread by a longhorn beetle']
    ],
    heightByYear:[[0,0.3],[10,3.0],[25,7.0],[50,12.0],[100,16.0],[180,19.0],[250,20.0]],
    stages:[
      {y:0,   name:'Seedling',   tag:'On sand',       fig:'germination',
       fact:'Black pine germinates on bare, poor, salty ground where almost nothing competes with it. Its advantage is not vigour — it is a tolerance for places other trees will not start in.'},
      {y:12,  name:'Sapling',    tag:'Candles',       fig:'candling',
       fact:'New growth comes as upright “candles” in spring, all of the year’s extension at once. Pinching a candle in half halves that year’s growth — the basis of every pruned garden pine.'},
      {y:30,  name:'Young Tree', tag:'Taking form',   fig:'form',
       fact:'The trunk begins to lean and kink. Nothing forces it; the leader is simply overtaken by a side shoot again and again, and each handover leaves a bend.'},
      {y:70,  name:'Mature',     tag:'Pads',          fig:'pads',
       fact:'Foliage gathers into flat pads with bare wood showing between them. In a garden that separation is cut in deliberately — the gaps are the design, not the branches.'},
      {y:140, name:'Old',        tag:'Plated bark',   fig:'plated',
       fact:'The bark thickens into deep near-black plates. It is fire protection: thick corky bark insulates the living tissue underneath long enough to survive a ground fire.'},
      {y:210, name:'Veteran',    tag:'Standing on',   fig:'veteran',
       fact:'A single black pine survived the 2011 tsunami at Rikuzentakata out of a coastal forest of some seventy thousand. It died of salt within two years and was preserved as a monument — the Miracle Pine.'}
    ]
  }
};

const LIB_ORDER = ['sakura','momiji','sugi','ginkgo','matsu'];

/* ---- the two curve helpers, exactly as the app defines them -------- */
function lerpTable(tbl, x){
  if(x <= tbl[0][0]) return tbl[0][1];
  for(let i=1;i<tbl.length;i++){
    if(x <= tbl[i][0]){
      const f = (x - tbl[i-1][0]) / (tbl[i][0] - tbl[i-1][0]);
      return tbl[i-1][1] + f*(tbl[i][1] - tbl[i-1][1]);
    }
  }
  return tbl[tbl.length-1][1];
}
function invertTable(tbl, y){
  if(y <= tbl[0][1]) return tbl[0][0];
  for(let i=1;i<tbl.length;i++){
    if(y <= tbl[i][1]){
      const f = (y - tbl[i-1][1]) / (tbl[i][1] - tbl[i-1][1]);
      return tbl[i-1][0] + f*(tbl[i][0] - tbl[i-1][0]);
    }
  }
  return tbl[tbl.length-1][0];
}

/* The plate sequence, and the curve that decides which plate you see.
   Both are the app's, unchanged. HEIGHT_CURVE was measured off the
   evaluated Blender depsgraph, not derived from the node group. */
const PLATE_COUNT = 200;
const HEIGHT_CURVE = [[0.000,0.54],[0.201,3.00],[0.402,6.33],[0.603,8.79],[0.804,10.50],[1.000,12.02]];
const RENDER_MAX_M = 12.02;

/* t (0..1 of a life) -> which of the 200 plates.
   Read the real height at that age, ask what fraction of full size that
   is, then ask the render's own measured curve which frame is that
   tall. Plates therefore get spent quickly in the fast early years and
   barely at all in the last decades, which is how a tree actually
   grows. */
function plateForT(t){
  const sp = LIB.sakura;
  const realH  = lerpTable(sp.heightByYear, t*sp.lifespan);
  const target = (realH / sp.maxH) * RENDER_MAX_M;
  const age    = invertTable(HEIGHT_CURVE, target);
  return Math.max(1, Math.min(PLATE_COUNT, 1 + Math.round(age*(PLATE_COUNT-1))));
}
/* Frame 1 is bare ground, so it has no anchor; borrow the first that
   does. ANCHORS itself is injected at build time from the app. */
function anchorFor(n){
  for(let i=n;i<=PLATE_COUNT;i++){ if(ANCHORS[i-1]) return ANCHORS[i-1]; }
  return [50,95];
}
function stageIndexOf(sp, t){
  const y = t * sp.lifespan;
  let k = 0;
  for(let i=0;i<sp.stages.length;i++) if(y >= sp.stages[i].y) k = i;
  return k;
}
