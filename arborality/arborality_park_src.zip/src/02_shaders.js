/* =====================================================================
   02 — SHADERS
   These are the small programs that run on the graphics card: once per
   vertex (where things are), once per pixel (what colour they are).
   ===================================================================== */

/* The vertex stage is shared between the main pass and the shadow pass.
   That sharing is not a tidiness win — it is a correctness requirement.
   If leaves sway in the camera's view but stand still in the sun's view,
   the shadows on the ground detach from the leaves casting them. */
const VS_COMMON = `#version 300 es
precision highp float;

layout(location=0) in vec3  a_pos;
layout(location=1) in vec3  a_nrm;
layout(location=2) in vec2  a_uv;
layout(location=3) in vec3  a_col;
layout(location=4) in float a_sway;
/* per-instance: one tree, one blade of grass, one butterfly */
layout(location=5) in vec3  i_off;
layout(location=6) in vec2  i_yawScale;
layout(location=7) in vec3  i_tint;
layout(location=8) in float i_phase;

uniform mat4  u_viewProj;
uniform mat4  u_lightVP;
uniform float u_time;
uniform float u_wind;

out vec3 v_wpos;
out vec3 v_nrm;
out vec2 v_uv;
out vec3 v_col;
out vec4 v_lpos;

void main(){
  float yaw = i_yawScale.x;
  float sc  = i_yawScale.y;
  float cy = cos(yaw), sy = sin(yaw);

  vec3 p = a_pos * sc;
  p = vec3(p.x*cy + p.z*sy, p.y, -p.x*sy + p.z*cy);
  vec3 n = vec3(a_nrm.x*cy + a_nrm.z*sy, a_nrm.y, -a_nrm.x*sy + a_nrm.z*cy);
  vec3 wp = p + i_off;

  /* Wind. Two sine waves at unrelated frequencies, offset per instance
     and per position, so the canopy never pulses in unison. a_sway is
     baked into the geometry: 0 at the trunk base, rising to 1 at the
     twig tips, so a tree bends rather than slides. */
  float ph = i_phase + wp.x*0.17 + wp.z*0.11;
  float w1 = sin(u_time*1.10 + ph);
  float w2 = sin(u_time*2.63 + ph*1.7) * 0.42;
  float amp = a_sway * u_wind;
  wp.x += (w1 + w2) * amp;
  wp.z += (w1*0.55 - w2*0.5) * amp;
  wp.y -= abs(w1) * amp * 0.16;

  v_wpos = wp;
  v_nrm  = n;
  v_uv   = a_uv;
  v_col  = a_col * i_tint;
  v_lpos = u_lightVP * vec4(wp, 1.0);
  gl_Position = u_viewProj * vec4(wp, 1.0);
}`;

/* ---- main surface shader --------------------------------------------
   One shader for bark, ground, leaves, blossom, grass and petals. The
   differences are switched by uniform rather than by having six
   programs: u_translucency > 0 means "this is a leaf", u_alphaCut > 0
   means "this has holes in it". */
const FS_WORLD = `#version 300 es
precision highp float;
precision highp sampler2DShadow;

in vec3 v_wpos;
in vec3 v_nrm;
in vec2 v_uv;
in vec3 v_col;
in vec4 v_lpos;

uniform sampler2D       u_tex;
uniform sampler2DShadow u_shadow;
uniform vec3  u_sunDir;        // surface -> sun
uniform vec3  u_sunCol;
uniform vec3  u_skyCol;        // ambient from above
uniform vec3  u_gndCol;        // ambient bounced from below
uniform vec3  u_camPos;
uniform vec3  u_fogCol;
uniform float u_fogDens;
uniform float u_useTex;
uniform float u_alphaCut;
uniform float u_translucency;
uniform float u_gloss;
uniform float u_texel;         // 1 / shadow map size
uniform float u_shadowStr;

out vec4 o_col;

/* Percentage-closer filtering. We ask the shadow map nine times in a
   small grid and average the answers. One tap gives a hard, aliased
   edge; nine give the soft-edged dapple that reads as komorebi. */
float shadowAt(vec4 lp, float ndl){
  vec3 pc = lp.xyz / lp.w * 0.5 + 0.5;
  if(pc.z > 1.0 || pc.x < 0.0 || pc.x > 1.0 || pc.y < 0.0 || pc.y > 1.0) return 1.0;
  /* Bias scaled by slope. Without it, a surface lit at a glancing angle
     shadows itself and the whole scene crawls with dark speckle. */
  float bias = clamp(0.0022 * tan(acos(clamp(ndl, 0.0, 1.0))), 0.0006, 0.0075);
  float s = 0.0;
  for(int y=-1; y<=1; y++){
    for(int x=-1; x<=1; x++){
      s += texture(u_shadow, vec3(pc.xy + vec2(float(x), float(y)) * u_texel, pc.z - bias));
    }
  }
  return s / 9.0;
}

void main(){
  vec4 t = vec4(1.0);
  if(u_useTex > 0.5){
    t = texture(u_tex, v_uv);
    if(t.a < u_alphaCut) discard;
  }
  vec3 albedo = v_col * t.rgb;

  vec3 N  = normalize(v_nrm);
  vec3 Vv = normalize(u_camPos - v_wpos);
  /* Leaf cards are flat and seen from both sides. Flip the normal to
     face the camera so the far side of the canopy isn't pitch black. */
  if(u_translucency > 0.0 && dot(N, Vv) < 0.0) N = -N;

  float ndl = dot(N, u_sunDir);
  float sh  = mix(1.0, shadowAt(v_lpos, ndl), u_shadowStr);

  /* Wrapped diffuse on foliage: real leaves scatter light round their
     own curvature, so the light/dark terminator is soft, not a hard
     line at 90 degrees. */
  float diff = (u_translucency > 0.0)
    ? max((ndl + 0.38) / 1.38, 0.0)
    : max(ndl, 0.0);

  /* Hemisphere ambient — blue-ish from the sky above, warm bounce from
     the grass below. Cheap, and it stops shadowed areas going flat. */
  vec3 amb = mix(u_gndCol, u_skyCol, N.y * 0.5 + 0.5);

  vec3 c = albedo * (amb + u_sunCol * diff * sh);

  /* Transmission. When the sun is behind a leaf and you are in front of
     it, light comes THROUGH the leaf and it glows. This single term is
     most of what makes a low sun in a canopy look like late afternoon
     rather than like a flat green wall. */
  if(u_translucency > 0.0){
    float back = pow(max(dot(Vv, -u_sunDir), 0.0), 3.0);
    c += albedo * u_sunCol * back * u_translucency * mix(0.35, 1.0, sh);
  }

  if(u_gloss > 0.0){
    vec3 H = normalize(u_sunDir + Vv);
    c += u_sunCol * pow(max(dot(N, H), 0.0), 28.0) * u_gloss * sh;
  }

  /* Distance haze, warmed in the direction of the sun so the far end of
     the park glows rather than greying out. */
  float d   = length(u_camPos - v_wpos);
  float fog = 1.0 - exp(-pow(d * u_fogDens, 2.0));
  float toSun = pow(max(dot(-Vv, u_sunDir), 0.0), 6.0);
  vec3  fogC  = u_fogCol + u_sunCol * toSun * 0.22;
  c = mix(c, fogC, clamp(fog, 0.0, 1.0));

  o_col = vec4(c, 1.0);
}`;

/* Depth-only pass for the shadow map. Colour is never written; the only
   job of the fragment stage is to punch holes where leaves are
   transparent, so that leaf-shaped light gets through. */
const FS_DEPTH = `#version 300 es
precision highp float;
in vec2 v_uv;
in vec3 v_wpos;
in vec3 v_nrm;
in vec3 v_col;
in vec4 v_lpos;
uniform sampler2D u_tex;
uniform float u_useTex;
uniform float u_alphaCut;
void main(){
  if(u_useTex > 0.5 && texture(u_tex, v_uv).a < u_alphaCut) discard;
}`;

/* ---- sky ------------------------------------------------------------
   Drawn as one triangle covering the screen, before anything else. We
   unproject each pixel to get the direction the eye is looking, then
   colour it by height and by angle to the sun. */
const VS_FULL = `#version 300 es
precision highp float;
layout(location=0) in vec2 a_p;
out vec2 v_ndc;
out vec2 v_uv;
void main(){
  v_ndc = a_p;
  v_uv  = a_p * 0.5 + 0.5;
  gl_Position = vec4(a_p, 0.0, 1.0);
}`;

const FS_SKY = `#version 300 es
precision highp float;
in vec2 v_ndc;
out vec4 o_col;
uniform mat4  u_invVP;
uniform vec3  u_camPos;
uniform vec3  u_sunDir;
uniform vec3  u_sunCol;
uniform vec3  u_zenith;
uniform vec3  u_horizon;
uniform float u_time;

void main(){
  vec4 p0 = u_invVP * vec4(v_ndc, -1.0, 1.0);
  vec4 p1 = u_invVP * vec4(v_ndc,  1.0, 1.0);
  vec3 dir = normalize(p1.xyz/p1.w - p0.xyz/p0.w);

  float h = clamp(dir.y * 0.5 + 0.5, 0.0, 1.0);
  vec3 c = mix(u_horizon, u_zenith, pow(max(dir.y, 0.0), 0.55));

  /* Below the horizon we are looking at the far ground plane, which is
     drowned in haze anyway — fade to the horizon colour. */
  c = mix(u_horizon * 0.82, c, smoothstep(-0.06, 0.06, dir.y));

  float ang = max(dot(dir, u_sunDir), 0.0);
  c += u_sunCol * pow(ang, 5.0)  * 0.55;   // broad glow
  c += u_sunCol * pow(ang, 220.0) * 6.0;   // the disc itself
  c += u_sunCol * pow(ang, 1400.0) * 22.0; // hot core, feeds the bloom

  /* A few soft cloud bands, high and thin. fbm would be nicer but three
     stretched sines are enough at this distance. */
  float cl = sin(dir.x*3.1 + u_time*0.008) * sin(dir.z*2.4 - u_time*0.006);
  cl = smoothstep(0.25, 0.9, cl) * smoothstep(0.03, 0.45, dir.y);
  c = mix(c, mix(c, vec3(1.02, 0.96, 0.90), 0.55), cl * 0.5);

  o_col = vec4(c, 1.0);
}`;

/* Unlit and additive. Used only for the ring of light that marks the tree
   the prompt is talking about — it should look like light lying on the
   grass, so it is added to whatever is already there rather than lit. */
const FS_GLOW = `#version 300 es
precision highp float;
in vec2 v_uv;
in vec3 v_col;
in vec3 v_wpos;
uniform sampler2D u_tex;
uniform vec3  u_camPos;
uniform float u_fade;
out vec4 o_col;
void main(){
  vec4 t = texture(u_tex, v_uv);
  /* Fade with distance so the ring never becomes a bright disc on the
     horizon when you look at a tree from far away. */
  float d = length(u_camPos - v_wpos);
  float near = 1.0 - smoothstep(6.0, 15.0, d);
  o_col = vec4(t.rgb * v_col, t.a * u_fade * near);
}`;

/* ---- post-processing ------------------------------------------------ */

/* Isolate only the parts of the frame brighter than the threshold. Those
   are the sun, the sky near it, and sunlit leaf edges — the things that
   should bleed. */
const FS_BRIGHT = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 o_col;
uniform sampler2D u_src;
uniform float u_thresh;
void main(){
  vec3 c = texture(u_src, v_uv).rgb;
  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
  o_col = vec4(c * smoothstep(u_thresh, u_thresh + 0.6, l), 1.0);
}`;

/* Separable Gaussian: blur horizontally, then blur that vertically.
   Two 9-tap passes instead of one 81-tap pass. */
const FS_BLUR = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 o_col;
uniform sampler2D u_src;
uniform vec2 u_dir;
void main(){
  float w[5];
  w[0]=0.2270; w[1]=0.1946; w[2]=0.1216; w[3]=0.0540; w[4]=0.0162;
  vec3 c = texture(u_src, v_uv).rgb * w[0];
  for(int i=1;i<5;i++){
    vec2 o = u_dir * float(i);
    c += texture(u_src, v_uv + o).rgb * w[i];
    c += texture(u_src, v_uv - o).rgb * w[i];
  }
  o_col = vec4(c, 1.0);
}`;

/* God rays. Walk from each pixel towards the sun's position on screen,
   accumulating brightness with decay. Where a leaf blocks the path the
   samples are dark, so the light that does get through arrives as a
   shaft. This is the second half of komorebi — the shadow map does the
   dapple on the ground, this does the shafts in the air. */
const FS_RAYS = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 o_col;
uniform sampler2D u_src;
uniform vec2  u_sunUV;
uniform float u_density;
uniform float u_decay;
uniform float u_weight;
uniform float u_expo;
void main(){
  vec2 uv = v_uv;
  vec2 delta = (uv - u_sunUV) * (u_density / 40.0);
  vec3 c = vec3(0.0);
  float illum = 1.0;
  for(int i=0;i<40;i++){
    uv -= delta;
    vec3 s = texture(u_src, clamp(uv, 0.0, 1.0)).rgb;
    c += s * illum * u_weight;
    illum *= u_decay;
  }
  o_col = vec4(c * u_expo, 1.0);
}`;

/* Final pass: add the glow layers, compress the huge brightness range
   down to something a monitor can show, then grade. */
const FS_COMPOSITE = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 o_col;
uniform sampler2D u_scene;
uniform sampler2D u_bloom;
uniform sampler2D u_rays;
uniform float u_bloomAmt;
uniform float u_rayAmt;
uniform float u_exposure;
uniform float u_time;
uniform float u_vignette;

/* ACES filmic curve. A plain clamp turns every bright highlight into a
   flat white blob; this rolls them off so the sun keeps its colour as
   it saturates. */
vec3 aces(vec3 x){
  const float a=2.51, b=0.03, c=2.43, d=0.59, e=0.14;
  return clamp((x*(a*x+b))/(x*(c*x+d)+e), 0.0, 1.0);
}

void main(){
  vec3 c = texture(u_scene, v_uv).rgb;
  c += texture(u_bloom, v_uv).rgb * u_bloomAmt;
  c += texture(u_rays,  v_uv).rgb * u_rayAmt;

  c *= u_exposure;
  c = aces(c);

  /* Warm the highlights, cool the shadows very slightly — the standard
     golden-hour grade. */
  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
  c = mix(c * vec3(0.965, 0.985, 1.045), c * vec3(1.045, 1.005, 0.945), l);

  vec2 d = v_uv - 0.5;
  c *= 1.0 - dot(d, d) * u_vignette;

  /* A whisper of grain. Without it, large smooth gradients (the sky
     especially) band into visible steps on 8-bit displays. */
  float g = fract(sin(dot(v_uv * 1000.0 + u_time, vec2(12.9898, 78.233))) * 43758.5453);
  c += (g - 0.5) * 0.016;

  o_col = vec4(pow(max(c, 0.0), vec3(1.0/2.2)), 1.0);
}`;
