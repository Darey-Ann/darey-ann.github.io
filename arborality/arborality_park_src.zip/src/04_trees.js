/* =====================================================================
   04 — GROWING THE TREES

   Every tree is grown, not modelled. One recursive function walks a
   branch forward in small steps, bending it as it goes, then splits off
   children and calls itself. Foliage is dropped onto whichever branch
   orders the species actually carries leaves on.

   The parameters below are what separate a cedar from a maple. Nothing
   else in this file is species-specific.
   ===================================================================== */

/* WHAT EACH PARAMETER DOES
   -------------------------------------------------------------------------
   height        the tree's full height in metres, for reference
   trunk         length of the first branch (the trunk) in metres
   rad           trunk radius at the base, in metres
   levels        how many times the branching recurses. Each extra level
                 roughly triples the branch count, so 6 is expensive
   sides         how many vertices go round each branch. Drops with depth
   kids(d)       how many children a branch at depth d puts out
   childFrom(d)  how far along the parent the children start, 0..1. Near 1
                 means the parent ends and splits (a cherry); near 0 means
                 they come off along its length (a cedar)
   continues     true if the trunk runs to the top rather than dissolving
                 into the crown. The single biggest shape difference
                 between a conifer and a broadleaf
   angle(d)      how far a child leaves the parent's direction, radians.
                 ~0.5 is a narrow upright tree, ~1.2 is nearly horizontal
   lenF / radF   how much shorter and thinner each generation is
   gravi(d)      gravitropism: positive bends a shoot back towards
                 vertical as it grows, negative lets it droop
   wander        random wobble per step. High values give a picturesque
                 pine, low values give a straight cedar
   flex          how much the species moves in wind. Pine is stiff (0.35),
                 maple is loose (1.25)
   lenByHeight   conifers only: branch length as a function of height up
                 the trunk. This alone produces the cone
   bark/barkTip  trunk colour at the base and at the twigs
   foliageFrom   the first branch depth that carries leaves
   foliageAlong  true = leaves all along the shoot (conifers, ginkgo),
                 false = leaves gathered at the tip (broadleaves)
   leaf          { tex, size (metres), per (cards per branch), spread,
                   tint, vary }
   leaf2         an optional second foliage type mixed in — the sakura
                 uses it to put a few green leaves among the blossom
   trans         translucency: how much light passes THROUGH a leaf. The
                 single value that makes a backlit canopy glow
   gloss         sheen on the leaf surface
   ------------------------------------------------------------------- */
const SPECIES_FORM = {

  /* SAKURA · Somei-Yoshino.
     Deliquescent: the trunk does not continue to the top, it dissolves
     into a vase of scaffold limbs low down. Bark almost black — the
     contrast against pale blossom is the whole look of a cherry in
     flower against a bright sky. Blossom only on the outermost twigs,
     because that is where a cherry actually flowers. */
  sakura: {
    height: 11.0, trunk: 3.0, rad: 0.26,
    levels: 5, sides: 7,
    kids: d => d === 0 ? 4 : (d < 3 ? 3 : 2),
    childFrom: d => d === 0 ? 0.62 : 0.55,   // where along the parent children start
    continues: false,
    angle: d => d === 0 ? 0.72 : 0.62,
    lenF: 0.70, radF: 0.575,
    gravi: d => d === 0 ? 0.28 : 0.10,       // >0 bends back towards vertical
    wander: 0.22, flex: 1.0,
    bark: [0.135, 0.108, 0.098],             // near-black
    barkTip: [0.30, 0.22, 0.19],
    foliageFrom: 4,
    leaf: { tex: 'sakura', size: 0.235, per: 12, spread: 0.62,
            tint: [1.0, 0.97, 0.99], vary: 0.10 },
    leaf2:{ tex: 'sakuraL', size: 0.165, per: 4, spread: 0.58,
            tint: [0.92, 1.0, 0.88], vary: 0.14 },
    trans: 0.85, gloss: 0.05
  },

  /* MOMIJI · Acer palmatum.
     Small, often several leaders straight from the base, and the
     branching is markedly horizontal — a maple builds itself in layers
     with gaps between them, which is why light comes through it in
     sheets rather than as scattered dapple. */
  momiji: {
    height: 5.2, trunk: 1.1, rad: 0.11,
    levels: 5, sides: 6,
    kids: d => d === 0 ? 3 : (d < 3 ? 3 : 2),
    childFrom: d => d === 0 ? 0.30 : 0.48,
    continues: false,
    angle: d => d === 0 ? 0.55 : 1.02,       // wide: nearly horizontal
    lenF: 0.74, radF: 0.585,
    gravi: d => -0.06,                       // droops very slightly
    wander: 0.30, flex: 1.25,
    bark: [0.30, 0.29, 0.26],
    barkTip: [0.42, 0.36, 0.30],
    foliageFrom: 3,
    leaf: { tex: 'momiji', size: 0.185, per: 11, spread: 0.68,
            tint: [1.0, 1.0, 1.0], vary: 0.16 },
    trans: 1.15, gloss: 0.07
  },

  /* SUGI · Cryptomeria japonica.
     Excurrent: one straight trunk all the way to the tip, with short
     side branches coming off it in whorls. The branches get shorter the
     higher up they are, and that alone produces the cone. */
  sugi: {
    height: 21.0, trunk: 20.0, rad: 0.44,
    levels: 3, sides: 8,
    kids: d => d === 0 ? 26 : 3,
    childFrom: d => d === 0 ? 0.10 : 0.30,
    continues: true,                         // trunk runs to full height
    angle: d => d === 0 ? 1.28 : 0.60,       // side branches nearly horizontal
    lenF: 0.34, radF: 0.34,
    /* Branch length falls off sharply with height up the trunk — the
       cone shape comes from here, not from any explicit silhouette. */
    lenByHeight: h => Math.pow(1 - h*0.82, 1.35),
    gravi: d => 0.16,
    wander: 0.14, flex: 0.45,
    bark: [0.38, 0.235, 0.165],              // fibrous red-brown
    barkTip: [0.42, 0.28, 0.20],
    foliageFrom: 1,
    foliageAlong: true,                      // sprigs all along the shoot
    leaf: { tex: 'sugi', size: 0.33, per: 2, spread: 0.38,
            tint: [0.88, 0.98, 0.86], vary: 0.12 },
    trans: 0.55, gloss: 0.10
  },

  /* ICHO · Ginkgo biloba.
     Strongly upright, rather stiff and open, with foliage carried in
     tufts on short spur shoots rather than spread evenly. */
  ginkgo: {
    height: 16.0, trunk: 5.5, rad: 0.32,
    levels: 4, sides: 7,
    kids: d => d === 0 ? 5 : 3,
    childFrom: d => d === 0 ? 0.42 : 0.42,
    continues: true,
    angle: d => d === 0 ? 0.62 : 0.52,
    lenF: 0.62, radF: 0.545,
    gravi: d => 0.34,                        // pulls hard back to vertical
    wander: 0.18, flex: 0.7,
    bark: [0.355, 0.325, 0.285],
    barkTip: [0.44, 0.40, 0.34],
    foliageFrom: 2,
    foliageAlong: true,
    leaf: { tex: 'ginkgo', size: 0.21, per: 3, spread: 0.44,
            tint: [1.0, 1.0, 0.95], vary: 0.13 },
    trans: 1.0, gloss: 0.09
  },

  /* MATSU · Pinus thunbergii, the black pine.
     The awkward one, and the interesting one. Nothing about it is
     regular: the trunk leans and kinks, branches leave at odd angles,
     and the needles gather into flat pads at the ends with bare wood
     showing between. Extra wander, few children, foliage only at tips. */
  matsu: {
    height: 9.5, trunk: 3.4, rad: 0.30,
    levels: 4, sides: 7,
    kids: d => d === 0 ? 3 : 2,
    childFrom: d => d === 0 ? 0.34 : 0.60,
    continues: false,
    angle: d => d === 0 ? 0.95 : 0.80,
    lenF: 0.70, radF: 0.555,
    gravi: d => d < 2 ? -0.10 : 0.42,        // sags, then the tip lifts
    wander: 0.52, flex: 0.35,                // stiff, so barely moves
    kink: 0.55,                              // extra irregularity in the trunk
    bark: [0.185, 0.170, 0.160],
    barkTip: [0.34, 0.28, 0.23],
    foliageFrom: 2,
    leaf: { tex: 'matsu', size: 0.30, per: 26, spread: 0.62,
            tint: [0.92, 1.0, 0.90], vary: 0.10 },
    trans: 0.45, gloss: 0.14
  }
};

/* ---- the grower -----------------------------------------------------
   B = branch geometry, F = foliage geometry. They are separate meshes
   because they are drawn with different settings: bark is opaque and
   single-sided, foliage is alpha-tested, double-sided and translucent.
   ------------------------------------------------------------------- */
function growBranch(ctx, pos, dir, len, rad, depth, heightFrac){
  const { B, F, S, r, tex, levels, scaleLeaf } = ctx;

  const segs  = Math.max(2, Math.round(6 - depth*0.9));
  const sides = Math.max(3, S.sides - depth);
  const step  = len/segs;

  /* Sway rises towards the tips. Squaring it keeps the trunk almost
     rigid while the twigs move freely, which is how a tree behaves —
     the trunk of a cherry does not visibly move in a breeze. */
  const swayAt = t => Math.pow((depth + t)/(levels + 1), 1.7) * S.flex;

  let p = pos.slice(), d = dir.slice();
  let ringPrev = null;
  const path = [];

  for(let s = 0; s <= segs; s++){
    const t = s/segs;
    const rr = rad * (1 - t*0.86) + 0.0035;          // taper
    const [ax, az] = V.basis(d);
    const ring = [];
    /* Bark colour lightens towards the tips: young wood is paler than
       old furrowed bark, and it stops the crown reading as a black
       cloud. */
    const col = V.lerp(S.bark, S.barkTip, Math.min(1, (depth + t)/(levels*0.85)));
    for(let k = 0; k < sides; k++){
      const a = k/sides * Math.PI*2;
      const off = V.add(V.scale(ax, Math.cos(a)*rr), V.scale(az, Math.sin(a)*rr));
      const nrm = V.norm(off);
      ring.push(B.vert(V.add(p, off), nrm,
                       [k/sides*2.0, (depth*0.7 + t*len*0.55)],
                       col, swayAt(t)));
    }
    if(ringPrev){
      for(let k = 0; k < sides; k++){
        const k2 = (k+1)%sides;
        B.quad(ringPrev[k], ringPrev[k2], ring[k2], ring[k]);
      }
    }
    ringPrev = ring;
    path.push({ p: p.slice(), d: d.slice(), t });

    if(s < segs){
      /* Advance. Two forces act on the direction each step: gravitropism
         (the shoot's tendency to turn back towards vertical) and a small
         random wander that keeps anything from looking machined. */
      p = V.add(p, V.scale(d, step));
      const g = S.gravi(depth) * step * 0.55;
      d = V.norm([d[0] + (r()-0.5)*S.wander*step,
                  d[1] + g      + (r()-0.5)*S.wander*step*0.35,
                  d[2] + (r()-0.5)*S.wander*step]);
    }
  }
  const tip = p;

  /* ---- foliage ---- */
  const wantsLeaves = depth >= S.foliageFrom;
  if(wantsLeaves && ctx.leafBudget > 0){
    const spec = S.leaf;
    const put = (centre, sw, def) => {
      const size = def.size * scaleLeaf * (0.78 + r()*0.44);
      /* Random orientation with a slight downward bias, so leaves hang
         instead of standing to attention. */
      const n = V.norm([r()-0.5, (r()-0.5) - 0.25, r()-0.5]);
      const [bx, bz] = V.basis(n);
      /* Spin the card in its own plane by a random amount. V.basis always
         returns the same two axes for a given normal, so without this
         every blossom cluster is the same texture at the same angle and
         the crown reads as one stamp repeated — the "papery" look. */
      const roll = r()*Math.PI*2, cr = Math.cos(roll), sr = Math.sin(roll);
      const ax = V.add(V.scale(bx, cr), V.scale(bz, sr));
      const az = V.add(V.scale(bx, -sr), V.scale(bz, cr));
      const c = [
        def.tint[0] * (1 + (r()-0.5)*def.vary),
        def.tint[1] * (1 + (r()-0.5)*def.vary),
        def.tint[2] * (1 + (r()-0.5)*def.vary)
      ];
      const tgt = def.tex === 'sakura' || def.tex === 'sakuraL' ? F : F;
      /* Slightly non-square, varied per card, so no two read as clones. */
      tgt.card(centre, V.scale(ax, size*(0.86+r()*0.28)),
                       V.scale(az, size*(0.86+r()*0.28)), c, sw, [0,0],[1,1], n);
      ctx.leafBudget--;
    };

    if(S.foliageAlong){
      /* Conifers and ginkgo carry foliage along the whole shoot. */
      const n = Math.round(spec.per * segs * 0.9);
      for(let i = 0; i < n && ctx.leafBudget > 0; i++){
        const f  = 0.12 + r()*0.88;
        const idx = Math.min(path.length-1, Math.floor(f*path.length));
        const base = path[idx].p;
        const c = [base[0] + (r()-0.5)*len*spec.spread*0.5,
                   base[1] + (r()-0.5)*len*spec.spread*0.35,
                   base[2] + (r()-0.5)*len*spec.spread*0.5];
        put(c, swayAt(f)*1.15, spec);
      }
    } else {
      /* Broadleaves: a blob of leaves gathered at the twig tip. */
      for(let i = 0; i < spec.per && ctx.leafBudget > 0; i++){
        const c = [tip[0] + (r()-0.5)*len*spec.spread,
                   tip[1] + (r()-0.5)*len*spec.spread*0.7,
                   tip[2] + (r()-0.5)*len*spec.spread];
        put(c, swayAt(1)*1.2, spec);
      }
      if(S.leaf2){
        for(let i = 0; i < S.leaf2.per && ctx.leafBudget > 0; i++){
          const c = [tip[0] + (r()-0.5)*len*S.leaf2.spread,
                     tip[1] + (r()-0.5)*len*S.leaf2.spread*0.7,
                     tip[2] + (r()-0.5)*len*S.leaf2.spread];
          put(c, swayAt(1)*1.2, S.leaf2);
        }
      }
    }
  }

  if(depth >= levels) return;

  /* ---- children ---- */
  const n = S.kids(depth);
  const from = S.childFrom(depth);
  const goldenAngle = 2.39996;               // phyllotaxis: 137.5 degrees
  let roll = r()*Math.PI*2;

  for(let i = 0; i < n; i++){
    const f = S.continues && depth === 0
      ? from + (i/(n-1 || 1)) * (0.94 - from)       // spread up the trunk
      : from + (i/Math.max(1,n)) * (1 - from) + r()*0.06;

    const idx = Math.min(path.length-1, Math.max(0, Math.round(f*(path.length-1))));
    const node = path[idx];

    roll += goldenAngle;
    const [ax] = V.basis(node.d);
    /* Take the parent direction, tilt it away by the divergence angle,
       then roll that tilt around the parent axis. */
    let cd = V.rotAxis(node.d, ax, S.angle(depth) * (0.75 + r()*0.5));
    cd = V.rotAxis(cd, node.d, roll);
    cd = V.norm(cd);

    let clen = len * S.lenF * (0.80 + r()*0.40);
    /* On an excurrent tree the branches must shorten with height or the
       result is a cylinder, not a cone. */
    if(S.lenByHeight && depth === 0){
      clen = ctx.trunkBranchLen * S.lenByHeight(f) * (0.78 + r()*0.44);
    }
    const crad = rad * S.radF * (0.85 + r()*0.3);
    if(clen < 0.12 || crad < 0.006) continue;

    growBranch(ctx, node.p, cd, clen, crad, depth+1, heightFrac);
  }
}

/* Build one tree prototype. `quality` scales foliage density so distant
   background trees cost a fraction of a specimen tree by the path. */
function growTree(gl, key, seed, quality){
  const S = SPECIES_FORM[key];
  const r = R.make(seed);
  const B = new Builder(), F = new Builder();

  const ctx = {
    B, F, S, r,
    levels: S.levels - (quality < 0.6 ? 1 : 0),
    scaleLeaf: quality < 0.6 ? 1.55 : 1.0,     // fewer, bigger leaves far away
    leafBudget: Math.round(3800 * quality),
    trunkBranchLen: S.height * 0.42
  };

  /* The trunk. A slight lean and a kink give even a young tree some
     character; the pine gets a lot more of both. */
  const lean = (S.kink || 0.12);
  const dir0 = V.norm([(r()-0.5)*lean, 1, (r()-0.5)*lean]);
  growBranch(ctx, [0,0,0], dir0, S.trunk, S.rad, 0, 0);

  return {
    key,
    branch:  B.build(gl),
    foliage: F.build(gl),
    tris: B.tris + F.tris,
    height: S.height,
    /* Rough footprint, used to stop the player walking through trunks
       and to space trees apart when scattering them. */
    radius: Math.max(0.30, S.rad * 3.4),
    crown:  S.height * 0.42,
    form: S
  };
}

/* ---- shrubs ---------------------------------------------------------
   Not grown recursively — a shrub is a mound, so it is built as a mound
   of leaf cards over a few short woody stems. Much cheaper, and at the
   size they appear it reads the same. */
function growShrub(gl, seed, kind){
  const r = R.make(seed);
  const B = new Builder(), F = new Builder();
  const h = kind === 'azalea' ? 0.85 : 1.35;
  const w = kind === 'azalea' ? 1.15 : 0.95;

  for(let s = 0; s < 5; s++){
    const a = r()*Math.PI*2, ln = h*(0.5 + r()*0.4);
    const d = V.norm([Math.cos(a)*0.42, 1, Math.sin(a)*0.42]);
    let p = [0,0,0];
    const segs = 3;
    let prev = null;
    for(let i = 0; i <= segs; i++){
      const t = i/segs, rr = 0.035*(1-t*0.7)+0.004;
      const [ax, az] = V.basis(d);
      const ring = [];
      for(let k = 0; k < 5; k++){
        const ang = k/5*Math.PI*2;
        const off = V.add(V.scale(ax, Math.cos(ang)*rr), V.scale(az, Math.sin(ang)*rr));
        ring.push(B.vert(V.add(p,off), V.norm(off), [k/5, t], [0.28,0.24,0.19], t*0.25));
      }
      if(prev) for(let k=0;k<5;k++){ const k2=(k+1)%5; B.quad(prev[k],prev[k2],ring[k2],ring[k]); }
      prev = ring;
      p = V.add(p, V.scale(d, ln/segs));
    }
  }

  const count = kind === 'azalea' ? 90 : 110;
  for(let i = 0; i < count; i++){
    /* Points inside a squashed hemisphere: dense in the middle, thinning
       at the edges, which is what a clipped shrub looks like. */
    const u = r()*Math.PI*2, v = Math.acos(1 - r()*1.0);
    const rad = w * Math.pow(r(), 0.34);
    const c = [Math.sin(v)*Math.cos(u)*rad, Math.cos(v)*h*0.95 + 0.15, Math.sin(v)*Math.sin(u)*rad];
    const n = V.norm([c[0]+ (r()-0.5)*0.3, c[1]*0.8 + 0.2, c[2]+ (r()-0.5)*0.3]);
    const [ax, az] = V.basis(n);
    const sz = (kind === 'azalea' ? 0.30 : 0.34) * (0.75 + r()*0.5);
    const tint = 0.86 + r()*0.30;
    F.card(c, V.scale(ax, sz), V.scale(az, sz), [tint, tint*1.02, tint*0.95],
           0.55 + r()*0.3, [0,0],[1,1], n);
  }
  return {
    branch: B.build(gl), foliage: F.build(gl),
    radius: w*0.8, kind
  };
}
