/* =====================================================================
   01 — MATHS AND WebGL PLUMBING
   No library. Everything below is the minimum needed to put triangles
   on screen with a camera, a sun, and a shadow map.
   ===================================================================== */

/* ---- 4x4 matrices, column-major (the order WebGL expects) ---------- */
const M4 = {
  ident(){ return new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]); },

  /* Standard perspective projection. fovy in radians. */
  persp(fovy, aspect, near, far){
    const f = 1/Math.tan(fovy/2), nf = 1/(near-far);
    return new Float32Array([
      f/aspect,0,0,0,
      0,f,0,0,
      0,0,(far+near)*nf,-1,
      0,0,2*far*near*nf,0
    ]);
  },

  /* Orthographic — used for the sun's view when rendering the shadow map.
     The sun is effectively infinitely far away, so its rays are parallel,
     which is exactly what an ortho projection models. */
  ortho(l,r,b,t,n,f){
    const lr=1/(l-r), bt=1/(b-t), nf=1/(n-f);
    return new Float32Array([
      -2*lr,0,0,0,
      0,-2*bt,0,0,
      0,0,2*nf,0,
      (l+r)*lr,(t+b)*bt,(f+n)*nf,1
    ]);
  },

  lookAt(eye, ctr, up){
    let z0=eye[0]-ctr[0], z1=eye[1]-ctr[1], z2=eye[2]-ctr[2];
    let l = 1/Math.hypot(z0,z1,z2); z0*=l; z1*=l; z2*=l;
    let x0 = up[1]*z2 - up[2]*z1, x1 = up[2]*z0 - up[0]*z2, x2 = up[0]*z1 - up[1]*z0;
    l = Math.hypot(x0,x1,x2); if(l===0){ x0=1;x1=0;x2=0; } else { l=1/l; x0*=l;x1*=l;x2*=l; }
    const y0 = z1*x2 - z2*x1, y1 = z2*x0 - z0*x2, y2 = z0*x1 - z1*x0;
    return new Float32Array([
      x0,y0,z0,0,
      x1,y1,z1,0,
      x2,y2,z2,0,
      -(x0*eye[0]+x1*eye[1]+x2*eye[2]),
      -(y0*eye[0]+y1*eye[1]+y2*eye[2]),
      -(z0*eye[0]+z1*eye[1]+z2*eye[2]), 1
    ]);
  },

  mul(a,b){
    const o = new Float32Array(16);
    for(let c=0;c<4;c++){
      for(let r=0;r<4;r++){
        o[c*4+r] = a[0*4+r]*b[c*4+0] + a[1*4+r]*b[c*4+1] + a[2*4+r]*b[c*4+2] + a[3*4+r]*b[c*4+3];
      }
    }
    return o;
  },

  /* Transform a point (w=1) and divide through — used to find where the
     sun sits on screen for the god-ray pass. */
  xformPoint(m, p){
    const x=p[0],y=p[1],z=p[2];
    const w = m[3]*x + m[7]*y + m[11]*z + m[15];
    return [
      (m[0]*x + m[4]*y + m[8]*z  + m[12])/w,
      (m[1]*x + m[5]*y + m[9]*z  + m[13])/w,
      (m[2]*x + m[6]*y + m[10]*z + m[14])/w,
      w
    ];
  }
};

/* ---- deterministic random ------------------------------------------
   The whole park is generated from one seed. Using Math.random() would
   give a different park on every reload, which makes it impossible to
   say "the pine near the second bend looks wrong" — so we use a small
   seeded generator (mulberry32) instead. Change SEED, get a new park;
   keep it, and the park is identical every time. */
function rng(seed){
  let a = seed >>> 0;
  return function(){
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const R = {
  make: rng,
  range(r,a,b){ return a + r()*(b-a); },
  int(r,a,b){ return Math.floor(a + r()*(b-a+1)); },
  pick(r,arr){ return arr[Math.floor(r()*arr.length)]; }
};

/* ---- value noise ----------------------------------------------------
   Used for ground height, ground colour mottling, and wind. Cheap, and
   smooth enough that hills read as hills rather than as a grid. */
const NOISE_P = (()=> {
  const r = rng(1337), p = new Uint8Array(512);
  const perm = Array.from({length:256},(_,i)=>i);
  for(let i=255;i>0;i--){ const j=Math.floor(r()*(i+1)); [perm[i],perm[j]]=[perm[j],perm[i]]; }
  for(let i=0;i<512;i++) p[i]=perm[i&255];
  return p;
})();
function fade(t){ return t*t*t*(t*(t*6-15)+10); }
function lerp(a,b,t){ return a + (b-a)*t; }
function grad2(h,x,y){
  switch(h&3){ case 0: return  x+y; case 1: return -x+y; case 2: return x-y; default: return -x-y; }
}
function noise2(x,y){
  const X=Math.floor(x)&255, Y=Math.floor(y)&255;
  x-=Math.floor(x); y-=Math.floor(y);
  const u=fade(x), v=fade(y);
  const A=NOISE_P[X]+Y, B=NOISE_P[X+1]+Y;
  return lerp(
    lerp(grad2(NOISE_P[A],x,y),   grad2(NOISE_P[B],x-1,y),   u),
    lerp(grad2(NOISE_P[A+1],x,y-1), grad2(NOISE_P[B+1],x-1,y-1), u),
    v) * 0.7;
}
function fbm(x,y,oct){
  let s=0, a=0.5, f=1;
  for(let i=0;i<oct;i++){ s += a*noise2(x*f,y*f); a*=0.5; f*=2; }
  return s;
}

/* ---- shader compilation -------------------------------------------- */
function compile(gl, type, src, label){
  const s = gl.createShader(type);
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if(!gl.getShaderParameter(s, gl.COMPILE_STATUS)){
    console.error('shader ['+label+']', gl.getShaderInfoLog(s));
    console.error(src.split('\n').map((l,i)=>(i+1)+': '+l).join('\n'));
    throw new Error('shader compile failed: '+label);
  }
  return s;
}
function program(gl, vs, fs, label){
  const p = gl.createProgram();
  gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vs, label+'.vert'));
  gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs, label+'.frag'));
  gl.linkProgram(p);
  if(!gl.getProgramParameter(p, gl.LINK_STATUS)){
    throw new Error('link failed '+label+': '+gl.getProgramInfoLog(p));
  }
  /* Cache every uniform location once. Looking them up per frame is a
     surprisingly large cost in a scene with this many draw calls. */
  p.u = {};
  const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for(let i=0;i<n;i++){
    const info = gl.getActiveUniform(p, i);
    const name = info.name.replace(/\[0\]$/,'');
    p.u[name] = gl.getUniformLocation(p, name);
  }
  return p;
}

/* ---- a drawable ----------------------------------------------------
   Vertex layout is fixed for the whole scene, interleaved in one buffer:
     0 position   vec3
     1 normal     vec3
     2 uv         vec2
     3 colour     vec3   (baked-in tint; saves a texture for bark etc.)
     4 sway       float  (0 = rigid, 1 = moves fully with the wind)
   = 12 floats, 48 bytes per vertex.
   Instanced draws add a second buffer:
     5 offset     vec3
     6 yaw+scale  vec2
     7 tint       vec3
     8 phase      float   (so no two trees sway in unison)
   ------------------------------------------------------------------- */
const VSTRIDE = 12 * 4;

/* A Mesh is one lump of geometry the graphics card can draw.

   Two things about it are worth understanding:

   INTERLEAVED. All twelve numbers describing a vertex sit together in one
   buffer, rather than living in separate position/normal/uv arrays. The
   card reads a vertex in one go from one place, which is how the hardware
   wants it.

   INSTANCED. Drawing ninety cedars by calling draw() ninety times means
   ninety conversations with the card, and the cost is in the talking, not
   the triangles. Instead the geometry is uploaded once and accompanied by
   a list of positions; `drawElementsInstanced` then draws all ninety in
   one call, and the vertex shader offsets each copy by its own entry in
   that list. `vertexAttribDivisor(n, 1)` is the line that says "advance
   this attribute once per COPY, not once per vertex".
   ------------------------------------------------------------------- */
class Mesh {
  constructor(gl, verts, idx){
    this.gl = gl;
    this.count = idx.length;
    this.vao = gl.createVertexArray();
    gl.bindVertexArray(this.vao);

    this.vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
    gl.bufferData(gl.ARRAY_BUFFER, verts, gl.STATIC_DRAW);
    const F = 4;
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0,3,gl.FLOAT,false,VSTRIDE,0*F);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1,3,gl.FLOAT,false,VSTRIDE,3*F);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2,2,gl.FLOAT,false,VSTRIDE,6*F);
    gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3,3,gl.FLOAT,false,VSTRIDE,8*F);
    gl.enableVertexAttribArray(4); gl.vertexAttribPointer(4,1,gl.FLOAT,false,VSTRIDE,11*F);

    this.ibo = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);

    this.instCount = 1;
    gl.bindVertexArray(null);
  }

  /* One entry per copy, nine numbers each, laid out to match attributes
     5-8 declared in the vertex shader:
        [0..2] world position
        [3]    rotation about the vertical axis, radians
        [4]    scale
        [5..7] colour tint, multiplied into the vertex colour
        [8]    a phase offset, so no two trees sway in step
     data: Float32Array, 9 floats per instance */
  setInstances(data){
    const gl = this.gl;
    gl.bindVertexArray(this.vao);
    if(!this.ibo2) this.ibo2 = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.ibo2);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    const S = 9*4, F = 4;
    gl.enableVertexAttribArray(5); gl.vertexAttribPointer(5,3,gl.FLOAT,false,S,0*F); gl.vertexAttribDivisor(5,1);
    gl.enableVertexAttribArray(6); gl.vertexAttribPointer(6,2,gl.FLOAT,false,S,3*F); gl.vertexAttribDivisor(6,1);
    gl.enableVertexAttribArray(7); gl.vertexAttribPointer(7,3,gl.FLOAT,false,S,5*F); gl.vertexAttribDivisor(7,1);
    gl.enableVertexAttribArray(8); gl.vertexAttribPointer(8,1,gl.FLOAT,false,S,8*F); gl.vertexAttribDivisor(8,1);
    this.instCount = data.length/9;
    gl.bindVertexArray(null);
    return this;
  }

  /* When a mesh is drawn without instance data we still need attributes
     5-8 to have sane values, so we hand the GPU a constant. */
  bindStatic(){
    const gl = this.gl;
    gl.disableVertexAttribArray(5); gl.vertexAttrib3f(5,0,0,0);
    gl.disableVertexAttribArray(6); gl.vertexAttrib2f(6,0,1);
    gl.disableVertexAttribArray(7); gl.vertexAttrib3f(7,1,1,1);
    gl.disableVertexAttribArray(8); gl.vertexAttrib1f(8,0);
  }

  draw(instanced){
    const gl = this.gl;
    gl.bindVertexArray(this.vao);
    if(instanced && this.instCount > 0){
      gl.drawElementsInstanced(gl.TRIANGLES, this.count, gl.UNSIGNED_INT, 0, this.instCount);
    } else {
      this.bindStatic();
      gl.drawElements(gl.TRIANGLES, this.count, gl.UNSIGNED_INT, 0);
    }
  }
}

/* ---- mesh builder ---------------------------------------------------
   Accumulates triangles in plain arrays, then hands them to Mesh once.
   Everything in the park — trunks, leaves, grass, ground — is built
   through this. */
class Builder {
  constructor(){ this.v = []; this.i = []; this.n = 0; }

  vert(p, nrm, uv, col, sway){
    this.v.push(p[0],p[1],p[2], nrm[0],nrm[1],nrm[2], uv[0],uv[1], col[0],col[1],col[2], sway);
    return this.n++;
  }
  tri(a,b,c){ this.i.push(a,b,c); }
  quad(a,b,c,d){ this.i.push(a,b,c, a,c,d); }

  /* A camera-independent flat card, used for every leaf, petal and
     blade of grass. `up` is the card's own up axis, `right` its width. */
  card(centre, right, up, col, sway, uv0, uv1, normal){
    const n = normal || [0,1,0];
    const p = (sx,sy)=>[
      centre[0] + right[0]*sx + up[0]*sy,
      centre[1] + right[1]*sx + up[1]*sy,
      centre[2] + right[2]*sx + up[2]*sy
    ];
    /* Textures are uploaded with UNPACK_FLIP_Y, so canvas-bottom is v=0.
       The bottom edge of the card must therefore take uv0.y — get this
       backwards and every blade of grass hangs down from the sky. */
    const a = this.vert(p(-1,-1), n, [uv0[0],uv0[1]], col, sway);
    const b = this.vert(p( 1,-1), n, [uv1[0],uv0[1]], col, sway);
    const c = this.vert(p( 1, 1), n, [uv1[0],uv1[1]], col, sway);
    const d = this.vert(p(-1, 1), n, [uv0[0],uv1[1]], col, sway);
    this.quad(a,b,c,d);
  }

  build(gl){
    return new Mesh(gl, new Float32Array(this.v), new Uint32Array(this.i));
  }
  get tris(){ return this.i.length/3; }
}

/* ---- vector helpers ------------------------------------------------- */
const V = {
  add:(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]],
  sub:(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],
  scale:(a,s)=>[a[0]*s,a[1]*s,a[2]*s],
  dot:(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],
  cross:(a,b)=>[a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]],
  len:(a)=>Math.hypot(a[0],a[1],a[2]),
  norm(a){ const l=Math.hypot(a[0],a[1],a[2])||1; return [a[0]/l,a[1]/l,a[2]/l]; },
  lerp:(a,b,t)=>[a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t, a[2]+(b[2]-a[2])*t],
  /* Any two axes perpendicular to `d`. Needed to build a ring of
     vertices around a branch pointing in an arbitrary direction. */
  basis(d){
    const up = Math.abs(d[1]) > 0.95 ? [1,0,0] : [0,1,0];
    const r = V.norm(V.cross(up, d));
    return [r, V.cross(d, r)];
  },
  /* Rotate `v` around unit axis `k` by `ang` (Rodrigues' formula). */
  rotAxis(v, k, ang){
    const c = Math.cos(ang), s = Math.sin(ang);
    const kv = V.cross(k, v), kd = V.dot(k, v);
    return [
      v[0]*c + kv[0]*s + k[0]*kd*(1-c),
      v[1]*c + kv[1]*s + k[1]*kd*(1-c),
      v[2]*c + kv[2]*s + k[2]*kd*(1-c)
    ];
  }
};

/* ---- textures -------------------------------------------------------
   Every texture in this file is drawn with the 2D canvas API at load
   time and uploaded to the GPU. Nothing is downloaded. */
function texFromCanvas(gl, cv, mips){
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, t);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, cv);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
  if(mips !== false){
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    /* Sharpens alpha-tested foliage at grazing angles; harmless if the
       extension is missing. */
    const aniso = gl.getExtension('EXT_texture_filter_anisotropic');
    if(aniso) gl.texParameterf(gl.TEXTURE_2D, aniso.TEXTURE_MAX_ANISOTROPY_EXT, 4);
  } else {
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  }
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return t;
}
function newCanvas(w,h){
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

/* ---- render target -------------------------------------------------- */
class RT {
  constructor(gl, w, h, opts){
    opts = opts || {};
    this.gl = gl; this.w = w; this.h = h; this.opts = opts;
    this.fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);

    this.tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    const internal = opts.float ? gl.RGBA16F : gl.RGBA8;
    const type     = opts.float ? gl.HALF_FLOAT : gl.UNSIGNED_BYTE;
    gl.texImage2D(gl.TEXTURE_2D, 0, internal, w, h, 0, gl.RGBA, type, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.tex, 0);

    if(opts.depth){
      this.rbo = gl.createRenderbuffer();
      gl.bindRenderbuffer(gl.RENDERBUFFER, this.rbo);
      gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, w, h);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.rbo);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  resize(w,h){
    if(w===this.w && h===this.h) return;
    const gl = this.gl;
    this.w=w; this.h=h;
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    const internal = this.opts.float ? gl.RGBA16F : gl.RGBA8;
    const type     = this.opts.float ? gl.HALF_FLOAT : gl.UNSIGNED_BYTE;
    gl.texImage2D(gl.TEXTURE_2D, 0, internal, w, h, 0, gl.RGBA, type, null);
    if(this.rbo){
      gl.bindRenderbuffer(gl.RENDERBUFFER, this.rbo);
      gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, w, h);
    }
  }
  bind(){
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    gl.viewport(0,0,this.w,this.h);
  }
}

/* A depth-only target. This is the shadow map: the scene rendered from
   the sun's point of view, storing only "how far was the nearest thing".
   Comparing against it later is what puts leaf shadows on the ground. */
class DepthRT {
  constructor(gl, size){
    this.gl = gl; this.size = size;
    this.fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    this.tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24, size, size, 0,
                  gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    /* COMPARE_REF_TO_TEXTURE turns this into a sampler2DShadow: the GPU
       does the depth comparison and the bilinear filter in one step,
       which gives free 2x2 softening on every tap. */
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, this.tex, 0);
    gl.drawBuffers([gl.NONE]);
    gl.readBuffer(gl.NONE);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  bind(){
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    gl.viewport(0,0,this.size,this.size);
  }
}

/* A single triangle that covers the screen. Cheaper than two, and
   avoids a seam down the diagonal in post-processing passes. */
function fullscreenVAO(gl){
  const vao = gl.createVertexArray();
  gl.bindVertexArray(vao);
  const b = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, b);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);
  gl.bindVertexArray(null);
  return vao;
}
