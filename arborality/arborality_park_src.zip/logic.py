import asyncio
from playwright.async_api import async_playwright
PATH='file:///home/claude/arborality/arborality_park.html'

# Drive update() by hand at a fixed dt so the result does not depend on
# how fast this machine can actually draw a frame.
STEP = """(n) => { for(let i=0;i<n;i++) window.__P.update(0.05); }"""

async def main():
    errs=[]
    async with async_playwright() as pw:
        b=await pw.chromium.launch(headless=True,args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--no-sandbox'])
        pg=await b.new_page(viewport={'width':420,'height':300})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(PATH, wait_until='load', timeout=120000)
        await pg.wait_for_selector('#bootGo:not(.hidden)', timeout=240000)
        await pg.click('#bootGo'); await pg.wait_for_timeout(600)

        r = await pg.evaluate("""() => {
          const P = window.__P, W = window.__W;
          const t = W.specimens.find(s => s.key === 'sakura');
          // stand beside it, looking 50 degrees off and slightly down
          P.pos[0] = t.x + 3.2; P.pos[2] = t.z + 3.2;
          P.pos[1] = groundH(P.pos[0], P.pos[2]) + 1.62;
          P.yaw = Math.atan2(-3.2,-3.2) + 0.9; P.pitch = -0.18;
          P.frozen = true;                       // as it is while the device is up
          const before = P.aimAt([t.x, t.y + 4.5, t.z], 0.6);
          for(let i=0;i<20;i++) P.update(0.05);  // 1.0 s — tween is 0.6 s
          const aimed = { yaw:P.yaw, pitch:P.pitch };
          // now put the device away
          P.tweenTo(before.yaw, before.pitch, 0.5);
          for(let i=0;i<20;i++) P.update(0.05);
          const back = { yaw:P.yaw, pitch:P.pitch };
          const wrap = a => ((a + Math.PI) % (Math.PI*2) + Math.PI*2) % (Math.PI*2) - Math.PI;
          return {
            before, aimed, back,
            turnedBy: Math.abs(wrap(aimed.yaw - before.yaw)),
            yawError: Math.abs(wrap(back.yaw - before.yaw)),
            pitchError: Math.abs(back.pitch - before.pitch),
            aimCleared: P.aim === null
          };
        }""")
        f = lambda d: {k: round(v,4) for k,v in d.items()}
        print('before :', f(r['before']))
        print('aimed  :', f(r['aimed']), ' turned', round(r['turnedBy'],3), 'rad =',
              round(r['turnedBy']*57.3,1), 'deg')
        print('back   :', f(r['back']))
        print()
        print('RESTORED yaw within 0.001 rad?  ', r['yawError']   < 0.001, '(off by', round(r['yawError'],6), ')')
        print('RESTORED pitch within 0.001 rad?', r['pitchError'] < 0.001, '(off by', round(r['pitchError'],6), ')')
        print('tween finished and cleared?     ', r['aimCleared'])
        print('errors:', errs[:5] or '(none)')
        await b.close()
asyncio.run(main())
