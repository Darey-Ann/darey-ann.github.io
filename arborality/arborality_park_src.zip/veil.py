import asyncio
from playwright.async_api import async_playwright
PATH='file:///home/claude/arborality/arborality_park.html'
async def main():
    errs=[]
    async with async_playwright() as pw:
        b=await pw.chromium.launch(headless=True,args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--no-sandbox'])
        pg=await b.new_page(viewport={'width':940,'height':590})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(PATH, wait_until='load', timeout=120000)
        await pg.wait_for_selector('#bootGo:not(.hidden)', timeout=240000)
        await pg.click('#bootGo'); await pg.wait_for_timeout(1000)
        # stand at a sakura and open it straight onto the plate
        await pg.evaluate("""()=>{const P=__P,W=__W;
          const t=W.specimens.find(s=>s.key==='sakura');
          P.pos[0]=t.x+3.4; P.pos[2]=t.z+3.4;
          P.pos[1]=groundH(P.pos[0],P.pos[2])+1.62;
          P.yaw=Math.atan2(-3.4,-3.4); P.pitch=0.06;}""")
        await pg.wait_for_timeout(1500)
        await pg.keyboard.press('Space'); await pg.wait_for_timeout(900)
        await pg.click('.mitem')
        await pg.wait_for_function("()=>Device.state==='plate'", timeout=90000)
        await pg.evaluate("()=>{Device.playing=false;Device.syncPlay();Device.setT(0.42);}")
        await pg.wait_for_timeout(1200)
        await pg.screenshot(timeout=240000, path='w_sakura.png')
        print('errors:', errs[:5] or '(none)')
        await b.close()
asyncio.run(main())
