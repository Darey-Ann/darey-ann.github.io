import asyncio
from playwright.async_api import async_playwright
PATH='file:///home/claude/arborality/arborality_park.html'
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(headless=True,args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--no-sandbox'])
        pg=await b.new_page(viewport={'width':400,'height':300})
        await pg.goto(PATH, wait_until='load', timeout=120000)
        await pg.wait_for_selector('#bootGo:not(.hidden)', timeout=240000)
        r = await pg.evaluate("""() => {
          const W = window.__W;
          // how far is each specimen from the CENTRE LINE of the path?
          const P = window.__P;
          const rows = W.specimens.map(s => {
            const off   = distToPath(W.path, s.x, s.z).d;
            const reach = P.reachOf(s);
            return {
              key: s.key,
              offPath: +off.toFixed(2),
              reach:   +reach.toFixed(2),
              // how far along the path you can be and still be in range:
              // half-width of the window, from Pythagoras
              window: reach > off ? +(2*Math.sqrt(reach*reach - off*off)).toFixed(1) : 0
            };
          });
          const wanted = ['sakura','momiji','sugi','ginkgo','matsu'];
          const placed = {};
          for(const k of wanted) placed[k] = rows.filter(r=>r.key===k).length;
          return { total: rows.length, placed, rows };
        }""")
        print('specimens placed:', r['total'], 'of the 14 asked for')
        print('by species:', r['placed'])
        print()
        print(' species    how far off the path / how far it can be noticed')
        for row in sorted(r['rows'], key=lambda x:(x['key'], x['offPath'])):
            v = 'OUT OF REACH' if row['window'] == 0 else ('tight' if row['window'] < 4 else 'OK')
            print('  %-8s  off %5.2f m   reach %5.2f m   walkable window %5.1f m   %s'
                  % (row['key'], row['offPath'], row['reach'], row['window'], v))
        await b.close()
asyncio.run(main())
