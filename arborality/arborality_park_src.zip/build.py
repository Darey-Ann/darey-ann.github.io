#!/usr/bin/env python3
"""
Assemble the single self-contained page.

Nothing here is downloaded at runtime, so three things get folded in:
  - every source file, in order
  - the ANCHORS table, lifted verbatim out of the Arborality app so the
    two cannot drift apart
  - all 200 sakura plates, as base64 data URLs
"""
import base64, glob, os, re, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.join(ROOT, 'src')
APP  = '/root/.claude/uploads/f52d230d-5901-50a8-a275-5cef3896de24/33c64af2-arborality.html'
PLATES = os.path.join(ROOT, 'plates')
OUT  = os.path.join(ROOT, 'arborality_park.html')

# ---- pull ANCHORS straight from the app -----------------------------
app = open(APP, encoding='utf-8').read()
m = re.search(r'const ANCHORS = (\[.*?\]);', app, re.S)
if not m:
    sys.exit('could not find ANCHORS in the app')
anchors_js = 'const ANCHORS = %s;\n' % m.group(1)
print('anchors:', len(m.group(1)), 'bytes')

# ---- plates as data URLs --------------------------------------------
files = sorted(glob.glob(os.path.join(PLATES, 'plate_*.webp')))
if len(files) != 200:
    sys.exit('expected 200 plates, found %d' % len(files))
parts = []
for f in files:
    b64 = base64.b64encode(open(f, 'rb').read()).decode('ascii')
    parts.append('"data:image/webp;base64,' + b64 + '"')
plates_js = 'const PLATES = [\n' + ',\n'.join(parts) + '\n];\n'
print('plates:', round(len(plates_js)/1048576, 2), 'MB of base64')

# ---- assemble -------------------------------------------------------
head = open(os.path.join(SRC, '00_head.html'), encoding='utf-8').read()
body = open(os.path.join(SRC, '00_body.html'), encoding='utf-8').read()
js_files = sorted(f for f in os.listdir(SRC) if f.endswith('.js'))
js = []
for f in js_files:
    js.append('\n/* ================= %s ================= */\n' % f)
    js.append(open(os.path.join(SRC, f), encoding='utf-8').read())
print('js:', js_files)

ORIENTATION = r'''
/* ############################################################################

   ARBORALITY PARK — READ ME FIRST

   One file, no libraries, nothing downloaded. Everything below was
   assembled from the eleven source files in `src/` by `build.py`; edit
   those and re-run the build rather than editing this file, or your
   changes will be overwritten next time.

   ---------------------------------------------------------------------------
   WHAT THE FILES DO, in the order they appear below
   ---------------------------------------------------------------------------
   01_gl.js         Maths and WebGL plumbing. 4x4 matrices, a seeded random
                    number generator, value noise, shader compilation, the
                    Mesh/Builder pair that every piece of geometry is made
                    with, and render targets.

   02_shaders.js    The programs that run on the graphics card. One shared
                    vertex stage; fragment stages for surfaces, shadow
                    depth, sky, the marker ring, and the post-processing
                    chain (bright pass, blur, god rays, final grade).

   03_textures.js   Every leaf, blossom, needle, blade of grass, butterfly
                    and patch of bark, DRAWN with 2D canvas commands at
                    startup. There are no image files in this project
                    except your 200 sakura plates.

   04_trees.js      Grows the trees. One recursive function walks a branch
                    forward, bends it, drops foliage on it and calls
                    itself. SPECIES_FORM at the top is where a cedar stops
                    being a maple — start there to change how a tree looks.

   05_world.js      The park: ground heightfield, the winding path, where
                    every tree, shrub, tuft and flower goes, and the
                    petals, butterflies and birds that move.

   06_render.js     Draws the frame. LOOK at the top holds every lighting
                    value — sun angle and colour, haze, exposure, bloom.
                    Start there to change the time of day.

   07_player.js     Walking, looking, collision, and the turn that swings
                    the view onto a tree when you raise the device.

   08_data.js       What the device knows about each of the five species.
                    The sakura entry is copied from the Arborality app so
                    the two cannot disagree.

   09_schematic.js  Draws the growing ink figure for the four species that
                    have no rendered plates.

   10_device.js     The device itself: a state machine (menu -> scanning ->
                    plate -> collection) and the code that lays the plate
                    out against the metre scale.

   11_main.js       Synthesised sound, the loading sequence, the keyboard,
                    and the frame loop that ties it together.

   ---------------------------------------------------------------------------
   WHAT HAPPENS IN ONE FRAME  (Renderer.render, in 06_render.js)
   ---------------------------------------------------------------------------
     1. Draw the whole park from the SUN's point of view, recording only
        how far away the nearest thing was. That is the shadow map, and it
        is what puts leaf-shaped shadows on the grass.
     2. Draw the park again from YOUR point of view into an off-screen
        buffer, asking the shadow map at every pixel whether the sun can
        see that spot.
     3. Add the marker ring at the foot of the tree being asked about.
     4. Run a few flat passes over that buffer: pull out the bright parts,
        blur them (bloom), streak them away from the sun (god rays), then
        tone-map and grade the result onto the screen.

   Steps 1 and 4 are the two halves of komorebi: dapple on the ground,
   shafts in the air.

   ---------------------------------------------------------------------------
   WHERE TO CHANGE THE OBVIOUS THINGS
   ---------------------------------------------------------------------------
     time of day, warmth, haze .... LOOK          (06_render.js)
     sun height ................... SUN_ELEV      (06_render.js)
     tree shapes .................. SPECIES_FORM  (04_trees.js)
     shape of the path ............ PATH_CTRL     (05_world.js)
     which trees stand where ...... buildWorld    (05_world.js)
     how crowded the park is ...... the loop counts in buildWorld
     what the device says ......... LIB           (08_data.js)
     the device's look ............ the CSS in the <style> above
     walking speed, eye height .... EYE, `speed`  (07_player.js)

   The park is grown from ONE fixed seed (20260824, in buildWorld), so it
   is identical every time it loads. Change that number and you get a
   different park — same rules, different arrangement.

   ############################################################################ */

'''

out = []
out.append(head)
out.append(body)
out.append('<script>\n')
out.append(ORIENTATION)
out.append('/* the plate anchor table, copied from the Arborality app */\n')
out.append(anchors_js)
out.append('\n/* 200 rendered plates, inlined */\n')
out.append(plates_js)
out.append(''.join(js))
out.append('\n</script>\n')

html = ''.join(out)
open(OUT, 'w', encoding='utf-8').write(html)
print('wrote', OUT, round(len(html.encode('utf-8'))/1048576, 2), 'MB')
