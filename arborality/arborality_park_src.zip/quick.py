import asyncio
from playwright.async_api import async_playwright
PATH='file:///home/claude/arborality/arborality_park.html'
async def main():
    errs=[]
    async with async_playwright() as pw:
        b=await pw.chromium.launch(headless=True,args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--no-sandbox'])
        pg=await b.new_page(viewport={'width':960,'height':600})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(PATH, wait_until='load', timeout=120000)
        await pg.wait_for_selector('#bootGo:not(.hidden)', timeout=240000)
        await pg.click('#bootGo'); await pg.wait_for_timeout(1200)

        # stand beside a sakura but face AWAY from it, then raise the device
        await pg.evaluate("""()=>{const P=window.__P,W=window.__W;
          const t=W.specimens.find(s=>s.key==='sakura');
          P.pos[0]=t.x+3.4; P.pos[2]=t.z+3.4; P.yaw=Math.atan2(-3.4,-3.4)+0.95; P.pitch=-0.20;}""")
        await pg.wait_for_timeout(2200)
        await pg.screenshot(timeout=240000, path='q_before.png')
        print('prompt:', await pg.eval_on_selector('#prompt','e=>e.classList.contains("on")'))
        await pg.keyboard.press('Space')
        await pg.wait_for_timeout(1000)
        await pg.click('.mitem')
        await pg.wait_for_timeout(1400)
        await pg.screenshot(timeout=240000, path='q_scan.png')
        await pg.wait_for_timeout(3400)
        await pg.evaluate("()=>{Device.playing=false;Device.syncPlay();Device.setT(0.55);}")
        await pg.wait_for_timeout(1400)
        await pg.screenshot(timeout=240000, path='q_plate.png')

        # sugi schematic mid-life
        await pg.evaluate("()=>{Device.hide();}")
        await pg.evaluate("""()=>{const P=window.__P,W=window.__W;
          const t=W.specimens.find(s=>s.key==='sugi');
          P.pos[0]=t.x-3; P.pos[2]=t.z-7; P.yaw=Math.atan2(3,7); P.pitch=0.1;}""")
        await pg.wait_for_timeout(1400)
        await pg.evaluate("""()=>{Device.show(window.__W.specimens.find(s=>s.key==='sugi'));
          Device.state='plate'; Device.el.rail.classList.remove('off'); Device.buildTicks();
          Device.playing=false; Device.syncPlay(); Device.setT(0.55);}""")
        await pg.wait_for_timeout(1800)
        await pg.screenshot(timeout=240000, path='q_sugi.png')
        print('errors:', errs[:6] or '(none)')
        await b.close()
asyncio.run(main())
