import asyncio, sys
from playwright.async_api import async_playwright

PATH = 'file:///home/claude/arborality/arborality_park.html'
TAG  = sys.argv[1] if len(sys.argv) > 1 else ''

TELEPORT = """(k) => {
  const P = window.__P, W = window.__W;
  const t = W.specimens.find(s => s.key === k) || W.specimens[0];
  const a = Math.atan2(t.x, t.z);
  P.pos[0] = t.x - Math.sin(a)*4.6;
  P.pos[2] = t.z - Math.cos(a)*4.6;
  P.yaw = a; P.pitch = 0.08;
  return {key:t.key};
}"""

async def main():
    logs, errs = [], []
    async with async_playwright() as pw:
        b = await pw.chromium.launch(headless=True, args=[
            '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
            '--ignore-gpu-blocklist', '--no-sandbox'])
        pg = await b.new_page(viewport={'width':1000,'height':620})
        pg.on('console', lambda m: logs.append(m.type + ': ' + m.text))
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(PATH, wait_until='load', timeout=120000)
        try:
            await pg.wait_for_selector('#bootGo:not(.hidden)', timeout=240000)
        except Exception:
            print('BOOT FAILED:', await pg.eval_on_selector('#bootMsg','e=>e.textContent'))
            print('\n'.join(logs[-25:])); print(errs[:5]); await b.close(); return
        print('boot:', await pg.eval_on_selector('#bootMsg','e=>e.textContent'))
        await pg.click('#bootGo')
        await pg.wait_for_timeout(1500)
        shot = lambda n: pg.screenshot(timeout=240000, path='s%s_%s.png' % (TAG, n))

        # the marker ring: stand near a tree and let the halo fade in
        await pg.evaluate(TELEPORT, 'sakura')
        await pg.wait_for_timeout(3200)
        print('prompt on:', await pg.eval_on_selector('#prompt','e=>e.classList.contains("on")'))
        print('halo a:', round(await pg.evaluate("()=>window.__R.halo.a"), 3))
        await shot('01_halo')

        # a wider view of the ring from further back
        await pg.evaluate("()=>{ const P=window.__P; P.pos[0]+=1.6; P.pitch=-0.22; }")
        await pg.wait_for_timeout(1400)
        await shot('02_ring')

        # device: menu should now be see-through
        await pg.keyboard.press('Space')
        await pg.wait_for_timeout(900)
        await shot('03_menu')
        await pg.click('.mitem')
        await pg.wait_for_timeout(1100)
        await shot('04_scanning')
        await pg.wait_for_timeout(3200)
        await shot('05_plate')
        print('actions:', await pg.evaluate("()=>!!document.querySelector('.pv-actions')"))
        print('play disabled:', await pg.evaluate("()=>document.getElementById('playBtn').disabled"))
        await pg.evaluate("()=>{ Device.playing=false; Device.syncPlay(); Device.setT(0.30); }")
        await pg.wait_for_timeout(700); await shot('06_t30')
        await pg.evaluate("()=>Device.setT(0.62)")
        await pg.wait_for_timeout(700); await shot('07_t62')
        await pg.evaluate("()=>Device.setT(0.95)")
        await pg.wait_for_timeout(700); await shot('08_t95')

        # buttons
        await pg.click('#pvAdd'); await pg.wait_for_timeout(400)
        await pg.click('[data-act="back"]'); await pg.wait_for_timeout(600)
        print('back -> state:', await pg.evaluate("()=>Device.state"))
        await pg.click('#exitBtn'); await pg.wait_for_timeout(600)
        print('exit -> open:', await pg.evaluate("()=>Device.open"))
        print('frozen:', await pg.evaluate("()=>window.__P.frozen"))

        # a schematic species, checking the metre scale agrees
        await pg.evaluate(TELEPORT, 'sugi')
        await pg.wait_for_timeout(1200)
        await pg.keyboard.press('Space'); await pg.wait_for_timeout(700)
        await pg.click('.mitem'); await pg.wait_for_timeout(3600)
        await pg.evaluate("()=>{ Device.playing=false; Device.syncPlay(); Device.setT(0.62); }")
        await pg.wait_for_timeout(800); await shot('09_sugi')
        await pg.click('#pvAdd'); await pg.wait_for_timeout(300)
        await pg.click('[data-act="back"]'); await pg.wait_for_timeout(400)
        await pg.click('.mitem:nth-child(2)')
        await pg.wait_for_timeout(1200); await shot('10_collection')
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(400)
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(600)

        # quality toggle
        await pg.keyboard.press('KeyP'); await pg.wait_for_timeout(1200)
        print('quality after P:', await pg.evaluate("()=>window.__R.quality"))
        await pg.wait_for_timeout(800); await shot('11_lighter')

        print('frameMs:', round(await pg.evaluate("()=>window.__R.frameMs"),1))
        print('--- console ---'); print('\n'.join(logs[-20:]) or '(none)')
        print('--- errors ---');  print('\n'.join(errs[:15]) or '(none)')
        await b.close()

asyncio.run(main())
