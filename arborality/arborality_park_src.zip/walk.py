import asyncio
from playwright.async_api import async_playwright
PATH='file:///home/claude/arborality/arborality_park.html'
async def main():
    async with async_playwright() as pw:
        b=await pw.chromium.launch(headless=True,args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--no-sandbox'])
        pg=await b.new_page(viewport={'width':400,'height':300})
        await pg.goto(PATH, wait_until='load', timeout=120000)
        await pg.wait_for_selector('#bootGo:not(.hidden)', timeout=240000)
        r = await pg.evaluate("""() => {
          const P = window.__P, W = window.__W;
          // Walk the whole loop in half-metre steps, facing the way the
          // path goes, exactly as someone holding the up arrow would.
          const seen = {}, order = [];
          let promptedSteps = 0, steps = 0;
          for(let s = 0; s < W.path.len; s += 0.5){
            const at = pathPointAt(W.path, s);
            P.pos[0] = at.p[0]; P.pos[2] = at.p[1];
            P.pos[1] = groundH(P.pos[0], P.pos[2]) + 1.62;
            P.yaw = Math.atan2(at.dir[0], at.dir[2]);
            P.pitch = 0.02;
            steps++;
            const t = P.nearestSpecimen();
            if(t){
              promptedSteps++;
              seen[t.key] = (seen[t.key]||0) + 1;
              if(order[order.length-1] !== t.key) order.push(t.key);
            }
          }
          // and: is a tree already on offer the moment the park opens?
          P.pos = P.start.pos.slice(); P.pos[1] = groundH(P.pos[0],P.pos[2]) + 1.62;
          P.yaw = P.start.yaw; P.pitch = P.start.pitch;
          const atSpawn = P.nearestSpecimen();
          return { seen, order, coverage: Math.round(promptedSteps/steps*100),
                   loop: Math.round(W.path.len),
                   atSpawn: atSpawn ? atSpawn.key : null };
        }""")
        print('path loop is', r['loop'], 'm long')
        print()
        print('species offered while walking it once, in order:')
        print('  ' + ' -> '.join(r['order']))
        print()
        print('steps at which SOME tree was offered:', str(r['coverage'])+'% of the walk')
        print('prompt showing the instant the park opens?',
              ('YES - ' + r['atSpawn']) if r['atSpawn'] else 'no')
        print()
        for k in ['sakura','momiji','sugi','ginkgo','matsu']:
            n = r['seen'].get(k, 0)
            print('  %-8s %s  (%s)' % (k, 'REACHABLE' if n else 'never offered',
                                       str(round(n*0.5,1))+' m of walking' if n else '—'))
        await b.close()
asyncio.run(main())
