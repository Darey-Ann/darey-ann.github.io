import asyncio
from playwright.async_api import async_playwright
PATH='file:///home/claude/arborality/arborality_park.html'

async def main():
    errs=[]
    async with async_playwright() as pw:
        b=await pw.chromium.launch(headless=True,args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--no-sandbox'])
        pg=await b.new_page(viewport={'width':960,'height':600})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(PATH, wait_until='load', timeout=120000)
        await pg.wait_for_selector('#bootGo:not(.hidden)', timeout=240000)
        await pg.click('#bootGo'); await pg.wait_for_timeout(1200)

        start = await pg.evaluate("()=>({x:__P.pos[0],z:__P.pos[2],yaw:__P.yaw})")
        print('start:', {k:round(v,2) for k,v in start.items()})

        # stand near a sakura, deliberately looking off to one side
        await pg.evaluate("""()=>{const P=__P,W=__W;
          const t=W.specimens.find(s=>s.key==='sakura');
          P.pos[0]=t.x+3.2; P.pos[2]=t.z+3.2;
          P.yaw=Math.atan2(-3.2,-3.2)+0.9; P.pitch=-0.18;}""")
        await pg.wait_for_timeout(2400)
        before = await pg.evaluate("()=>({yaw:__P.yaw,pitch:__P.pitch})")
        print('before scan:', {k:round(v,3) for k,v in before.items()})

        await pg.keyboard.press('Space'); await pg.wait_for_timeout(1600)
        aimed = await pg.evaluate("()=>({yaw:__P.yaw,pitch:__P.pitch})")
        print('aimed at tree:', {k:round(v,3) for k,v in aimed.items()},
              '-> turned', round(abs(aimed['yaw']-before['yaw']),3), 'rad')
        await pg.screenshot(timeout=240000, path='v_aimed.png')

        await pg.click('.mitem'); await pg.wait_for_timeout(4200)
        await pg.click('#pvAdd'); await pg.wait_for_timeout(500)
        print('collected:', await pg.evaluate("()=>Object.keys(Device.collection).length"))

        await pg.click('#exitBtn')
        # Wait for the turn to actually finish rather than guessing at a
        # duration: under software rendering a frame can take seconds, and
        # the tween only advances when a frame runs.
        try:
            await pg.wait_for_function("() => window.__P.aim === null", timeout=120000)
        except Exception as e:
            print('tween never finished:', e)
        await pg.wait_for_timeout(300)
        after = await pg.evaluate("()=>({yaw:__P.yaw,pitch:__P.pitch})")
        print('after close:', {k:round(v,3) for k,v in after.items()})
        dy = abs(((after['yaw']-before['yaw']+3.14159)%6.28318)-3.14159)
        print('RESTORED?  yaw off by', round(dy,4),
              'pitch off by', round(abs(after['pitch']-before['pitch']),4))

        # R: reset
        await pg.keyboard.press('KeyR'); await pg.wait_for_timeout(900)
        rst = await pg.evaluate("()=>({x:__P.pos[0],z:__P.pos[2],yaw:__P.yaw,n:Object.keys(Device.collection).length,tally:document.getElementById('tallyN').textContent})")
        print('after R:', {k:(round(v,2) if isinstance(v,(int,float)) else v) for k,v in rst.items()})
        print('BACK AT START?', abs(rst['x']-start['x'])<0.01 and abs(rst['z']-start['z'])<0.01,
              '| COLLECTION EMPTY?', rst['n']==0, '| tally shows', rst['tally'])
        print('stored copy cleared?', await pg.evaluate("()=>localStorage.getItem('arborality.collection')"))
        await pg.screenshot(timeout=240000, path='v_reset.png')
        print('errors:', errs[:6] or '(none)')
        await b.close()
asyncio.run(main())
